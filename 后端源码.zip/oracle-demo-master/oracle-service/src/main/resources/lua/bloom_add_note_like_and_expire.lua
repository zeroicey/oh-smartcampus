-- 操作的 key
local key = KEYS[1]
local noteId = ARGV[1] -- 笔记ID
local expireSeconds = ARGV[2] -- 过期秒数

redis.call('BF.ADD', key, noteId)
-- 设置过期时间
redis.call('EXPIRE', key, expireSeconds)
return 0