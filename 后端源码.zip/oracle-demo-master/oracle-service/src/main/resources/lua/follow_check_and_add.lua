-- LUA 脚本：校验并添加关注关系

local key = KEYS[1]          -- 操作的 Redis Key
local followUserId = ARGV[1] -- 关注用户 ID
local timestamp = ARGV[2]    -- 过期秒数

-- 使用 EXISTS 命令检查 ZSET 用户列表是否存在
local exists = redis.call('EXISTS', key)
if exists == 0 then
    return -1
end

-- 校验关注人数是否上限（是否达到 1000）
local size = redis.call('ZCARD', key)
if size >= 1000 then
    return -2
end

-- 校验目标用户是否已经关注
if redis.call('ZSCORE', key, followUserId) then
    return -3
end

-- ZADD 添加关注关系
redis.call('ZADD', key, timestamp, followUserId)

---- 缓存穿透的键值存在时，删除防止缓存穿透的键值
-- Lua 脚本操作 ZSET 时会不会带上 "" 而在 java 代码操作 ZSET 时会带上 ""，因此在 Lua 脚本需要带上双引号
if redis.call('ZSCORE', key, '"null"') then
    redis.call('ZREM', key, '"null"')
end

return 0