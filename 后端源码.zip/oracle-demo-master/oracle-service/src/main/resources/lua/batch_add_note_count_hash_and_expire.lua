local key = KEYS[1] -- 操作的 key

local hashArgs = {} -- 准备批量添加数据的参数表

-- 遍历 ARGV 参数，将键和值按顺序插入到 hashArgs 变量中
for i = 1, #ARGV - 1, 2 do
    -- 小 bug : 传入的 lua 参数为 string 时会自带双引号，如 "likeTotal" 需要手动去除
    local field = ARGV[i]:gsub('"', '')  -- 去掉键名中的双引号
    table.insert(hashArgs, field)
    table.insert(hashArgs, ARGV[i + 1])
end

-- 调用 HSET 批量插入数据
redis.call('HSET', key, unpack(hashArgs))

-- 设置 HSET 的过期时间
local expireTime = ARGV[#ARGV] -- 最后一个参数为过期时间
redis.call('EXPIRE', key, expireTime)
return 0
