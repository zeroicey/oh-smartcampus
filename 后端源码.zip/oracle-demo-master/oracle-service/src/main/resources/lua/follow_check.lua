-- LUA 脚本：校验关注关系

local key = KEYS[1]          -- 操作的 Redis Key
local targetUserId = ARGV[1] -- 关注用户 ID

-- 使用 EXISTS 命令检查 ZSET 用户列表是否存在
local exists = redis.call('EXISTS', key)
if exists == 0 then
    return -1
end

-- 防止缓存穿透，用户没有关注记录
-- Lua 脚本操作 ZSET 时会不会带上 "" 而在 java 代码操作 ZSET 时会带上 ""，因此在 Lua 脚本需要带上双引号
if redis.call('ZSCORE', key, '"null"') then
    return 0
end

-- 校验目标用户是否被关注
if redis.call('ZSCORE', key, targetUserId) then
    return -3
end

return 0