local key = KEYS[1]           -- 操作的 Redis Key
local followUserId = ARGV[1]  -- 关注的用户ID
local timestamp = ARGV[2]     -- 时间戳
local expireSeconds = ARGV[3] -- 过期时间（秒）

-- ZADD 添加关注关系
redis.call('ZADD', key, timestamp, followUserId)

-- 缓存穿透的键值存在，删除防止缓存穿透的键值
-- Lua 脚本操作 ZSET 时会不会带上 "" 而在 java 代码操作 ZSET 时会带上 ""，因此在 Lua 脚本需要带上双引号
if redis.call('ZSCORE', key, '"null"') then
    redis.call('ZREM', key, '"null"')
end

-- 设置过期时间
redis.call('EXPIRE', key, expireSeconds)
return 0