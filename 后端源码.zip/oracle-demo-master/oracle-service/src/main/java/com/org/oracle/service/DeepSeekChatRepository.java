package com.org.oracle.service;

import com.org.oracle.mongodb.entity.DeepSeekChatRecord;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface DeepSeekChatRepository extends MongoRepository<DeepSeekChatRecord, String> {
    // 根据用户ID查询对话历史（按时间倒序）
    List<DeepSeekChatRecord> findByUserIdOrderByCreatedAtDesc(String userId);
}