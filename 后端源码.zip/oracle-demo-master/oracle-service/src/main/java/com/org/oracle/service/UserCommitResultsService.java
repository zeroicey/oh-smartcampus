package com.org.oracle.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.org.oracle.mysql.dto.UserAnswerSubmitDTO;
import com.org.oracle.mysql.entity.UserCommitResult;
import com.org.oracle.mysql.vo.ChapterProgressVo;
import com.org.oracle.mysql.vo.SubjectStudyTimeVo;
import com.org.oracle.result.Result;

import java.util.Date;
import java.util.List;


/**
 * (UserCommitResults)表服务接口
 *
 * @author luo
 * @since 2024-12-16 20:37:19
 */
public interface UserCommitResultsService extends IService<UserCommitResult> {

    Result userUpLoadAnswer(String uid, UserAnswerSubmitDTO submitDTO);

    Result userTemporarySaveAnswer(String uid, UserAnswerSubmitDTO submitDTO);

    Date getLastSubmitOrTemporaryTime(String uid, String chapterId);
    Long getChapterTotalStudyTime(String uid, String chapterId);

    boolean isChapterCompleted(String uid, String chapterId);
    List<ChapterProgressVo> getChapterProgressBySubjectId(String uid, String subjectId);

    List<SubjectStudyTimeVo> getSubjectStudyTimeToday(String uid);

    Float getSubjectProgressByUid(String uid);
}

