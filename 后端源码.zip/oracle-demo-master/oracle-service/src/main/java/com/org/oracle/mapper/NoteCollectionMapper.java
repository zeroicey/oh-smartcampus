package com.org.oracle.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.org.oracle.mysql.entity.NoteCollection;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author: heiye
 * @date: 2024/12/14 上午11:54
 * @version: v1.0.0
 * @description: 笔记收藏
 */
@Mapper
public interface NoteCollectionMapper extends BaseMapper<NoteCollection> {
    /**
     * 新增笔记收藏记录，若已存在，则更新笔记收藏记录
     *
     * @param noteCollection
     * @return
     */
    int saveOrUpdate(NoteCollection noteCollection);
}
