package com.org.oracle.exception;

import com.org.oracle.enums.ResponseCodeEnum;
import com.org.oracle.result.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author: heiye
 * @date: 2024/10/08 下午2:09
 * @version: v1.0.0
 * @description: 全局异常处理
 */
@Slf4j
@ControllerAdvice
public class GlobalExceptionHandler {
    /**
     * 处理不可控异常
     *
     * @param e
     * @return
     */
    @ExceptionHandler(Exception.class)
    @ResponseBody
    public Result exception(Exception e) {
        log.error("catch exception:", e);
        return Result.fail(ResponseCodeEnum.SERVER_ERROR.getErrorMessage(), 500);
    }

    /**
     * 处理可控异常  自定义异常
     *
     * @param e
     * @return
     */
    @ExceptionHandler(CustomException.class)
    @ResponseBody
    public Result exception(CustomException e) {
        log.error("catch exception:", e);
        return Result.fail(e.getResponseCodeEnum().getErrorMessage(), e.getResponseCodeEnum().getCode());
    }

    /**
     * 处理 guava 参数校验异常
     *
     * @param e
     * @return
     */
    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseBody
    public Result exception(IllegalArgumentException e) {
        log.error("catch exception:", e);
        return Result.fail(e.getMessage(), ResponseCodeEnum.PARAM_REQUIRE.getCode());
    }
}