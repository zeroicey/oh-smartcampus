package com.org.oracle.controller;

import com.org.oracle.mongodb.entity.KnowledgeBase;
import com.org.oracle.result.Result;
import com.org.oracle.service.KnowledgeBaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @Author: heiye
 * @CreateTime: 2024/09/09 下午5:51
 * @Description: 知识库
 * @Version: 1.0
 */
@RestController
@RequestMapping("/knowledgeBase")
public class KnowledgeBaseController {

    @Autowired
    private KnowledgeBaseService knowledgeBaseService;

    /**
     * 添加知识库
     *
     * @param knowledgeBase
     * @return
     */
    @PostMapping("/create")
    public Result create(@RequestBody KnowledgeBase knowledgeBase) {
        knowledgeBaseService.create(knowledgeBase);
        return Result.ok();
    }

    /**
     * 模糊查询数据库
     *
     * @param name
     * @return
     */
    @GetMapping("/find")
    public Result find(String name) {
        return Result.ok(knowledgeBaseService.find(name));
    }
}
