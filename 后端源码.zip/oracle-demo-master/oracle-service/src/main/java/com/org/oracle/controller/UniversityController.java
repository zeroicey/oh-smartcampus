package com.org.oracle.controller;

import com.org.oracle.mysql.dto.FindRangeSearchDTO;
import com.org.oracle.mysql.dto.FindSchoolSearchDTO;
import com.org.oracle.mysql.vo.FindRangeSearchVO;
import com.org.oracle.result.Result;
import com.org.oracle.service.UniversityService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

/**
 * @author suze
 * @date 2024/11/30
 * @time 15:42
 **/
@RestController
@RequestMapping("/university")
public class UniversityController {

    @Resource
    private UniversityService universityService;
    /**
     * 根据地区查找大学信息
     *搜索参数：
     * 地区
     * 专业（由大专业和小专业组成）
     * @param findRangeSearchDTO 包含搜索条件的视图对象
     * @return 返回搜索结果封装在Result对象中
     */
    @PostMapping("/findRangeSearch")
    public Result findRangeSearch(@RequestBody FindRangeSearchDTO findRangeSearchDTO) {
        //TODO
        return Result.ok(universityService.findRangeSearch(findRangeSearchDTO));
    }
    /**
     * 根据学校名字搜索学校信息
     *搜索参数：
     * 学校名字
     * @param findSchoolSearchDTO 包含搜索条件的视图对象
     * @return 返回搜索结果封装在Result对象中
     */
    @PostMapping("/findSchool")
    public Result findSchool(@RequestBody FindSchoolSearchDTO findSchoolSearchDTO) {
        //TODO
        return Result.ok(universityService.findSchool(findSchoolSearchDTO));
    }

}
