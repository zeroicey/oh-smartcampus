package com.org.oracle.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.org.oracle.mysql.entity.UserQuestionProgress;


/**
 * (UserQuestionProgress)表服务接口
 *
 * @author luo
 * @since 2024-12-18 20:37:44
 */
public interface UserQuestionProgressService extends IService<UserQuestionProgress> {

}

