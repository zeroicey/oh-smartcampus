package com.org.oracle.service;

import com.org.oracle.mongodb.entity.ChatSession;
import com.org.oracle.mongodb.entity.DeepSeekChatRecord;
import com.org.oracle.mongodb.entity.UserChatSession;
import com.org.oracle.sub.entity.Message;
import reactor.core.publisher.Flux;

import java.util.List;

public interface DeepSeekChatService {
    // 流式对话（含持久化）
    Flux<String> streamChat(String userId, String userInput);
//
    // 获取用户对话历史
    List<DeepSeekChatRecord> getChatHistory(String userId);
//    List<UserChatSession> getChatHistory(String userId);
//    Flux<String> streamChat(String sessionId, String userInput);
//    List<Message> getSessionHistory(String sessionId);
//    List<ChatSession> listUserSessions(String userId);
}