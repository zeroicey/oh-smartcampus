package com.org.oracle.consumer;

import com.github.phantomthief.collection.BufferTrigger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.org.oracle.constant.MQConstants;
import com.org.oracle.constant.RedisKeyConstants;
import com.org.oracle.enums.CollectUnCollectNoteTypeEnum;
import com.org.oracle.mysql.dto.AggregationCountCollectUnCollectNoteMqDTO;
import com.org.oracle.mysql.dto.CollectUnCollectNoteMqDTO;
import com.org.oracle.util.JsonUtils;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.client.producer.SendCallback;
import org.apache.rocketmq.client.producer.SendResult;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.checkerframework.checker.nullness.qual.Nullable;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author: heiye
 * @date: 2024/12/15 下午5:27
 * @version: v1.0.0
 * @description: 计数: 笔记收藏数
 */
@Slf4j
@Component
@RocketMQMessageListener(
        // Group 组
        consumerGroup = "oracle_group_" + MQConstants.TOPIC_COUNT_NOTE_COLLECT,
        // 消费的主题 Topic
        topic = MQConstants.TOPIC_COUNT_NOTE_COLLECT
)
public class CountNoteCollectConsumer implements RocketMQListener<String> {

    @Resource
    private RedisTemplate<String, Object> redisTemplate;

    @Resource
    private RocketMQTemplate rocketMQTemplate;

    private BufferTrigger<String> bufferTrigger = BufferTrigger.<String>batchBlocking()
            // 缓冲队列的最大容量
            .bufferSize(50000)
            // 一批次最多聚合 1000 条
            .batchSize(1000)
            // 多久聚合一次
            .linger(Duration.ofSeconds(1))
            // 设置消费者方法
            .setConsumerEx(this::consumeMessage)
            .build();

    @Override
    public void onMessage(String body) {
        // 往 bufferTrigger 中添加元素
        bufferTrigger.enqueue(body);
    }

    private void consumeMessage(List<String> bodys) {
        log.info("==> 【笔记收藏数】聚合消息, size: {}", bodys.size());
        log.info("==> 【笔记收藏数】聚合消息, {}", JsonUtils.toJsonString(bodys));

        List<CollectUnCollectNoteMqDTO> collectUnCollectNoteMqDTOS = bodys.stream()
                .map(body -> JsonUtils.parseObject(body, CollectUnCollectNoteMqDTO.class))
                .toList();

        // 按笔记 ID 进行分组
        Map<String, List<CollectUnCollectNoteMqDTO>> groupMap = collectUnCollectNoteMqDTOS.stream()
                .collect(Collectors.groupingBy(CollectUnCollectNoteMqDTO::getNoteId));

        // 按组汇总数据，统计出最终的计数
        // 最终操作的计数对象
        ArrayList<AggregationCountCollectUnCollectNoteMqDTO> countList = Lists.newArrayList();

        for (Map.Entry<String, List<CollectUnCollectNoteMqDTO>> entry : groupMap.entrySet()) {
            List<CollectUnCollectNoteMqDTO> list = entry.getValue();
            // 笔记ID
            String noteId = entry.getKey();
            // 笔记作者ID
            String creatorId = null;
            // 最终的计数值，默认为0
            int finalCount = 0;
            for (CollectUnCollectNoteMqDTO collectUnCollectNoteMqDTO : list) {
                // 获取操作类型
                Integer type = collectUnCollectNoteMqDTO.getType();

                creatorId = collectUnCollectNoteMqDTO.getNoteCreatorId();

                // 根据操作类型，获取对应枚举
                CollectUnCollectNoteTypeEnum collectUnCollectNoteTypeEnum = CollectUnCollectNoteTypeEnum.valueOf(type);

                // 若枚举为空，跳到下一次循环
                if (Objects.isNull(collectUnCollectNoteTypeEnum)) {
                    continue;
                }

                switch (collectUnCollectNoteTypeEnum) {
                    // 如果为收藏操作，点赞数 +1
                    case COLLECT -> finalCount += 1;
                    // 如果为取消收藏操作，点赞数 -1
                    case UN_COLLECT -> finalCount -= 1;
                }
            }
            // 将分组后统计出的最终计数，存入 countMap 中
            countList.add(AggregationCountCollectUnCollectNoteMqDTO.builder()
                    .noteId(noteId)
                    .creatorId(creatorId)
                    .count(finalCount)
                    .build());
        }
        log.info("## 【笔记收藏数】聚合后的计数数据: {}", JsonUtils.toJsonString(countList));

        // 更新 Redis
        countList.forEach(item -> {
            // 笔记 ID
            String noteId = item.getNoteId();
            // 笔记发布者 ID
            String creatorId = item.getCreatorId();
            // 聚合后的计数
            Integer count = item.getCount();
            // Redis Hash Key
            String countNoteKey = RedisKeyConstants.buildCountNoteKey(noteId);
            // 判断 Redis 中 Hash 是否存在
            Boolean isCountNoteExisted = redisTemplate.hasKey(countNoteKey);

            // 若存在才会更新
            // (因为缓存设有过期时间，考虑到过期后，缓存会被删除，这里需要判断一下，存在才会去更新，而初始化工作放在查询计数来做)
            if (isCountNoteExisted) {
                // 对目标用户 Hash 中的收藏总数字段进行计数操作
                redisTemplate.opsForHash().increment(countNoteKey, RedisKeyConstants.FIELD_COLLECT_TOTAL, count);
            }

            // 更新 Redis 用户维度点赞数
            String countUserKey = RedisKeyConstants.buildCountUserKey(creatorId);
            Boolean isCountUser = redisTemplate.hasKey(countUserKey);
            if (isCountUser) {
                redisTemplate.opsForHash().increment(countUserKey, RedisKeyConstants.FIELD_COLLECT_TOTAL, count);
            }
        });

        // 发送 MQ, 笔记收藏数据落库
        Message<String> message = MessageBuilder.withPayload(JsonUtils.toJsonString(countList)).build();

        // 异步发送 MQ 消息
        rocketMQTemplate.asyncSend(MQConstants.TOPIC_COUNT_NOTE_COLLECT_2_DB, message, new SendCallback() {
            @Override
            public void onSuccess(SendResult sendResult) {
                log.info("==> 【计数服务：笔记收藏数入库】MQ 发送成功，SendResult: {}", sendResult);
            }

            @Override
            public void onException(Throwable throwable) {
                log.error("==> 【计数服务：笔记收藏数入库】MQ 发送异常: ", throwable);
            }
        });
    }
}
