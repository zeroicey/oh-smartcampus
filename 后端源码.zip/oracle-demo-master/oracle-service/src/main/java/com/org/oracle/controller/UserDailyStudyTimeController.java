package com.org.oracle.controller;

import com.org.oracle.mysql.vo.SubjectStudyTimeVo;
import com.org.oracle.result.Result;
import com.org.oracle.service.UserAnswerDetailsService;
import com.org.oracle.service.UserCommitResultsService;
import com.org.oracle.service.UserDailyStudyTimeService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

//TODO 这里的controller的URL设置得不是很规范，可以放在question里的
@RestController
@RequestMapping("/question")
public class UserDailyStudyTimeController {
    @Resource
    private UserDailyStudyTimeService userDailyStudyTimeService;

    @Resource
    private UserAnswerDetailsService userAnswerDetailsService;

    @Resource
    private UserCommitResultsService userCommitResultsService;
    //获取总学习时间
    @GetMapping("/totalStudyTime")
    public Result getUserTotalStudyTime(String uid){
        return userDailyStudyTimeService.getTotalStudyTimeInMinutes(uid);
    }

    /**
     * 获取用户当天刷题数
     * @param uid 用户id
     * @return 用户当天刷题数 Integer类型
     */
    @GetMapping("/userQuestionCount")
    public Integer userQuestionCount(String uid){
        return userAnswerDetailsService.countQuestionsByUid(uid);
    }

    /**
     * 获取用户当天学习时间
     * @param uid 用户Id
     * @return 用户当天学习时间（分钟为单位）
     */
    @GetMapping("/todayStudyTime")
    public Result getUserTodayStudyTime(String uid){
        return userDailyStudyTimeService.getTodayStudyTimeInMinutes(uid);
    }

    /**
     * 获取用户当天各科目的学习时间统计情况（没做的科目时间为0）
     * @param uid 用户ID
     * @return 包含每个科目学习时间等信息的列表
     */
    @GetMapping("/subjectStudyTimeToday")
    public Result getSubjectStudyTimeToday(@RequestHeader String uid) {
        List<SubjectStudyTimeVo> studyTimeVos = userCommitResultsService.getSubjectStudyTimeToday(uid);
        return Result.ok(studyTimeVos);
    }
}
