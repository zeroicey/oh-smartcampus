package com.org.oracle.config;

import org.apache.rocketmq.spring.autoconfigure.RocketMQAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

/**
 * @author: heiye
 * @date: 2024/12/12 下午9:34
 * @version: v1.0.0
 * @description: RocketMQ 配置
 */
@Configuration
@Import(RocketMQAutoConfiguration.class)
public class RocketMQConfig {
}
