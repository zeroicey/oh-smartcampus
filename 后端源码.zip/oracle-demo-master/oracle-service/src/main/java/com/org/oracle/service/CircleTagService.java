package com.org.oracle.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.org.oracle.mysql.entity.CircleTag;
import com.org.oracle.mysql.vo.CircleTagVO;

import java.util.List;

/**
 * @author: heiye
 * @date: 2024/11/14 下午3:02
 * @version: v1.0.0
 * @description: 知识圈标签Service
 */
public interface CircleTagService extends IService<CircleTag> {
    /**
     * 查找全部知识圈标签
     *
     * @return
     */
    List<CircleTagVO> findAll();
}
