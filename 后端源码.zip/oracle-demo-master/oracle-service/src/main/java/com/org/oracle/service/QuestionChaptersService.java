package com.org.oracle.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.org.oracle.mysql.entity.QuestionChapters;
import com.org.oracle.result.Result;

import java.util.List;


/**
 * (QuestionChapters)表服务接口
 *
 * @author luo
 * @since 2024-11-13 20:18:50
 */
public interface QuestionChaptersService extends IService<QuestionChapters> {

//    List<QuestionChapters> getChapterBySubjectId(String id);

    String getChapterIdByName(String chapterName);

    Result getQuestionByCircleContext(String context);
}
