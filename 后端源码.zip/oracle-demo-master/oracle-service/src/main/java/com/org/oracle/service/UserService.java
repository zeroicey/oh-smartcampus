package com.org.oracle.service;

import com.org.oracle.mongodb.dto.*;
import com.org.oracle.mongodb.vo.*;

import java.util.List;

/**
 * @author: heiye
 * @date: 2024/10/09 下午9:23
 * @version: v1.0.0
 * @description:
 */
public interface UserService {
    /**
     * 用户注册
     *
     * @param userRegisterDTO
     */
    void register(UserRegisterDTO userRegisterDTO);

    /**
     * 登录
     *
     * @param userLoginDTO
     */
    UserVO login(UserLoginDTO userLoginDTO);

    /**
     * 修改密码
     *
     * @param uid
     * @param updatePasswordDTO
     */
    void updatePassword(String uid, UpdatePasswordDTO updatePasswordDTO);

    /**
     * 忘记密码
     *
     * @param forgetPasswordDTO
     */
    void forgetPassword(ForgetPasswordDTO forgetPasswordDTO);

    /**
     * 修改用户信息
     *
     * @param uid
     * @param userUpdateInfoDTO
     * @return
     */
    void updateInfo(String uid, UserUpdateInfoDTO userUpdateInfoDTO);

    /**
     * 根据用户ID查找用户详细信息
     *
     * @param uid
     * @return
     */
    UserDetailCircleVO findUserDetailById(String uid);

    /**
     * 根据用户ID查询用户的基本信息
     * 调用了 redis 和  caffeine 形成 2 级缓存
     * 防止缓存雪崩，缓存穿透和缓存击穿的问题
     *
     * @param uid
     * @return
     */
    UserSimpleVO findUserSimpleById(String uid);

    /**
     * 批量查询用户简要信息
     *
     * @param ids
     * @return
     */
    List<UserSimpleVO> findUserSimpleByIds(List<String> ids);

    /**
     * 基于用户id查找用户主页信息
     *
     * @param uid
     * @return
     */
    UserInfoVO findUserById(String uid);

//  =============================== 暂时不需要的服务 =================================

    /**
     * 根据用户ID查找用户的可编辑信息
     *
     * @param uid
     * @return
     */
    UserEditInfoVO findUserEditInfoById(String uid);

    /**
     * 用户邮箱信息换绑
     *
     * @param uid
     * @param userUpdateEmailDTO
     */
    void updateEmail(String uid, UserUpdateEmailDTO userUpdateEmailDTO);

//    =============================== 已经弃用的服务 ===============================

    /**
     * 微信登录
     *
     * @return
     */
    String wxLogin(UserLoginDTO dto);
}
