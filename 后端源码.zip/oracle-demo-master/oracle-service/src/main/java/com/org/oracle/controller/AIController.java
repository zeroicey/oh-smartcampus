package com.org.oracle.controller;

import com.org.oracle.mongodb.entity.AiHistory;
import com.org.oracle.mysql.dto.AiHistoryQueryDTO;
import com.org.oracle.result.Result;
import com.org.oracle.service.AIService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

/**
 * @author: heiye
 * @date: 2024/11/11 上午9:55
 * @version: v1.0.0
 * @description: AI转接接口
 */
@RestController
@RequestMapping("/ai")
public class AIController {

    @Resource
    private AIService aiService;

    /**
     * 保存聊天记录
     *
     * 该方法通过POST请求接收聊天记录数据，并将其保存到系统中
     * 主要用于处理用户与AI交互的记录，以便于后续回顾和分析
     *
     * @param aiHistory 包含要保存的聊天记录信息的数据传输对象
     * @return 返回保存结果，包括是否成功保存以及相关的消息
     * @author SUZE
     * @time 2024/12/18-15:48
     */
    @PostMapping("/save")
    public Result save(@RequestBody AiHistory aiHistory) {
        aiService.save(aiHistory);
        return Result.ok();
    }

    /**
     * 处理历史记录列表请求
     * 该方法接收一个POST请求，并返回与给定查询条件匹配的历史记录列表
     * 主要用途是当需要根据特定条件（如时间范围、类型等）检索历史记录时
     *
     * @param aiHistoryQueryDTO 包含查询条件的DTO对象，用于指定查询的历史记录的条件
     * @return 返回一个Result对象，其中包含符合查询条件的历史记录列表
     */
    @PostMapping("/history_list")
    public Result historyList(@RequestBody AiHistoryQueryDTO aiHistoryQueryDTO) {
        return Result.ok(aiService.historyList(aiHistoryQueryDTO));
    }

    /**
     * 获取历史记录详细信息
     * 通过GET请求获取指定UID的历史记录的详细信息
     * 主要用于展示单个历史记录的详细页面，以便用户可以深入了解该记录的具体内容
     *
     * @param mid 历史记录的唯一标识符，用于指定需要获取详细信息的历史记录
     * @return 返回一个Result对象，其中包含指定历史记录的详细信息
     */
    @GetMapping("/history_detail")
    public Result historyDetail(@RequestParam("mid") String mid) {
        return Result.ok(aiService.historyDetail(mid));
    }



}
