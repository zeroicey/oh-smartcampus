package com.org.oracle.controller;

import com.org.oracle.mongodb.entity.Comment;
import com.org.oracle.result.Result;
import com.org.oracle.service.CircleService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

/***
 * @title CommentController
 * @author SUZE
 * @Date 18:27
 **/
@RestController
@RequestMapping("/circle")
public class CommentController {
    @Resource
    private CircleService circleService;

    /**
     * 用户发送评论
     *
     * 此方法用于让用户对知识圈中的内容发送评论
     * @param uid 用户ID，从请求头获取
     * @param comment 包含评论信息的对象
     * 返回表示评论发送结果的Result对象
     */
    @GetMapping("/sendComment")
    public Result send_comment(@RequestHeader("uid") String uid, @RequestBody Comment comment) {
        return Result.ok(circleService.send_comment(uid, comment));
    }

    /**
     * 通过笔记id查看某笔记的评论详情
     *
     * 此方法用于获取特定笔记的所有评论详情
     * @param cmid 笔记ID，用于获取评论信息
     * 返回包含特定笔记所有评论信息的Result对象
     */
    @GetMapping("/findComment")
    public Result find_comment(@RequestParam("cmid") String cmid) {
        return Result.ok(circleService.find_comment(cmid));
    }


}
