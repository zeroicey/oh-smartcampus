package com.org.oracle.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.org.oracle.mysql.entity.Subjects;
import com.org.oracle.result.Result;

import java.util.List;


/**
 * (Subjects)表服务接口
 *
 * @author luo
 * @since 2024-12-02 09:35:58
 */
public interface SubjectsService extends IService<Subjects> {

    String getSubjectIdByName(String subjectName);

    List<Subjects> getAllSubjects();

    Result getAllSubject();
}

