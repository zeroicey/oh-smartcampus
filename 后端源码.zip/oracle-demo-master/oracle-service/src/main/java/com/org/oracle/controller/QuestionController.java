package com.org.oracle.controller;


import com.org.oracle.mysql.vo.ChapterProgressVo;
import com.org.oracle.result.Result;
import com.org.oracle.service.QuestionChaptersService;
import com.org.oracle.service.QuestionsService;
import com.org.oracle.service.SubjectsService;
import com.org.oracle.service.UserCommitResultsService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/question")
public class QuestionController {

    @Resource
    private QuestionsService questionsService;

    @Resource
    private QuestionChaptersService questionChaptersService;

    @Resource
    private UserCommitResultsService userCommitResultsService;

    @Resource
    private SubjectsService subjectsService;
    //获取题目
    @GetMapping("/getQuestion")
    public Result getQuestion(){

        return questionsService.getQuestion();
    }

    /**
     * 根据章节id获取相应题目
     * @param id
     * @return
     */
    @GetMapping("/getQuestionByChapterId/{id}")
    public Result getQuestionByChapterId(@PathVariable String id){
        return questionsService.getQuestionByChapterId(id);
    }

    /**
     * 获取所有学科
     * @return
     */
    @GetMapping("/getAllSubject")
    public Result getAllSubject(){
        return subjectsService.getAllSubject();
    }
    /**
     * 根据学科id获取相应章节
     * @param id
     * @return
     */
    @GetMapping("getChapterBySubjectId")
    public Result getChapterBySubjectId(@RequestParam String uid,@RequestParam String id){
        List<ChapterProgressVo> chapterProgressList = userCommitResultsService.getChapterProgressBySubjectId(uid, id);
//        return questionChaptersService.getChapterBySubjectId(id);
        return Result.ok(chapterProgressList);
    }

    /**
     * AI跳题
     * @param topicContext 话题词汇
     * @return 相关题目集合
     */
    @GetMapping("/getQuestionByCircleContext")
    public Result getQuestionByCircleContext(@RequestParam String topicContext){
        return questionChaptersService.getQuestionByCircleContext(topicContext);
    }
}