package com.org.oracle.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.org.oracle.mysql.entity.UserAnswerDetail;


/**
 * (UserAnswerDetails)表服务接口
 *
 * @author luo
 * @since 2024-12-16 20:35:16
 */
public interface UserAnswerDetailsService extends IService<UserAnswerDetail> {
    Integer countQuestionsByUid(String uid);
}

