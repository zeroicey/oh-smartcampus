package com.org.oracle.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.org.oracle.mysql.entity.UserQuestionProgress;
import com.org.oracle.mapper.UserQuestionProgressMapper;
import org.springframework.stereotype.Service;
import com.org.oracle.service.UserQuestionProgressService;

/**
 * (UserQuestionProgress)表服务实现类
 *
 * @author luo
 * @since 2024-12-18 20:37:44
 */
@Service("userQuestionProgressService")
public class UserQuestionProgressServiceImpl extends ServiceImpl<UserQuestionProgressMapper, UserQuestionProgress> implements UserQuestionProgressService {

}

