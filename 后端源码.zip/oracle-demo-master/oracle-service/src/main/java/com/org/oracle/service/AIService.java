package com.org.oracle.service;

import com.org.oracle.mongodb.entity.AiHistory;
import com.org.oracle.mongodb.vo.AiHistoryVO;
import com.org.oracle.mysql.dto.AiHistoryQueryDTO;

import java.util.List;

/**
 * @author: heiye
 * @date: 2024/11/11 下午6:53
 * @version: v1.0.0
 * @description: AI转接Service
 */
public interface AIService {


    void save(AiHistory aiHistory);

    List<AiHistoryVO> historyList(AiHistoryQueryDTO aiHistoryQueryDTO);

    AiHistory historyDetail(String mid);
}
