package com.org.oracle.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.org.oracle.mysql.entity.Questions;
import com.org.oracle.result.Result;

import java.util.List;
import java.util.Map;


/**
 * (Questions)表服务接口
 *
 * @author luo
 * @since 2024-11-13 17:21:59
 */
public interface QuestionsService extends IService<Questions> {

    Result getQuestion();

    void saveQuestions(List<Questions> questions);

    Result getQuestionByChapterId(String id);

    Integer getQuestionNumByChapterId(String id);

    List<Questions> convertToQuestionsList(List<Questions> questions);

    Map<Long,String> getAnswersByIds(List<Long> questionIds);

    String getAnswerById(Long questionId);
}

