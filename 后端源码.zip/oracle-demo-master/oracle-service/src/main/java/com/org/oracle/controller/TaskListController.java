package com.org.oracle.controller;

import com.org.oracle.result.Result;
import com.org.oracle.service.TaskListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/19 下午10:31
 */
@RestController
@RequestMapping("/taskList")
public class TaskListController {
    @Autowired
    private TaskListService taskListService;

    /**
     * 查询用户的每日任务表单
     */
    @GetMapping("/find")
    public Result findByUid(@RequestHeader String uid) {
        return Result.ok(taskListService.findByUid(uid));
    }

    /**
     * 查询用户是否能点击打卡按钮
     *
     * @return
     */
    @GetMapping("/check")
    public Result check(@RequestHeader String uid) {
        return Result.ok(taskListService.check(uid));
    }

    /**
     * 用户手动打卡
     *
     * @param uid
     * @return
     */
    @GetMapping("/press")
    public Result press(@RequestHeader String uid) {
        taskListService.press(uid);
        return Result.ok();
    }
    /**
     * 获取总打卡天数
     *
     * @param uid
     * @return
     */
    @GetMapping("/getDay")
    public Result getDay(@RequestHeader("uid") String uid) {
        return Result.ok(taskListService.getDay(uid));
    }

    /**
     * 获取月打卡天数
     *
     * @param uid
     * @return
     */
    @GetMapping("/getMDay")
    public Result getMDay(@RequestHeader("uid") String uid) {
        return Result.ok(taskListService.getMDay(uid));
    }

}
