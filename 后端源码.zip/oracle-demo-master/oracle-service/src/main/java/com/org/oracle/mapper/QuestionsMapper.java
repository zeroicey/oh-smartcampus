package com.org.oracle.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.org.oracle.mysql.entity.Questions;


/**
 * (Questions)表数据库访问层
 *
 * @author luo
 * @since 2024-11-13 17:21:54
 */
public interface QuestionsMapper extends BaseMapper<Questions> {

}

