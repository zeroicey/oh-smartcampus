package com.org.oracle.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.org.oracle.mysql.entity.UserAnswerDetail;


/**
 * (UserAnswerDetails)表数据库访问层
 *
 * @author luo
 * @since 2024-12-16 20:35:12
 */
public interface UserAnswerDetailsMapper extends BaseMapper<UserAnswerDetail> {

}

