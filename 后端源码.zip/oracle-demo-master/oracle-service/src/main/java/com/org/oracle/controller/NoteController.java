package com.org.oracle.controller;

import com.org.oracle.mongodb.dto.CircleQueryBatchDTO;
import com.org.oracle.mongodb.entity.CircleContext;
import com.org.oracle.mysql.dto.CollectNoteDTO;
import com.org.oracle.mysql.dto.LikeNoteDTO;
import com.org.oracle.mysql.dto.UnCollectNoteDTO;
import com.org.oracle.mysql.dto.UnLikeNoteDTO;
import com.org.oracle.result.Result;
import com.org.oracle.service.CircleService;
import com.org.oracle.service.NoteService;
import com.org.oracle.sub.dto.PageRequestDTO;
import jakarta.annotation.Resource;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/***
 * @title NoteController
 * @author SUZE
 * @Date 18:23
 **/
@RestController
@RequestMapping("/note")
public class NoteController {

    @Resource
    private NoteService noteService;

    /**
     * 批量查询笔记
     *
     * @param dto
     * @return 返回查询结果，包括批量查询到的知识圈内容
     */
    @GetMapping("/queryBatch")
    public Result queryBatch(CircleQueryBatchDTO dto) {
        return Result.ok(noteService.queryBatch(dto));
    }

    /**
     * 查询笔记详情
     *
     * @param noteId 内容ID，用于指定知识圈内的具体内容
     * @return 返回查询结果，包括知识圈内的具体内容
     */
    @GetMapping("/queryById")
    public Result queryById(@RequestHeader String uid, @RequestParam("noteId") String noteId) {
        return Result.ok(noteService.queryOne(uid, noteId));
    }

    /**
     * 用户发送笔记
     * <p>
     * 此方法用于让用户提交手写笔记到特定知识圈
     *
     * @param uid           用户ID，从请求头获取
     * @param circleContext 包含笔记信息的对象
     *                      返回表示笔记发送结果的Result对象
     */
    @PostMapping("/sendNote")
    public Result send_note(@RequestHeader("uid") String uid, @RequestBody CircleContext circleContext) {
        return Result.ok(noteService.send_note(uid, circleContext));
    }

    /**
     * 用户获取发过的笔记
     * <p>
     * 此方法用于获取用户在知识圈中发布的所有笔记
     *
     * @param uid 用户ID，从请求头获取
     *            返回包含用户发布所有笔记信息的Result对象
     */
    @GetMapping("/find_note")
    public Result find_note(@RequestHeader("uid") String uid, PageRequestDTO pageRequestDTO) {
        return Result.ok(noteService.find_note(uid, pageRequestDTO));
    }

    /**
     * 用户保存手写笔记 --存草稿
     * <p>
     * 此方法用于保存用户的手写笔记到特定知识圈
     *
     * @param uid           用户ID，从请求头获取
     * @param circleContext 包含笔记信息的对象
     *                      返回表示笔记保存结果的Result对象
     */
    @PostMapping("/save_note")
    public Result save_note(@RequestHeader("uid") String uid, @RequestBody CircleContext circleContext) {
        return Result.ok(noteService.save_note(uid, circleContext));
    }

    /**
     * 用户查找保存过的笔记 --查草稿
     * <p>
     *
     * @param uid 用户ID，从请求头获取
     *            返回表示笔记保存结果的Result对象
     */
    @GetMapping("/get_save_note")
    public Result get_save_note(@RequestHeader("uid") String uid, PageRequestDTO pageRequestDTO) {
        return Result.ok(noteService.get_save_note(uid, pageRequestDTO));
    }

    @GetMapping("/get_save_note_one")
    public Result get_save_note_one(@RequestHeader("uid") String uid,@RequestParam("noteId") String  noteId) {
        return Result.ok(noteService.get_save_note_one(uid, noteId));
    }
    /**
     * 点赞笔记
     * 该接口应该写入笔记中
     * 但知识圈本身又和笔记存放在一起没有拆开
     * 导致那边的代码十分臃肿并且冗余
     * 暂时写入该接口中
     *
     * @param uid
     * @param likeNoteDTO
     * @return
     */
    @PostMapping("/like")
    public Result likeNote(@RequestHeader String uid, @Validated @RequestBody LikeNoteDTO likeNoteDTO) {
        noteService.likeNote(uid, likeNoteDTO);
        return Result.ok();
    }

    /**
     * 取消点赞笔记
     *
     * @param uid
     * @param unLikeNoteDTO
     * @return
     */
    @PostMapping("/unlike")
    public Result unlikeNote(@RequestHeader String uid, @Validated @RequestBody UnLikeNoteDTO unLikeNoteDTO) {
        noteService.unlikeNote(uid, unLikeNoteDTO);
        return Result.ok();
    }

    /**
     * 收藏笔记
     *
     * @param uid
     * @param collectNoteDTO
     * @return
     */
    @PostMapping("/collect")
    public Result collectNote(@RequestHeader String uid, @Validated @RequestBody CollectNoteDTO collectNoteDTO) {
        noteService.collectNote(uid, collectNoteDTO);
        return Result.ok();
    }

    /**
     * 取消收藏笔记
     *
     * @param uid
     * @param unCollectNoteDTO
     * @return
     */
    @PostMapping("/uncollect")
    public Result unCollectNote(@RequestHeader String uid, @Validated @RequestBody UnCollectNoteDTO unCollectNoteDTO) {
        noteService.unCollectNote(uid, unCollectNoteDTO);
        return Result.ok();
    }

    /**
     * 查询用户收藏过的笔记
     *
     * @param uid
     * @param pageRequestDTO
     * @return
     */
    @GetMapping("/findUserCollectNote")
    public Result findUserCollectedNote(@RequestHeader String uid, PageRequestDTO pageRequestDTO) {
        return Result.ok(noteService.findUserCollectedNote(uid, pageRequestDTO));
    }
}
