package com.org.oracle.service;

import com.org.oracle.mysql.dto.FindRangeSearchDTO;
import com.org.oracle.mysql.dto.FindSchoolSearchDTO;
import com.org.oracle.mysql.vo.FindRangeSearchVO;

import java.util.List;

/**
 * @author suze
 * @date 2024/11/30
 * @time 15:43
 **/
public interface UniversityService {


    List<FindRangeSearchVO> findRangeSearch(FindRangeSearchDTO findRangeSearchDTO);

    List<FindRangeSearchVO> findSchool(FindSchoolSearchDTO findSchoolSearchDTO);
}
