package com.org.oracle.service;

import com.org.oracle.mongodb.entity.Circle;
import com.org.oracle.mongodb.entity.Comment;
import com.org.oracle.mongodb.vo.CircleVO;

import java.util.List;

/**
 * @author suze
 * @date 2024/8/18
 * @time 20:11
 **/
public interface CircleService {


    List<CircleVO> find_all();

    List<Circle> find_by_tag(Long tag);

    List<Circle> find_by_word(String word);

//    List<Circle> find_by_user(String uid);


//    Object join_circle(String uid, String cid);

    Comment send_comment(String uid, Comment comment);

    List<Comment> find_comment(String cmid);

    Comment reply_comment(String uid, Comment comment);


//    /**
//     * 查询知识圈详情
//     * @param id
//     * @return
//     */
//    CircleVO queryById(String id);
}
