package com.org.oracle.controller;

import com.org.oracle.mongodb.dto.PointsListDTO;
import com.org.oracle.result.Result;
import com.org.oracle.service.StudyPointsListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @Author: heiye
 * @CreateTime: 2024/08/27 下午10:28
 * @Description: 学习积分榜接口
 * @Version: 1.0
 */
@RestController
@RequestMapping("/studyPointsList")
public class StudyPointsListController {

    @Autowired
    private StudyPointsListService studyPointsListService;

    /**
     * 查找榜单的积分排名
     *
     * @param dto
     * @return
     */
    @GetMapping("/findPointsList")
    public Result findPointsList(PointsListDTO dto) {
        return Result.ok(studyPointsListService.findPointsList(dto));
    }

    /**
     * 在学习积分榜单里查找到用户的积分
     *
     * @param uid
     * @param dto
     * @return
     */
    @GetMapping("/findUserPoints")
    public Result findUserPoints(@RequestHeader String uid, PointsListDTO dto) {
        return Result.ok(studyPointsListService.findUserPoints(uid, dto));
    }
}
