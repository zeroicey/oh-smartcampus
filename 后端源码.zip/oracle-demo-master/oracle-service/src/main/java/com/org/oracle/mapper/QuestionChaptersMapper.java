package com.org.oracle.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.org.oracle.mysql.entity.QuestionChapters;


/**
 * (QuestionChapters)表数据库访问层
 *
 * @author luo
 * @since 2024-11-13 20:15:33
 */
public interface QuestionChaptersMapper extends BaseMapper<QuestionChapters> {

}

