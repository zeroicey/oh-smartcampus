package com.org.oracle.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.google.common.collect.Lists;
import com.org.oracle.enums.DeletedEnum;
import com.org.oracle.mapper.CircleTagMapper;
import com.org.oracle.mysql.entity.CircleTag;
import com.org.oracle.mysql.vo.CircleTagVO;
import com.org.oracle.service.CircleTagService;
import jakarta.annotation.Resource;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author: heiye
 * @date: 2024/11/14 下午3:04
 * @version: v1.0.0
 * @description: 知识圈标签ServiceImpl
 */
@Service
public class CircleTagServiceImpl extends ServiceImpl<CircleTagMapper, CircleTag> implements CircleTagService {

    @Resource
    private CircleTagMapper circleTagMapper;

    /**
     * 查找全部知识圈标签
     *
     * @return
     */
    @Override
    public List<CircleTagVO> findAll() {
        // 查找全部知识圈标签
        LambdaQueryWrapper<CircleTag> lambdaQueryWrapper = Wrappers.<CircleTag>lambdaQuery()
                .eq(CircleTag::getIsDeleted, DeletedEnum.NO.getValue())
                .select(CircleTag::getId, CircleTag::getName);

        // 查询数据
        List<CircleTag> circleTags = circleTagMapper.selectList(lambdaQueryWrapper);

        // 初始化 VOS
        List<CircleTagVO> circleTagVOS = Lists.newArrayList();

        // 循环构建
        for (CircleTag circleTag : circleTags) {
            // 初始化 VO
            CircleTagVO circleTagVO = new CircleTagVO();

            // copy 数据
            BeanUtils.copyProperties(circleTag, circleTagVO);

            // 添加到列表中
            circleTagVOS.add(circleTagVO);

        }

        return circleTagVOS;
    }
}
