package com.org.oracle.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.org.oracle.mysql.entity.Task;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/19 下午7:47
 */
@Mapper
public interface TaskMapper extends BaseMapper<Task> {
}
