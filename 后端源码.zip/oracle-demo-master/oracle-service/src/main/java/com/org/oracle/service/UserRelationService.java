package com.org.oracle.service;

import com.org.oracle.mysql.dto.FollowUserDTO;
import com.org.oracle.mysql.dto.UnfollowUserDTO;

/**
 * @author: heiye
 * @date: 2024/12/20 上午9:14
 * @version: v1.0.0
 * @description: 用户关系
 */
public interface UserRelationService {
    /**
     * 关注用户
     *
     * @param uid
     * @param followUserDTO
     */
    void follow(String uid, FollowUserDTO followUserDTO);

    /**
     * 取消关注用户
     *
     * @param uid
     * @param unFollowUserDTO
     */
    void unfollow(String uid, UnfollowUserDTO unFollowUserDTO);

    /**
     * 查询用户之间关系
     *
     * @param uid
     * @param targetUserId
     */
    Boolean findUserRelation(String uid, String targetUserId);
}
