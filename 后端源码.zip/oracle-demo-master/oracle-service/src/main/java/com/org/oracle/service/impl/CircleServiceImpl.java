package com.org.oracle.service.impl;


import cn.hutool.core.collection.CollUtil;
import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;
import com.org.oracle.constant.MQConstants;
import com.org.oracle.enums.NoteOperateEnum;
import com.org.oracle.enums.ResponseCodeEnum;
import com.org.oracle.mongodb.dto.CircleQueryBatchDTO;
import com.org.oracle.mongodb.dto.NoteOperateMqDTO;
import com.org.oracle.mongodb.entity.*;
import com.org.oracle.mongodb.vo.*;
import com.org.oracle.mysql.vo.TopicVO;
import com.org.oracle.result.PageResult;
import com.org.oracle.service.CircleService;
import com.org.oracle.service.DraftService;
import com.org.oracle.service.TopicService;
import com.org.oracle.service.UserService;
import com.org.oracle.sub.dto.PageRequestDTO;
import com.org.oracle.util.JsonUtils;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.rocketmq.client.producer.SendCallback;
import org.apache.rocketmq.client.producer.SendResult;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.springframework.beans.BeanUtils;
import org.springframework.context.annotation.Primary;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;


import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author suze
 * @date 2024/8/18
 * @time 20:36
 **/
@Service
@Slf4j
@Primary
public class CircleServiceImpl implements CircleService {


    @Resource
    private MongoTemplate mongoTemplate;


    @Override
    public List<CircleVO> find_all() {
        // 创建查询对象
        Query query = new Query();
        // 执行查询
        List<Circle> circles = mongoTemplate.find(query, Circle.class);
//        System.out.println(circles);
        List<CircleVO> circleVOS = Lists.newArrayList();
        for (Circle circle : circles) {
            CircleVO circleVO = new CircleVO();
            BeanUtils.copyProperties(circle, circleVO);
            circleVOS.add(circleVO);
        }
        return circleVOS;
    }

    @Override
    public List<Circle> find_by_tag(Long tag) {
        Query query = new Query();
        query.addCriteria(Criteria.where("tag").is(tag));
        return mongoTemplate.find(query, Circle.class);
    }

    @Override
    public List<Circle> find_by_word(String word) {
        Query query = new Query();
        query.addCriteria(Criteria.where("tag").is(word).
                orOperator(Criteria.where("introduce").is(word)).
                orOperator(Criteria.where("circleName").is(word)));
        return mongoTemplate.find(query, Circle.class);
    }

    @Override
    public Comment send_comment(String uid, Comment comment) {
        mongoTemplate.insert(comment);
        return comment;
    }

    @Override
    public List<Comment> find_comment(String cmid) {
        Query query = new Query();
        query.addCriteria(Criteria.where("cmid").is(cmid));
        if (mongoTemplate.findOne(query, Comment.class) != null) {
            return mongoTemplate.find(query, Comment.class);
        }
        return null;
    }

    @Override
    public Comment reply_comment(String uid, Comment comment) {
        Query query = new Query();
        // 找到用户想要回复的那个人的评论
        query.addCriteria(Criteria.where("uid").is(comment.getReplyId()));
        Comment uComment = mongoTemplate.findOne(query, Comment.class);
        if (uComment != null) {
            List<Comment> subComment = uComment.getSubComment();
            subComment.add(comment);
            uComment.setSubComment(subComment);
            mongoTemplate.save(uComment);
            return uComment;
        }
        return null;
    }
}
