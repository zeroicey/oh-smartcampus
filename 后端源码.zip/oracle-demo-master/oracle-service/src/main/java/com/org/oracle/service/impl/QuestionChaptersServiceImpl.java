package com.org.oracle.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.org.oracle.mapper.QuestionChaptersMapper;
import com.org.oracle.mysql.entity.QuestionChapters;
import com.org.oracle.mysql.entity.Questions;
import com.org.oracle.mysql.vo.QuestionsVo;
import com.org.oracle.result.Result;
import com.org.oracle.service.QuestionChaptersService;
import com.org.oracle.service.QuestionsService;
import com.org.oracle.util.BeanCopyUtils;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;


/**
 * (QuestionChapters)表服务实现类
 *
 * @author luo
 * @since 2024-11-13 20:18:29
 */
@Service("questionChaptersService")
public class QuestionChaptersServiceImpl extends ServiceImpl<QuestionChaptersMapper, QuestionChapters> implements QuestionChaptersService {

    @Resource
    private QuestionChaptersMapper questionChaptersMapper;

    @Resource
    private QuestionsService questionsService;

//    @Override
//    public List<QuestionChapters> getChapterBySubjectId(String id) {
//        //根据科目id获取章节
//        LambdaQueryWrapper<QuestionChapters> queryWrapper = new LambdaQueryWrapper<>();
//        queryWrapper.eq(QuestionChapters::getSubjectId,id);
//        List<QuestionChapters> questionChapters = list(queryWrapper);
//        //设置章节的题目数
//        List<QuestionChapters> chaptersList = questionChapters.stream()
//                .map(questionChapters1 -> questionChapters1.setQuestionNum(questionsService.getQuestionNumByChapterId(String.valueOf(questionChapters1.getId()))))
//                .toList();
//        return chaptersList;
//    }

    @Override
    public String getChapterIdByName(String chapterName) {
        LambdaQueryWrapper<QuestionChapters> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(QuestionChapters::getName,chapterName);
        QuestionChapters chapter = questionChaptersMapper.selectOne(queryWrapper);
        if (chapter == null) {
            throw new RuntimeException("无法找到章节名称: " + chapterName + " 对应的章节 ID。");
        }
        return chapter.getId().toString();
    }

    @Override
    public Result getQuestionByCircleContext(String context) {
        if (!StringUtils.hasText(context)) {
            throw new RuntimeException("传入的话题context不为空");
        }
        LambdaQueryWrapper<QuestionChapters> queryWrapper = new LambdaQueryWrapper<>();
        String topic = topicSplitter(context);
        queryWrapper.like(QuestionChapters::getName, topic);
        // 匹配所有章节数据
        List<QuestionChapters> chapters = list(queryWrapper);

        // 若没有获取到对应章节
        if (chapters.isEmpty()) {
            throw new RuntimeException("找不到话题 [" + topic + "] 对应的题库");
        }
        // 如果匹配到多条，选择第一个
        QuestionChapters chapter = chapters.get(0);
        // 根据chapter章节获取题目
        LambdaQueryWrapper<Questions> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Questions::getChapterId, chapter.getId());
        // 只查询5条
        wrapper.last("Limit 5");
        // 返回查询结果
        List<Questions> questionsList = questionsService.convertToQuestionsList(questionsService.list(wrapper));
        List<QuestionsVo> questionsVos = BeanCopyUtils.copyBeanList(questionsList, QuestionsVo.class);
        return Result.ok(questionsVos);
    }

    /**
     * 字符串分割规则，取话题前两个字符
     * @param topic 传入的话题
     * @return 话题前两个字符
     */
    private String topicSplitter(String topic){
        String result;
        if(topic.length()>2){
            result = topic.substring(0,2);
        }else{
            result = topic;
        }
        return result;
    }
}