package com.org.oracle.controller;

import com.org.oracle.mongodb.dto.*;
import com.org.oracle.result.Result;
import com.org.oracle.service.UserService;
import jakarta.annotation.Resource;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * @author: heiye
 * @date: 2024/10/09 下午9:14
 * @version: v1.0.0
 * @description: 用户接口
 */
@RestController
@RequestMapping("/user")
public class UserController {

    @Resource
    private UserService userService;

    /**
     * 注册
     *
     * @param userRegisterDTO
     * @return
     */
    @PostMapping("/register")
    public Result register(@Validated @RequestBody UserRegisterDTO userRegisterDTO) {
        userService.register(userRegisterDTO);
        return Result.ok();
    }

    /**
     * 登录
     * TODO 将用户的一些基本信息返回给前端
     *
     * @param userLoginDTO
     * @return
     */
    @PostMapping("/login")
    public Result login(@Validated @RequestBody UserLoginDTO userLoginDTO) {
        return Result.ok(userService.login(userLoginDTO));
    }

    /**
     * 修改密码
     *
     * @param uid
     * @param updatePasswordDTO
     * @return
     */
    @PostMapping("/update/password")
    public Result updatePassword(@RequestHeader String uid, @Validated @RequestBody UpdatePasswordDTO updatePasswordDTO) {
        userService.updatePassword(uid, updatePasswordDTO);
        return Result.ok();
    }

    /**
     * 忘记密码
     *
     * @param forgetPasswordDTO
     * @return
     */
    @PostMapping("/forgotPassword")
    public Result forgotPassword(@RequestBody ForgetPasswordDTO forgetPasswordDTO) {
        userService.forgetPassword(forgetPasswordDTO);
        return Result.ok();
    }

    /**
     * 用户信息更改
     *
     * @param userUpdateInfoDTO
     * @return
     */
    @PostMapping("/update/info")
    public Result updateInfo(@RequestHeader String uid, @Validated @RequestBody UserUpdateInfoDTO userUpdateInfoDTO) {
        userService.updateInfo(uid, userUpdateInfoDTO);
        return Result.ok();
    }

    /**
     * 用户邮箱信息换绑
     *
     * @param userUpdateEmailDTO
     * @return
     */
    @PostMapping("/update/email")
    public Result updateEmail(@RequestHeader String uid, @Validated @RequestBody UserUpdateEmailDTO userUpdateEmailDTO) {
        userService.updateEmail(uid, userUpdateEmailDTO);
        return Result.ok();
    }

    /**
     * 基于用户id查找用户信息
     *
     * @return
     */
    @GetMapping("/findById")
    public Result findUserById(@RequestHeader String uid) {
        return Result.ok(userService.findUserById(uid));
    }

    /**
     * 查询用户的详情信息
     *
     * @param uid
     * @return
     */
    @GetMapping("/findUserDetailById")
    public Result findUserDetailById(String uid) {
        return Result.ok(userService.findUserDetailById(uid));
    }
//   ============================= 暂时不需要再向外提供该接口了 ==================================

    /**
     * 根据用户ID查找用户的可编辑信息
     *
     * @return
     */
//    @GetMapping("/findEditInfoById")
    public Result findUserEditInfoById(@RequestHeader String uid) {
        return Result.ok(userService.findUserEditInfoById(uid));
    }

//    =============================== 已经弃用的接口 ===============================

    /**
     * 用户登录
     *
     * @param dto
     * @return
     */
//    @PostMapping("/wxLogin")
    public Result wxLogin(@RequestBody UserLoginDTO dto) {
        return Result.ok(userService.wxLogin(dto));
    }
}

