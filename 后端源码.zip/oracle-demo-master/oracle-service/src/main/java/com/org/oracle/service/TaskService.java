package com.org.oracle.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.org.oracle.mysql.dto.TaskAcceptDTO;
import com.org.oracle.mysql.dto.TaskInitDTO;
import com.org.oracle.mysql.entity.Task;

import java.util.List;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/19 下午5:27
 */
public interface TaskService extends IService<Task> {
    /**
     * 用户 加入知识圈 任务初始化
     */
    void taskInit(String uid, TaskInitDTO dto);

    /**
     * 查找用户在该知识圈下的学习任务进度
     */
    List<Task> taskProgress(String uid, String circleId);

    /**
     * 用户接受任务
     *
     * @param uid
     * @param name  任务名称
     * @param state 2:正在挑战
     */
    void taskChallenge(String uid, String name, Integer state);

    /**
     * 用户完成任务
     * @param uid
     * @param dto 任务名称 任务得分
     * @param state 3:已完成
     */
    void taskFinish(String uid, TaskAcceptDTO dto, Integer state);
}
