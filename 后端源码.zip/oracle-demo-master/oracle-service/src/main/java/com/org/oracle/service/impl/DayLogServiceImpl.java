package com.org.oracle.service.impl;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.date.LocalDateTimeUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.google.common.base.Preconditions;
import com.mongodb.internal.time.TimePoint;
import com.org.oracle.constant.DayLogConstants;
import com.org.oracle.enums.ResponseCodeEnum;
import com.org.oracle.exception.CustomException;
import com.org.oracle.mapper.DayLogMapper;
import com.org.oracle.sub.entity.TaskList;
import com.org.oracle.mysql.entity.DayLog;
import com.org.oracle.mysql.entity.Task;
import com.org.oracle.service.DayLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalUnit;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/21 下午5:31
 */
@Service
@Transactional
public class DayLogServiceImpl extends ServiceImpl<DayLogMapper, DayLog> implements DayLogService {

    @Autowired
    private DayLogMapper dayLogMapper;

    /**
     * 查找用户当月的打卡记录
     *
     * @param uid
     * @return
     */
    @Override
    public List<DayLog> findByDate(String uid, Date date) {
        // 判断参数
        Preconditions.checkArgument(StringUtils.isNotBlank(uid) && Objects.nonNull(date), ResponseCodeEnum.PARAM_REQUIRE);
        // 构建条件
        LambdaQueryWrapper<DayLog> wrapper = new LambdaQueryWrapper<>();

        // 查找对应用户
        wrapper.eq(DayLog::getUid, uid);

        // 限定必须是当月的数据
        wrapper.between(DayLog::getDate, DateUtil.beginOfMonth(date), DateUtil.endOfMonth(date));

        return dayLogMapper.selectList(wrapper);
    }



    /**
     * 打卡记录
     *
     * @param taskList
     * @param finish
     */
    @Override
    public void log(TaskList taskList, Integer finish) {
        // 判断参数
        Preconditions.checkArgument(Objects.nonNull(taskList), ResponseCodeEnum.PARAM_REQUIRE);
        Preconditions.checkArgument(DayLogConstants.OVER.equals(finish) || DayLogConstants.NOT_OVER.equals(finish), ResponseCodeEnum.PARAM_INVALID);

        // 因为该方法调用时是在当天凌晨4点，用户的实际操作是在凌晨4点前
        // 如执行方法时间：2024-08-21 04:00
        // 用户都是在 2024-08-20 04:00 ~ 2024-08-21 04:00 进行的操作
        // 所以时间需要减去一天
        LocalDateTime localDateTime = LocalDateTimeUtil.offset(LocalDateTime.now(), -1, ChronoUnit.DAYS);

        // 统计当天得到的积分
        int pointsSum = 0;
        // 如果任务列表不为空，需要统计今日获得的积分
        if (!taskList.getList().isEmpty()) {
            for (Task task : taskList.getList()) {
                pointsSum += task.getPoints();
            }
        }

        // 记录打卡
        DayLog dayLog = DayLog.builder()
                .uid(taskList.getUid())
                .gotPoints(pointsSum)
                .date(localDateTime)
                .isFinish(finish)
                .build();
        dayLogMapper.insert(dayLog);

    }
}
