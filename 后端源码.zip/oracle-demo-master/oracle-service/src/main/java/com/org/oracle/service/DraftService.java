package com.org.oracle.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.org.oracle.mysql.entity.Draft;
import org.springframework.stereotype.Service;

/**
 * @author suze
 * @date 2024/12/11
 * @time 21:13
 **/

public interface DraftService extends IService<Draft> {
}
