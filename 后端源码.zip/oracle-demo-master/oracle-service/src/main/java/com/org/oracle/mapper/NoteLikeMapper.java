package com.org.oracle.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.org.oracle.mysql.entity.NoteLike;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author: heiye
 * @date: 2024/12/11 下午7:36
 * @version: v1.0.0
 * @description: 笔记点赞
 */
@Mapper
public interface NoteLikeMapper extends BaseMapper<NoteLike> {

    /**
     * 新增笔记点赞记录，若已存在，则更新笔记点赞记录
     *
     * @param noteLike
     * @return
     */
    int saveOrUpdate(NoteLike noteLike);
}
