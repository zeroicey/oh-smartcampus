package com.org.oracle.controller;

import com.org.oracle.result.Result;
import com.org.oracle.service.DayLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/21 下午5:24
 */
@RestController
@RequestMapping("/dayLog")
public class DayLogController {

    @Autowired
    private DayLogService dayLogService;

    /**
     * 查找用户该月的打卡记录
     *
     * @param uid
     * @param date 传递过来的日期 当月则传递当前时间 其他月份则传递他们的第一天
     * @return
     */
    @GetMapping("/find")
    public Result findByDate(@RequestHeader String uid, Date date) {
        return Result.ok(dayLogService.findByDate(uid, date));
    }





}
