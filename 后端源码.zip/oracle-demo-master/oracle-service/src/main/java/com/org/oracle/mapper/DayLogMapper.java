package com.org.oracle.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.org.oracle.mysql.entity.DayLog;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author heiye
 * @version 1.0
 * @date 2024/8/21 下午5:32
 */
@Mapper
public interface DayLogMapper extends BaseMapper<DayLog> {
}
