package com.org.oracle.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.org.oracle.sub.entity.TaskList;
import com.org.oracle.mysql.entity.DayLog;

import java.util.Date;
import java.util.List;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/21 下午5:31
 */
public interface DayLogService extends IService<DayLog> {
    /**
     * 查找用户该月的打卡记录
     *
     * @param uid
     * @return
     */
    List<DayLog> findByDate(String uid, Date date);

    /**
     * 打卡记录
     *
     * @param taskList
     * @param finish
     */
    void log(TaskList taskList, Integer finish);
}
