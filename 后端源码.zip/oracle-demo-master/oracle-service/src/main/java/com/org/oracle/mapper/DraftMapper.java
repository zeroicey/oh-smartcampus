package com.org.oracle.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.org.oracle.mysql.entity.Draft;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author suze
 * @date 2024/12/11
 * @time 21:12
 **/
@Mapper
public interface DraftMapper extends BaseMapper<Draft> {
}
