package com.org.oracle.controller;

import com.org.oracle.result.Result;
import com.org.oracle.service.TopicService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/18 下午4:43
 */
@RestController
@RequestMapping("/topic")
public class TopicController {
    @Autowired
    private TopicService topicService;

    /**
     * 查找全部话题AI标签
     */
    @GetMapping("/findAll")
    public Result findAll() {
        return Result.ok(topicService.findAll());
    }

    /**
     * 查找该知识圈的全部话题AI标签
     */
    @GetMapping("/findAllById")
    public Result findAllById(@RequestParam(value = "circleId") String id) {
        return Result.ok(topicService.findAllById(id));
    }
    /**
     * 查找前n条推荐的话题AI标签,前端要给size
     */
    @GetMapping("/findList")
    public Result findGoods(@RequestParam(value = "size") int size) {
        return Result.ok(topicService.findGoods(size));
    }

    /**
     * 权重接口
     */
    @GetMapping("/aiWeight")
    public Result AiWeight(@RequestParam(value = "id") String id, @RequestParam(value = "type") int type) {
        return Result.ok(topicService.updateWeight(id, type));
    }


    /**
     * 根据 知识圈id 查找对应的 话题ai
     */
    @GetMapping("/findTopic")
    public Result findByCircleId(@RequestParam(value = "circleId")String circleId,@RequestParam(value = "size")String size) {
        return Result.ok(topicService.findByCircleId(circleId,size));
    }

    /**
     * @author suze
     * @date 2024-08-29
     * 根据章节去生成对应的话题ai  相当于知识圈初始化的部分
     **/
    @GetMapping("/getAi")
    public Result getAi() {
        return Result.ok(topicService.info());
    }

    /**
     * 查询话题 AI 详情
     *
     * @param id
     * @return
     */
    @GetMapping("/findById/{id}")
    public Result findById(@PathVariable String id) {
        return Result.ok(topicService.findById(id));
    }
}
