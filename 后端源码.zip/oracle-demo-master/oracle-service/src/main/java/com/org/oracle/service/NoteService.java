package com.org.oracle.service;

import com.org.oracle.mongodb.dto.CircleQueryBatchDTO;
import com.org.oracle.mongodb.entity.CircleContext;
import com.org.oracle.mongodb.vo.NoteVO;
import com.org.oracle.mongodb.vo.NoteSimpleVO;
import com.org.oracle.mysql.dto.CollectNoteDTO;
import com.org.oracle.mysql.dto.LikeNoteDTO;
import com.org.oracle.mysql.dto.UnCollectNoteDTO;
import com.org.oracle.mysql.dto.UnLikeNoteDTO;
import com.org.oracle.result.PageResult;
import com.org.oracle.sub.dto.PageRequestDTO;

/**
 * @author: heiye
 * @date: 2024/12/18 下午1:45
 * @version: v1.0.0
 * @description: 笔记
 */
public interface NoteService {


    CircleContext send_note(String uid, CircleContext circleContext);

    /**
     * 批量查询笔记
     *
     * @param dto
     * @return
     */
    PageResult<NoteSimpleVO> queryBatch(CircleQueryBatchDTO dto);

    NoteVO queryOne(String uid, String noteId);

    CircleContext save_note(String uid, CircleContext circleContext);

    PageResult<NoteSimpleVO> get_save_note(String uid, PageRequestDTO pageRequestDTO);
    CircleContext get_save_note_one(String uid,String noteId);

    PageResult<NoteSimpleVO> find_note(String uid, PageRequestDTO pageRequestDTO);

    /**
     * 点赞笔记
     *
     * @param uid
     * @param likeNoteDTO
     * @return
     */
    void likeNote(String uid, LikeNoteDTO likeNoteDTO);

    /**
     * 取消点赞笔记
     *
     * @param uid
     * @param unLikeNoteDTO
     */
    void unlikeNote(String uid, UnLikeNoteDTO unLikeNoteDTO);

    /**
     * 收藏笔记
     *
     * @param uid
     * @param collectNoteDTO
     */
    void collectNote(String uid, CollectNoteDTO collectNoteDTO);

    /**
     * 取消收藏笔记
     *
     * @param uid
     * @param unCollectNoteDTO
     */
    void unCollectNote(String uid, UnCollectNoteDTO unCollectNoteDTO);

    /**
     * 查询用户收藏过的笔记
     *
     * @param uid
     * @param pageRequestDTO
     * @return
     */
    PageResult<NoteSimpleVO> findUserCollectedNote(String uid, PageRequestDTO pageRequestDTO);
}
