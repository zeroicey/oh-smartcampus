//package com.org.oracle.config;
//
//import cn.dev33.satoken.context.SaHolder;
//import cn.dev33.satoken.exception.NotLoginException;
//import cn.dev33.satoken.exception.NotPermissionException;
//import cn.dev33.satoken.exception.NotRoleException;
//import cn.dev33.satoken.exception.SaTokenException;
//import cn.dev33.satoken.filter.SaServletFilter;
//import cn.dev33.satoken.router.SaRouter;
//import cn.dev33.satoken.stp.StpUtil;
//import cn.dev33.satoken.util.SaResult;
//import cn.hutool.json.JSONUtil;
//import com.org.oracle.enums.ResponseCodeEnum;
//import com.org.oracle.result.Result;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
///**
// * @author: heiye
// * @date: 2024/10/11 上午10:42
// * @version: v1.0.0
// * @description: [Sa-Token 权限认证] 配置类
// */
//@Slf4j
//@Configuration
//public class SaTokenConfig {
//    /**
//     * 注册 [Sa-Token全局过滤器]
//     */
//    @Bean
//    public SaServletFilter getSaServletFilter() {
//        return new SaServletFilter()
//                // 指定 拦截路由 与 放行路由
//                .addInclude("/**")
//                // 认证函数: 每次请求执行
//                .setAuth(obj -> {
//                    log.info("==================> SaServletFilter, Path: {}", SaHolder.getRequest().getRequestPath());
//
//// ======================== 拦截所有路由 ========================
//                    SaRouter.match("/**")
//// ========================  认证服务  =========================
//
//                            // 发送邮箱验证码
//                            .notMatch("/send/email")
//                            // 邮箱验证码校验
//                            .notMatch("/check/email")
//
//// ========================  笔记服务  =========================
//
//                            // 查询笔记详情
//                            .notMatch("/note/queryById")
//                            // 根据知识圈ID和话题ID批量查询笔记
//                            .notMatch("/note/queryBatch")
//
//// ========================  用户服务  =========================
//
//                            // 注册
//                            .notMatch("/user/register")
//                            // 登录
//                            .notMatch("/user/login")
//                            // 忘记密码
//                            .notMatch("/user/forgotPassword")
//                            // 查询笔记作者的详情信息
//                            .notMatch("/user/findUserDetailById")
//
//                            // 校验是否登录
//                            .check(r -> StpUtil.checkLogin());
//
//                })
//                // 手动抛出异常
//                .setError(e -> {
//                    log.error("==================> SaServletFilter, catchError: {}", e.getMessage());
//                    // 未登录异常
//                    if (e instanceof NotLoginException) {
//                        return JSONUtil.toJsonStr(Result.fail(e.getMessage(), ResponseCodeEnum.TOKEN_INVALID.getCode()));
//                    }
//                    // 权限不足，或不具备角色，统一抛出权限不足异常
//                    else if (e instanceof NotPermissionException || e instanceof NotRoleException) {
//                        return JSONUtil.toJsonStr(Result.fail(e.getMessage(), ((SaTokenException) e).getCode()));
//                    }
//                    // 其他异常，则抛出一个运行时异常
//                    else {
//                        return JSONUtil.toJsonStr(Result.fail(e.getMessage(), ResponseCodeEnum.SERVER_ERROR.getCode()));
//                    }
//                });
//    }
//}
//
