package com.org.oracle.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.org.oracle.mysql.entity.UserQuestionProgress;


/**
 * (UserQuestionProgress)表数据库访问层
 *
 * @author luo
 * @since 2024-12-18 20:37:44
 */
public interface UserQuestionProgressMapper extends BaseMapper<UserQuestionProgress> {

}

