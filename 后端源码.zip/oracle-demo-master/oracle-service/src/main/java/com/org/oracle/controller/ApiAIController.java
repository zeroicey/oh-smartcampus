package com.org.oracle.controller;

import com.org.oracle.mongodb.entity.DeepSeekChatRecord;
import com.org.oracle.service.DeepSeekChatService;
import jakarta.annotation.Resource;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;

import java.time.LocalDate;
import java.util.List;

import static org.springframework.ai.chat.client.advisor.AbstractChatMemoryAdvisor.CHAT_MEMORY_RETRIEVE_SIZE_KEY;

@RestController
@RequestMapping("/deepseek")
public class ApiAIController {
    ChatClient chatClient;
    @Resource
    private DeepSeekChatService chatService;

    public ApiAIController(ChatClient.Builder chatClientBuilder){
        this.chatClient = chatClientBuilder.build();
    }

    @CrossOrigin
    @GetMapping(value = "/testChat01")
    public String testChat(@RequestParam(value = "message", defaultValue = "你是谁？你是哪一家公司开发的？") String message){
        String content = chatClient.prompt()
                .system(s -> s.param("current_date", LocalDate.now().toString()))
                .user(message)
                .call()
                .content();
        return content;
    }
    @CrossOrigin
    @GetMapping(value = "/generateStreamAsString", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<String> generateStreamAsString(@RequestParam(value = "message", defaultValue = "讲个笑话") String message) {
        //Prompt prompt = new Prompt(new UserMessage(message));
        //return chatClient.stream(prompt);
        Flux<String> content = chatClient.prompt()
                .system(s -> s.param("current_date", LocalDate.now().toString()))
                //.advisors(a -> a.param(CHAT_MEMORY_CONVERSATION_ID_KEY, chatId).param(CHAT_MEMORY_RETRIEVE_SIZE_KEY, 100))
                .advisors(a -> a.param(CHAT_MEMORY_RETRIEVE_SIZE_KEY, 100))
                .user(message)
                .stream()
                .content();

        return  content
                .concatWith(Flux.just("[complete]"));

    }
    @GetMapping(value = "/chat", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<ServerSentEvent<String>> streamChat(
            @RequestParam String userId,
            @RequestParam String message) {
        return chatService.streamChat(userId, message)
                .map(content -> ServerSentEvent.builder(content).build())
                .onErrorResume(e -> Flux.just(
                        ServerSentEvent.builder("服务异常: " + e.getMessage()).build()
                ));
    }

    @GetMapping("/history")
    public ResponseEntity<List<DeepSeekChatRecord>> getHistory(
            @RequestParam String userId) {
        return ResponseEntity.ok(chatService.getChatHistory(userId));
    }
}