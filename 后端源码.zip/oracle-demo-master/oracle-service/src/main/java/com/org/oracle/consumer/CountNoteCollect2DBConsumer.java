package com.org.oracle.consumer;

import cn.hutool.core.collection.CollUtil;
import com.google.common.util.concurrent.RateLimiter;
import com.org.oracle.constant.MQConstants;
import com.org.oracle.mapper.NoteCountMapper;
import com.org.oracle.mapper.UserCountMapper;
import com.org.oracle.mysql.dto.AggregationCountCollectUnCollectNoteMqDTO;
import com.org.oracle.util.JsonUtils;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.spring.annotation.ConsumeMode;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.List;
import java.util.Map;

/**
 * @author: heiye
 * @date: 2024/12/15 下午7:32
 * @version: v1.0.0
 * @description: 计数: 笔记收藏数落库
 */
@Slf4j
@Component
@RocketMQMessageListener(
        // Group 组
        consumerGroup = "oracle_group_" + MQConstants.TOPIC_COUNT_NOTE_COLLECT_2_DB,
        // 消费的主题 Topic
        topic = MQConstants.TOPIC_COUNT_NOTE_COLLECT_2_DB
)
public class CountNoteCollect2DBConsumer implements RocketMQListener<String> {

    // 每秒创建 5000 个令牌
    private RateLimiter rateLimiter = RateLimiter.create(5000);

    @Resource
    private NoteCountMapper noteCountMapper;

    @Resource
    private UserCountMapper userCountMapper;

    @Resource
    private TransactionTemplate transactionTemplate;

    @Override
    public void onMessage(String body) {
        // 流量削峰：通过获取令牌，如果没有令牌可用，将阻塞，直到获得
        rateLimiter.acquire();

        log.info("## 消费到了 MQ 【计数: 笔记收藏数入库】, {}...", body);

        List<AggregationCountCollectUnCollectNoteMqDTO> countList = null;
        try {
            countList = JsonUtils.parseList(body, AggregationCountCollectUnCollectNoteMqDTO.class);
        } catch (Exception e) {
            log.error("## 解析 JSON 字符串异常", e);
        }

        if (CollUtil.isNotEmpty(countList)) {
            // 判断数据库中 note_count 表，若笔记计数记录不存在，则插入；若记录已存在，则直接更新
            countList.forEach(item -> {
                Integer count = item.getCount();
                String noteId = item.getNoteId();
                String creatorId = item.getCreatorId();

                // 编程式事务，保证两条语句的原子性
                transactionTemplate.execute(status -> {
                    try {
                        noteCountMapper.insertOrUpdateCollectTotalByNoteId(count, noteId);
                        userCountMapper.insertOrUpdateCollectTotalByUserId(count, creatorId);
                        return true;
                    } catch (Exception e) {
                        // 标记事务为回滚
                        status.setRollbackOnly();
                        log.error("## 【计数服务：笔记收藏数和用户获得收藏数入库失败】", e);
                        return false;
                    }
                });

            });
        }
    }
}
