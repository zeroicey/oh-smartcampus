package com.org.oracle.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.org.oracle.mysql.entity.Subjects;


/**
 * (Subjects)表数据库访问层
 *
 * @author luo
 * @since 2024-12-02 09:35:53
 */
public interface SubjectsMapper extends BaseMapper<Subjects> {

}

