package com.org.oracle.service;

import com.org.oracle.mysql.entity.Questions;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * @author: heiye
 * @date: 2024/11/21 下午1:36
 * @version: v1.0.0
 * @description: TODO
 */
public interface FileService {

    /**
     * 上传图片
     *
     * @param image
     * @return
     */
    String uploadImg(MultipartFile image);

    List<Questions> parseCsv(String tempFilePath);

    List<Questions> parseExcel(String tempFilePath);
}
