package com.org.oracle.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.org.oracle.mapper.SubjectsMapper;
import com.org.oracle.mysql.entity.Subjects;
import com.org.oracle.mysql.vo.SubjectVo;
import com.org.oracle.result.Result;
import com.org.oracle.service.SubjectsService;
import com.org.oracle.util.BeanCopyUtils;
import org.checkerframework.checker.units.qual.A;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.awt.desktop.QuitEvent;
import java.util.List;

/**
 * (Subjects)表服务实现类
 *
 * @author luo
 * @since 2024-12-02 09:35:59
 */
@Service("subjectsService")
public class SubjectsServiceImpl extends ServiceImpl<SubjectsMapper, Subjects> implements SubjectsService {

    @Autowired
    private SubjectsMapper subjectsMapper;

    @Override
    public String getSubjectIdByName(String subjectName) {
        LambdaQueryWrapper<Subjects> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Subjects::getName,subjectName);
        Subjects subject = subjectsMapper.selectOne(queryWrapper);
        if(subject == null){
            throw new RuntimeException("无法找到科目名称: "+subjectName+" 对应的科目ID。");
        }
        return subject.getId().toString();
    }

    /**
     * 获取所有科目
     * @return 所有科目
     */
    @Override
    public List<Subjects> getAllSubjects() {
        return list();
    }

    @Override
    public Result getAllSubject() {
        List<Subjects> subjects = getAllSubjects();
        List<SubjectVo> subjectVos = BeanCopyUtils.copyBeanList(subjects, SubjectVo.class);
        return Result.ok(subjectVos);
    }
}

