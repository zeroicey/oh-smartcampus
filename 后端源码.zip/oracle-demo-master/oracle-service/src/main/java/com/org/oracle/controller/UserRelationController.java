package com.org.oracle.controller;

import com.org.oracle.mysql.dto.FollowUserDTO;
import com.org.oracle.mysql.dto.UnfollowUserDTO;
import com.org.oracle.result.Result;
import com.org.oracle.service.UserRelationService;
import jakarta.annotation.Resource;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * @author: heiye
 * @date: 2024/12/20 上午11:35
 * @version: v1.0.0
 * @description: 用户关系
 */
@RestController
@RequestMapping("/relation")
public class UserRelationController {

    @Resource
    private UserRelationService userRelationService;

    /**
     * 关注用户
     *
     * @param uid
     * @param followUserDTO
     * @return
     */
    @PostMapping("/follow")
    public Result follow(@RequestHeader String uid, @Validated @RequestBody FollowUserDTO followUserDTO) {
        userRelationService.follow(uid, followUserDTO);
        return Result.ok();
    }

    /**
     * 取关用户
     *
     * @param uid
     * @param unFollowUserDTO
     * @return
     */
    @PostMapping("/unfollow")
    public Result unfollow(@RequestHeader String uid, @Validated @RequestBody UnfollowUserDTO unFollowUserDTO) {
        userRelationService.unfollow(uid, unFollowUserDTO);
        return Result.ok();
    }
}
