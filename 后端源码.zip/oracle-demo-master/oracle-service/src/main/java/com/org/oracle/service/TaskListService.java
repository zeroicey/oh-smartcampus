package com.org.oracle.service;

import com.org.oracle.sub.entity.TaskList;
import com.org.oracle.mysql.entity.Task;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/19 下午10:36
 */
public interface TaskListService {
    /**
     * 添加任务到当日的表单中
     *
     * @param uid
     * @param task
     */
    void taskAdd(String uid, Task task);

    /**
     * 查找用户任务列表
     *
     * @param uid
     * @return
     */
    TaskList findByUid(String uid);

    /**
     * 将用户每日任务修改为完成
     *
     * @param uid
     * @param task 需要修改的任务
     */
    void taskFinish(String uid, Task task);

    /**
     * 查询用户是否能点击打卡按钮
     *
     * @param uid
     * @return
     */
    Integer check(String uid);

    /**
     * 用户手动打卡
     *
     * @param uid
     */
    void press(String uid);

    Long getDay(String uid);

    Long getMDay(String uid);
}
