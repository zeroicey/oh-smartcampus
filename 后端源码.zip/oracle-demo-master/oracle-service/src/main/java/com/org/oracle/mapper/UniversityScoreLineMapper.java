package com.org.oracle.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.org.oracle.mysql.entity.UniversityScoreLine;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.lettuce.core.dynamic.annotation.Param;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/***
 * @title UniversityScoreLineMapper
 * @author SUZE
 * @Date 15:38
 **/
@Mapper
public interface UniversityScoreLineMapper extends BaseMapper<UniversityScoreLine> {
    /**
     * 根据范围搜索查询大学分数线信息列表，并支持分页
     *
     * @param page           分页对象
     * @param region         地区
     * @param secondaryMajor 二级专业
     * @param tertiaryMajor  三级专业
     * @return 符合条件的大学分数线信息列表
     */
    @Select("SELECT * FROM university_score_line " +
            "WHERE (#{region} IS NULL OR region = #{region}) " +
            "AND (#{secondaryMajor} IS NULL OR secondary_major = #{secondaryMajor}) " +
            "AND (#{tertiaryMajor} IS NULL OR tertiary_major = #{tertiaryMajor}) " )
    List<UniversityScoreLine> findRangeSearch(Page<UniversityScoreLine> page,
                                              @Param("region") String region,
                                              @Param("secondaryMajor") String secondaryMajor,
                                              @Param("tertiaryMajor") String tertiaryMajor);

    /**
     * 根据学校名称查询大学分数线信息列表，并支持分页
     *
     * @param page 分页对象
     * @param school 学校名称
     * @return 符合条件的大学分数线信息列表
     */
    @Select("SELECT * FROM university_score_line WHERE school like CONCAT('%', #{school}, '%')")
    List<UniversityScoreLine> findBySchool(Page<UniversityScoreLine> page, @Param("school") String school);
}
