package com.org.oracle.service;

import com.org.oracle.mongodb.dto.PointsListDTO;
import com.org.oracle.sub.vo.UserPointsVO;

import java.util.List;

/**
 * @Author: heiye
 * @CreateTime: 2024/08/29 下午2:33
 * @Description: 学习积分榜Service
 * @Version: 1.0
 */
public interface StudyPointsListService {
    /**
     * 用户加入知识圈后初始化任务库后加入学习积分榜
     *
     * @param uid
     */
    void pointsInit(String uid, String circleId);

    /**
     * 用户完成任务后更新榜单
     *
     * @param uid
     * @param circleId
     * @param points
     */
    void pointsUpdate(String uid, String circleId, Integer points);

    /**
     * 查找榜单的积分排名
     *
     * @param dto
     * @return
     */
    List<UserPointsVO> findPointsList(PointsListDTO dto);

    /**
     * 在学习积分榜单里查找到用户的积分
     *
     * @param uid
     * @param dto
     * @return
     */
    UserPointsVO findUserPoints(String uid, PointsListDTO dto);
}
