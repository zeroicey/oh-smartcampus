package com.org.oracle.controller;

import com.org.oracle.constant.TaskConstants;
import com.org.oracle.mysql.dto.TaskAcceptDTO;
import com.org.oracle.result.Result;
import com.org.oracle.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/19 下午5:16
 */
@RestController
@RequestMapping("/task")
public class TaskController {
    @Autowired
    private TaskService taskService;

    /**
     * 查找用户在该知识圈下的学习任务进度
     */
    @GetMapping("/progress")
    public Result taskProgress(@RequestHeader String uid, String circleId) {
        return Result.ok(taskService.taskProgress(uid, circleId));
    }

    /**
     * 用户接受任务
     */
    @PutMapping("/challenge")
    public Result taskChallenge(@RequestHeader String uid, String name) {
        taskService.taskChallenge(uid, name, TaskConstants.CHALLENGED);
        return Result.ok();
    }

    /**
     * 用户完成任务
     */
    @PutMapping("/finish")
    public Result taskFinish(@RequestHeader String uid, @RequestBody TaskAcceptDTO dto) {
        taskService.taskFinish(uid, dto, TaskConstants.CHALLENGE_ACCOMPLISHED);
        return Result.ok();
    }
}
