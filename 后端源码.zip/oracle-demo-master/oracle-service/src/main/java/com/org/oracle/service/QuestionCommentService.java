package com.org.oracle.service;

import com.org.oracle.mongodb.entity.QuestionComment;

import java.util.List;

public interface QuestionCommentService {
    List<QuestionComment> getCommentsByQuestionId(String questionId);
}
