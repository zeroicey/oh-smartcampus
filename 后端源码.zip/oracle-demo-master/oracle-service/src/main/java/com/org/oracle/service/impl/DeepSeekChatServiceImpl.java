package com.org.oracle.service.impl;

import com.org.oracle.mongodb.entity.DeepSeekChatRecord;
import com.org.oracle.mongodb.entity.DeepSeekMessage;
import com.org.oracle.mongodb.entity.UserChatSession;
import com.org.oracle.service.DeepSeekChatRepository;
import com.org.oracle.service.DeepSeekChatService;
import com.org.oracle.service.UserChatSessionRepository;
import com.org.oracle.sub.entity.Message;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class DeepSeekChatServiceImpl implements DeepSeekChatService {
    private final DeepSeekChatRepository chatRepository;
    private final ChatClient.Builder chatClientBuilder;

    @Override
    public Flux<String> streamChat(String userId, String userInput) {
        // 初始化包含用户消息的记录
        DeepSeekChatRecord record = DeepSeekChatRecord.builder()
                .userId(userId)
                .messages(new ArrayList<>(List.of(new Message("user", userInput))))
                .createdAt(LocalDateTime.now())
                .build();

        // 保存初始记录并获取ID
        DeepSeekChatRecord savedRecord = chatRepository.save(record);
        StringBuilder aiContent = new StringBuilder();

        return chatClientBuilder.build()
                .prompt()
                .user(userInput)
                .stream()
                .content()
                .concatMap(content -> {
                    aiContent.append(content);
                    return Mono.just(content); // 保持实时流式传输
                })
                .doOnComplete(() -> {
                    // 流结束时添加完整AI消息
                    savedRecord.getMessages().add(
                            new Message("assistant", aiContent.toString())
                    );
                    chatRepository.save(savedRecord); // 最终持久化
                });
    }

    @Override
    public List<DeepSeekChatRecord> getChatHistory(String userId) {
        return chatRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }
}
