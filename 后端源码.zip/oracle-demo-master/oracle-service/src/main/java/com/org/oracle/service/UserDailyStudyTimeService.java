package com.org.oracle.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.org.oracle.mysql.entity.UserDailyStudyTime;
import com.org.oracle.result.Result;


/**
 * (UserDailyStudyTime)表服务接口
 *
 * @author luo
 * @since 2024-12-16 21:22:13
 */
public interface UserDailyStudyTimeService extends IService<UserDailyStudyTime> {


    Result getTotalStudyTimeInMinutes(String uid);

    Result getTodayStudyTimeInMinutes(String uid);
}

