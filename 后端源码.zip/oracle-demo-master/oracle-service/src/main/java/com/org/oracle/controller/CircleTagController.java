package com.org.oracle.controller;

import com.org.oracle.result.Result;
import com.org.oracle.service.CircleTagService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author: heiye
 * @date: 2024/11/14 下午3:01
 * @version: v1.0.0
 * @description: 知识圈标签接口
 */
@RestController
@RequestMapping("/circleTag")
public class CircleTagController {

    @Resource
    private CircleTagService circleTagService;

    /**
     * 查找全部标签
     *
     * @return
     */
    @GetMapping("/findAll")
    public Result findAll() {
        return Result.ok(circleTagService.findAll());
    }
}
