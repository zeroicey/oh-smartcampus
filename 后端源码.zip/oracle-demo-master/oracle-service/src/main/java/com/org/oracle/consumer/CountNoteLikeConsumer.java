package com.org.oracle.consumer;

import com.github.phantomthief.collection.BufferTrigger;
import com.google.common.collect.Maps;
import com.org.oracle.constant.MQConstants;
import com.org.oracle.constant.RedisKeyConstants;
import com.org.oracle.enums.LikeUnlikeNoteTypeEnum;
import com.org.oracle.mysql.dto.AggregationCountLikeUnlikeNoteMqDTO;
import com.org.oracle.mysql.dto.LikeUnlikeNoteMqDTO;
import com.org.oracle.util.JsonUtils;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.utils.Lists;
import org.apache.rocketmq.client.producer.SendCallback;
import org.apache.rocketmq.client.producer.SendResult;
import org.apache.rocketmq.spring.annotation.ConsumeMode;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author: heiye
 * @date: 2024/12/13 下午1:13
 * @version: v1.0.0
 * @description: 计数: 笔记点赞数
 */
@Slf4j
@Component
@RocketMQMessageListener(
        // Group 组
        consumerGroup = "oracle_group_" + MQConstants.TOPIC_COUNT_NOTE_LIKE,
        // 消费的主题 Topic
        topic = MQConstants.TOPIC_COUNT_NOTE_LIKE
)
public class CountNoteLikeConsumer implements RocketMQListener<String> {

    @Resource
    private RedisTemplate<String, Object> redisTemplate;

    @Resource
    private RocketMQTemplate rocketMQTemplate;

    private BufferTrigger<String> bufferTrigger = BufferTrigger.<String>batchBlocking()
            // 缓冲队列的最大容量
            .bufferSize(50000)
            // 一批次最多聚合 1000 条
            .batchSize(1000)
            // 多久聚合一次
            .linger(Duration.ofSeconds(1))
            // 设置消费者方法
            .setConsumerEx(this::consumeMessage)
            .build();

    @Override
    public void onMessage(String body) {
        // 往 bufferTrigger 中添加元素
        bufferTrigger.enqueue(body);
    }

    private void consumeMessage(List<String> bodys) {
        log.info("==> 【笔记点赞数】聚合消息, size: {}", bodys.size());
        log.info("==> 【笔记点赞数】聚合消息, {}", JsonUtils.toJsonString(bodys));

        // List<String> 转 List<LikeUnlikeNoteMqDTO>
        List<LikeUnlikeNoteMqDTO> likeUnlikeNoteMqDTOS = bodys.stream()
                .map(body -> JsonUtils.parseObject(body, LikeUnlikeNoteMqDTO.class)).toList();

        // 按笔记 ID 进行分组
        Map<String, List<LikeUnlikeNoteMqDTO>> groupMap = likeUnlikeNoteMqDTOS.stream()
                .collect(Collectors.groupingBy(LikeUnlikeNoteMqDTO::getNoteId));

        // 按组汇总数据，统计出最终的计数
        // 最终操作的计数对象
        List<AggregationCountLikeUnlikeNoteMqDTO> countList = Lists.newArrayList();

        for (Map.Entry<String, List<LikeUnlikeNoteMqDTO>> entry : groupMap.entrySet()) {
            List<LikeUnlikeNoteMqDTO> list = entry.getValue();
            // 笔记ID
            String noteId = entry.getKey();
            // 笔记作者ID
            String creatorId = null;
            // 最终的计数值，默认为 0
            int finalCount = 0;
            for (LikeUnlikeNoteMqDTO likeUnlikeNoteMqDTO : list) {
                // 获取操作类型
                Integer type = likeUnlikeNoteMqDTO.getType();
                // 设置笔记发布者用户 ID
                creatorId = likeUnlikeNoteMqDTO.getNoteCreatorId();

                // 根据操作类型，获取对应枚举
                LikeUnlikeNoteTypeEnum likeUnlikeNoteTypeEnum = LikeUnlikeNoteTypeEnum.valueOf(type);

                // 若枚举为空，跳到下一次循环
                if (Objects.isNull(likeUnlikeNoteTypeEnum)) {
                    continue;
                }

                switch (likeUnlikeNoteTypeEnum) {
                    // 如果为点赞操作，点赞数 +1
                    case LIKE -> finalCount += 1;
                    // 如果为取消点赞操作，点赞数 -1
                    case UNLIKE -> finalCount -= 1;
                }
            }
            // 将分组后统计出的最终计数，存入 countList 中
            countList.add(AggregationCountLikeUnlikeNoteMqDTO.builder()
                    .noteId(noteId)
                    .creatorId(creatorId)
                    .count(finalCount)
                    .build());
        }

        log.info("## 【笔记点赞数】聚合后的计数数据: {}", JsonUtils.toJsonString(countList));

        countList.forEach(item -> {
            // 笔记 ID
            String noteId = item.getNoteId();
            // 笔记发布者 ID
            String creatorId = item.getCreatorId();
            // 聚合后的计数
            Integer count = item.getCount();

            // Redis Key
            String countNoteRedisKey = RedisKeyConstants.buildCountNoteKey(noteId);
            // 判断 Redis 中 Hash 是否存在
            Boolean isCountNoteExisted  = redisTemplate.hasKey(countNoteRedisKey);

            // 若存在才会更新
            // (因为缓存设有过期时间，考虑到过期后，缓存会被删除，这里需要判断下，存在才会去更新，而初始化工作放在查询计数来做)
            if (isCountNoteExisted ) {
                // 对目标用户 Hash 中点赞数字段进行计数操作
                redisTemplate.opsForHash().increment(countNoteRedisKey, RedisKeyConstants.FIELD_LIKE_TOTAL, count);
            }

            // 更新 Redis 用户维度点赞数
            String countUserKey = RedisKeyConstants.buildCountUserKey(creatorId);
            Boolean isCountUserExisted = redisTemplate.hasKey(countUserKey);
            if (isCountUserExisted ) {
                redisTemplate.opsForHash().increment(countUserKey, RedisKeyConstants.FIELD_LIKE_TOTAL, count);
            }
        });

        // 发送 MQ, 笔记点赞数据落库
        Message<String> message = MessageBuilder.withPayload(JsonUtils.toJsonString(countList))
                .build();

        // 异步发送 MQ 消息
        rocketMQTemplate.asyncSend(MQConstants.TOPIC_COUNT_NOTE_LIKE_2_DB, message, new SendCallback() {
            @Override
            public void onSuccess(SendResult sendResult) {
                log.info("==> 【计数服务：笔记点赞数入库】MQ 发送成功，SendResult: {}", sendResult);
            }

            @Override
            public void onException(Throwable throwable) {
                log.error("==> 【计数服务：笔记点赞数入库】MQ 发送异常: ", throwable);
            }
        });
    }
}
