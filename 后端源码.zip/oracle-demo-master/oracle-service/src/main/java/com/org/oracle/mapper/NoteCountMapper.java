package com.org.oracle.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.org.oracle.mysql.entity.NoteCount;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @author: heiye
 * @date: 2024/12/13 下午3:16
 * @version: v1.0.0
 * @description: 笔记计数
 */
@Mapper
public interface NoteCountMapper extends BaseMapper<NoteCount> {
    /**
     * 添加笔记计数记录或更新笔记点赞数
     *
     * @param count
     * @param noteId
     * @return
     */
    int insertOrUpdateLikeTotalByNoteId(@Param("count") Integer count, @Param("noteId") String noteId);

    /**
     * 添加记录或更新笔记收藏数
     *
     * @param count
     * @param noteId
     * @return
     */
    int insertOrUpdateCollectTotalByNoteId(@Param("count") Integer count, @Param("noteId") String noteId);
    /**
     * 查询笔记的点赞数
     *
     * @param noteId 笔记ID
     * @return 笔记点赞数
     */
    int selectLikeTotalByNoteId(@Param("noteId") String noteId);

    /**
     * 查询笔记的收藏数
     *
     * @param noteId 笔记ID
     * @return 笔记收藏数
     */
    int selectCollectTotalByNoteId(@Param("noteId") String noteId);



}
