package com.org.oracle.service;

import com.org.oracle.mysql.vo.NoteCountVO;
import com.org.oracle.mysql.vo.NoteLikeTotalVO;
import com.org.oracle.mysql.vo.UserCountVO;

import java.util.List;

/**
 * @author: heiye
 * @date: 2024/12/11 下午6:25
 * @version: v1.0.0
 * @description: 计数服务
 */
public interface CountService {
    /**
     * 根据用户 ID 查询用户的计数信息
     * @param uid
     * @return
     */
    UserCountVO findUserCount(String uid);


    /**
     * 批量查询笔记被点赞的数量
     *
     * @param ids
     * @return
     */
    List<NoteLikeTotalVO> findNoteLikeTotalByNoteIds(List<String> ids);

    /**
     * 根据笔记 ID 查询笔记计数信息
     * @param noteId
     * @return
     */
    NoteCountVO findNoteCountByNoteId(String noteId);
}
