package com.org.oracle.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.org.oracle.mysql.entity.UserDailyStudyTime;


/**
 * (UserDailyStudyTime)表数据库访问层
 *
 * @author luo
 * @since 2024-12-16 21:22:13
 */
public interface UserDailyStudyTimeMapper extends BaseMapper<UserDailyStudyTime> {

}

