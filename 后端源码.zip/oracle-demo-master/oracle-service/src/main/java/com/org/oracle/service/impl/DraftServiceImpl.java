package com.org.oracle.service.impl;/**
 * @author suze
 * @date 2024/12/11
 * @time 21:13
 **/

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.org.oracle.mapper.DraftMapper;
import com.org.oracle.mysql.entity.Draft;
import com.org.oracle.service.DraftService;
import org.springframework.stereotype.Service;

/**
 * @Author SuZe
 * @Description 草稿实现类
 * @Date $ $
 * @Param $
 * @return $
 */
@Service
public class DraftServiceImpl extends ServiceImpl<DraftMapper, Draft> implements DraftService {
}
