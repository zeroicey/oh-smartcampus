package com.org.oracle.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.org.oracle.mysql.entity.UniversityScoreDistribution;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

   /***
    * @title UniversityScoreDistributionMapper
    * @author SUZE
    * @Date 15:38
    **/
   @Mapper
   public interface UniversityScoreDistributionMapper extends BaseMapper<UniversityScoreDistribution> {

       @Select("SELECT * FROM university_score_distribution " +
               "WHERE (#{school} IS NULL OR school = #{school}) " +
               "AND (#{faculty} IS NULL OR faculty = #{faculty}) " +
               "AND (#{secondaryMajor} IS NULL OR secondary_major = #{secondaryMajor}) " +
               "AND (#{tertiaryMajor} IS NULL OR tertiary_major = #{tertiaryMajor})")
       List<UniversityScoreDistribution> findByFields(
               @Param("school") String school,
               @Param("faculty") String faculty,
               @Param("secondaryMajor") String secondaryMajor,
               @Param("tertiaryMajor") String tertiaryMajor);
   }

