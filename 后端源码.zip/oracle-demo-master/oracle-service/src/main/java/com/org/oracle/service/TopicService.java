package com.org.oracle.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.org.oracle.mysql.entity.Topic;
import com.org.oracle.mysql.vo.HistoryTopicVO;
import com.org.oracle.mysql.vo.TopicVO;

import java.util.List;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/18 下午4:46
 */
public interface TopicService extends IService<Topic> {

    /**
     * 查找全部话题AI标签
     *
     * @return
     */
    List<TopicVO> findAll();

    /**
     * 根据 知识圈id 查找对应的 话题ai
     *
     * @param circleId
     * @return
     */
    List<TopicVO> findByCircleId(String circleId,String size);

    List<Topic> info();

    List<TopicVO> findGoods(int size);

    Object updateWeight(String id, int type);

    /**
     * 查询话题 AI 详情
     *
     * @param id
     * @return
     */
    Topic findById(String id);

    TopicVO findTopicById(String id);

    List<TopicVO> findAllById(String id);

    HistoryTopicVO findHistoryVOById(String topicId);
}
