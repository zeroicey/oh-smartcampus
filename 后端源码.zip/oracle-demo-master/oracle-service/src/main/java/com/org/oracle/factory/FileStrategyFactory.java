package com.org.oracle.factory;

import com.org.oracle.strategy.FileStrategy;
import com.org.oracle.strategy.impl.AliyunOSSFileStrategy;
import com.org.oracle.strategy.impl.GiteeFileStrategy;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author: heiye
 * @date: 2024/11/21 下午1:34
 * @version: v1.0.0
 * @description: 策略模式 + 工厂模式：实现文件处理可扩展
 *               策略模式: 定义一组算法类，将每个算法分别封装，让它们可以互相替代，属于行为型设计模式的一种。
 *               而工厂模式则属于创建型设计模式的一种，用于解耦对象的创建和使用
 *               注意：当有多个策略时，如果需要实现只要改改配置文件就能更新策略的话，需
 *                    要更新项目为 spring could 并整合 Nacos 后使用 @RefreshScope 注解
 *                    就可以实现实时更新文件策略
 */
@Configuration
public class FileStrategyFactory {

    @Value("${storage.type}")
    private String strategyType;

    @Bean
    public FileStrategy getFileStrategy() {
        if (StringUtils.equals(strategyType, "gitee")) {
            return new GiteeFileStrategy();
        } else if (StringUtils.equals(strategyType, "aliyun")) {
            return new AliyunOSSFileStrategy();
        }

        throw new IllegalArgumentException("不可用的存储类型");
    }
}