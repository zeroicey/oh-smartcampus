package com.org.oracle.helper;

import com.org.oracle.factory.ByteArrayOutputStreamFactory;
import jakarta.annotation.Resource;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import net.coobird.thumbnailator.Thumbnails;
import org.apache.commons.pool2.ObjectPool;

import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayOutputStream;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @author: heiye
 * @date: 2024/12/21 下午9:45
 * @version: v1.0.0
 * @description: 图片处理
 */
@Slf4j
@Component
public class ImageHelper {

    // 图片最大为 1 MB
//    private static final int MAX_FILE_SIZE = 1024 * 1024;
    private static final int MAX_FILE_SIZE = 200 * 1024;

    // TODO 有 BUG 别用！！！！！！等我再学一学
//    @Resource
//    private ObjectPool<ByteArrayOutputStream> byteArrayOutputStreamObjectPool;

    /**
     * 图片压缩为 1 MB 以下
     *
     * @param image
     * @return
     */
    @SneakyThrows
    public MultipartFile compressImage(MultipartFile image) {
        // 获取压缩后的图片字节数组
        byte[] imageBytes = image.getBytes();

//        // 如果文件大于 200 KB
//        if (imageBytes.length > MAX_FILE_SIZE) {

        log.info("==> 开始压缩图片");

        // 获取 ByteArrayOutputStream 对象池中的一个对象
        try (ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream()) {
            // 压缩图片
            Thumbnails.of(image.getInputStream())
                    .outputFormat("jpg")
//                    .outputQuality(0.1f)
                    // 缩放 16 : 9
//                    .scale((double) 9 / 16)
                    .size(1920, 1080)
                    .keepAspectRatio(true)
                    .toOutputStream(byteArrayOutputStream);

            imageBytes = byteArrayOutputStream.toByteArray();

        } catch (Exception e) {
            log.error("# 图片压缩失败！", e);
        }
        // 返回压缩后的 MultipartFile
        return new MockMultipartFile(image.getOriginalFilename(), image.getOriginalFilename(), image.getContentType(), imageBytes);
//        }
//        return null;
    }
}
