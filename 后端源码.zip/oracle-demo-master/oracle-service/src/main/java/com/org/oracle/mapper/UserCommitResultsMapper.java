package com.org.oracle.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.org.oracle.mysql.entity.UserCommitResult;


/**
 * (UserCommitResults)表数据库访问层
 *
 * @author luo
 * @since 2024-12-16 20:37:19
 */
public interface UserCommitResultsMapper extends BaseMapper<UserCommitResult> {

}

