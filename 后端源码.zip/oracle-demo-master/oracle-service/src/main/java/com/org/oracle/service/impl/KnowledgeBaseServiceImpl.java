package com.org.oracle.service.impl;

import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.google.common.base.Preconditions;
import com.org.oracle.enums.ResponseCodeEnum;
import com.org.oracle.mongodb.entity.KnowledgeBase;
import com.org.oracle.service.KnowledgeBaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;

/**
 * @Author: heiye
 * @CreateTime: 2024/09/09 下午5:49
 * @Description: 知识库
 * @Version: 1.0
 */
@Service
public class KnowledgeBaseServiceImpl implements KnowledgeBaseService {

    @Autowired
    private MongoTemplate mongoTemplate;

    /**
     * 创建知识库
     *
     * @param knowledgeBase
     */
    @Override
    public void create(KnowledgeBase knowledgeBase) {
        // 参数校验
        Preconditions.checkArgument(Objects.nonNull(knowledgeBase), ResponseCodeEnum.PARAM_REQUIRE);
        Preconditions.checkArgument(knowledgeBase.check(), ResponseCodeEnum.PARAM_REQUIRE);

        mongoTemplate.insert(knowledgeBase);
    }

    /**
     * 模糊查询标题返回多条知识库
     *
     * @param name
     * @return
     */
    @Override
    public List<KnowledgeBase> find(String name) {
        // 创建正则表达式
        Pattern pattern = Pattern.compile("^.*" + name + ".*$", Pattern.CASE_INSENSITIVE);

        // 查询并返回
        return mongoTemplate.find(Query.query(Criteria.where("name").regex(pattern)), KnowledgeBase.class);
    }
}
