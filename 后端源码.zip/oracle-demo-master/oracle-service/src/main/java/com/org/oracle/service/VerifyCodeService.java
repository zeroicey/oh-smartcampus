package com.org.oracle.service;

import com.org.oracle.sub.dto.EmailCheckDTO;
import com.org.oracle.sub.dto.EmailVerifyCodeDTO;

/**
 * @author: heiye
 * @date: 2024/12/03 下午7:24
 * @version: v1.0.0
 * @description:
 */
public interface VerifyCodeService {

    /**
     * 发送邮件验证码
     *
     * @param emailVerifyCodeDTO
     */
    void sendEmail(EmailVerifyCodeDTO emailVerifyCodeDTO);

    /**
     * 邮箱校验
     * @param emailCheckDTO
     */
    void checkEmail(EmailCheckDTO emailCheckDTO);
}
