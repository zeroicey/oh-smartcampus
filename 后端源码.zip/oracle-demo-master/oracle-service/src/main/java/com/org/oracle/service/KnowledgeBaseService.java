package com.org.oracle.service;

import com.org.oracle.mongodb.entity.KnowledgeBase;

import java.util.List;

/**
 * @Author: heiye
 * @CreateTime: 2024/09/09 下午5:52
 * @Description: 知识库
 * @Version: 1.0
 */
public interface KnowledgeBaseService {
    /**
     * 创建知识库
     *
     * @param knowledgeBase
     */
    void create(KnowledgeBase knowledgeBase);

    /**
     * 模糊查询标题返回多条知识库
     *
     * @param name
     * @return
     */
    List<KnowledgeBase> find(String name);
}
