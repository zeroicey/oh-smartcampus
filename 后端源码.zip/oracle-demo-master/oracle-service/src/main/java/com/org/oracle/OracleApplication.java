package com.org.oracle;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @author suze
 * @date 2024/8/15
 * @time 12:05
 **/
@SpringBootApplication
@EnableTransactionManagement
@MapperScan("com.org.oracle.mapper")
@EnableScheduling
public class OracleApplication {
    public static void main(String[] args) {
        SpringApplication.run(OracleApplication.class, args);
    }
}
