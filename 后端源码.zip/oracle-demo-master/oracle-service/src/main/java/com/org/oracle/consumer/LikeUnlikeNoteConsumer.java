package com.org.oracle.consumer;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.google.common.util.concurrent.RateLimiter;
import com.org.oracle.constant.MQConstants;
import com.org.oracle.enums.LikeUnlikeNoteTypeEnum;
import com.org.oracle.mapper.NoteLikeMapper;
import com.org.oracle.mysql.dto.LikeUnlikeNoteMqDTO;
import com.org.oracle.mysql.entity.NoteLike;
import com.org.oracle.util.JsonUtils;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.client.producer.SendCallback;
import org.apache.rocketmq.client.producer.SendResult;
import org.apache.rocketmq.common.message.Message;
import org.apache.rocketmq.spring.annotation.ConsumeMode;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 * @author: heiye
 * @date: 2024/12/13 上午11:03
 * @version: v1.0.0
 * @description: 笔记点赞、取消点赞 MQ 消费者
 */
@Slf4j
@Component
@RocketMQMessageListener(
        // Group 组
        consumerGroup = "oracle_group_" + MQConstants.TOPIC_LIKE_OR_UNLIKE,
        // 消费的主题 Topic
        topic = MQConstants.TOPIC_LIKE_OR_UNLIKE,
        // 设置为顺序消费模式
        consumeMode = ConsumeMode.ORDERLY)
public class LikeUnlikeNoteConsumer implements RocketMQListener<Message> {

    // 每秒创建 5000 个令牌
    private RateLimiter rateLimiter = RateLimiter.create(5000);

    @Resource
    private NoteLikeMapper noteLikeMapper;

    @Autowired
    private RocketMQTemplate rocketMQTemplate;

    @Override
    public void onMessage(Message message) {
        // 流量削峰：通过获取令牌，如果没有令牌可用，将堵塞，直到获得
        rateLimiter.acquire();

        // 幂等性: 通过联合唯一索引保证

        // 消息体
        String bodyJsonStr = new String(message.getBody());
        // 标签
        String tags = message.getTags();

        log.info("==> LikeUnlikeNoteConsumer 消费了消息 {}, tags: {}", bodyJsonStr, tags);

        // 根据 MQ 标签，判断操作类型
        // 点赞笔记
        if (Objects.equals(tags, MQConstants.TAG_LIKE)) {
            handleLikeNoteTagMessage(bodyJsonStr);
        }
        // 取消点赞笔记
        else if (Objects.equals(tags, MQConstants.TAG_UNLIKE)) {
            handleUnlikeNoteTagMessage(bodyJsonStr);
        }
    }

    /**
     * 笔记点赞
     *
     * @param bodyJsonStr
     */
    private void handleLikeNoteTagMessage(String bodyJsonStr) {
        // 消息体 JSON 字符串转 DTO
        LikeUnlikeNoteMqDTO likeNoteMqDTO = JsonUtils.parseObject(bodyJsonStr, LikeUnlikeNoteMqDTO.class);

        if (Objects.isNull(likeNoteMqDTO)) {
            return;
        }

        // 用户ID
        String uid = likeNoteMqDTO.getUid();
        // 点赞的笔记ID
        String noteId = likeNoteMqDTO.getNoteId();
        // 操作类型
        Integer type = likeNoteMqDTO.getType();
        // 点赞时间
        LocalDateTime createTime = likeNoteMqDTO.getCreateTime();

        // 构建对象
        NoteLike noteLike = NoteLike.builder()
                .uid(uid)
                .noteId(noteId)
                .createTime(createTime)
                .status(type)
                .build();

        // 添加或更新笔记点赞记录
        int count = noteLikeMapper.saveOrUpdate(noteLike);

        if (count == 0) {
            return;
        }

        // 更新数据库成功后，发送计数MQ
        org.springframework.messaging.Message<String> message = MessageBuilder.withPayload(bodyJsonStr).build();

        // 异步发送 MQ 消息
        rocketMQTemplate.asyncSend(MQConstants.TOPIC_COUNT_NOTE_LIKE, message, new SendCallback() {
            @Override
            public void onSuccess(SendResult sendResult) {
                log.info("==> 【计数: 笔记点赞】MQ 发送成功，SendResult: {}", sendResult);
            }

            @Override
            public void onException(Throwable throwable) {
                log.error("==> 【计数: 笔记点赞】MQ 发送异常: ", throwable);
            }
        });
    }

    /**
     * 笔记取消点赞
     *
     * @param bodyJsonStr
     */
    private void handleUnlikeNoteTagMessage(String bodyJsonStr) {
        // 消息体 JSON 字符串转 DTO
        LikeUnlikeNoteMqDTO unlikeNoteMqDTO = JsonUtils.parseObject(bodyJsonStr, LikeUnlikeNoteMqDTO.class);

        if (Objects.isNull(unlikeNoteMqDTO)) {
            return;
        }

        // 构建条件
        LambdaUpdateWrapper<NoteLike> lambdaUpdateWrapper = Wrappers.<NoteLike>lambdaUpdate()
                // 操作类型
                .set(NoteLike::getStatus, unlikeNoteMqDTO.getType())
                // 取消点赞时间
                .set(NoteLike::getCreateTime, unlikeNoteMqDTO.getCreateTime())
                // 用户ID
                .eq(NoteLike::getUid, unlikeNoteMqDTO.getUid())
                // 点赞的笔记ID
                .eq(NoteLike::getNoteId, unlikeNoteMqDTO.getNoteId())
                // 确保布隆过滤器误判的情况下也能更改成功
                .eq(NoteLike::getStatus, LikeUnlikeNoteTypeEnum.LIKE.getCode());

        // 更新笔记点赞记录
        long count = noteLikeMapper.update(lambdaUpdateWrapper);

        if (count == 0) {
            return;
        }

        // 更新数据库成功后，发送计数MQ
        org.springframework.messaging.Message<String> message = MessageBuilder.withPayload(bodyJsonStr).build();

        // 异步发送 MQ 消息
        rocketMQTemplate.asyncSend(MQConstants.TOPIC_COUNT_NOTE_LIKE, message, new SendCallback() {
            @Override
            public void onSuccess(SendResult sendResult) {
                log.info("==> 【计数: 笔记点赞】MQ 发送成功，SendResult: {}", sendResult);
            }

            @Override
            public void onException(Throwable throwable) {
                log.error("==> 【计数: 笔记点赞】MQ 发送异常: ", throwable);
            }
        });
    }
}
