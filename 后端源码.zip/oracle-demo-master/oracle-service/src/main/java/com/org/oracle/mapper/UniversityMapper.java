package com.org.oracle.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.org.oracle.mysql.entity.University;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author suze
 * @date 2024/11/30
 * @time 15:49
 **/
@Mapper
public interface UniversityMapper extends BaseMapper<University> {

}
