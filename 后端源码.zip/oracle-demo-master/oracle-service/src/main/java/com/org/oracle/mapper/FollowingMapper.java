package com.org.oracle.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.org.oracle.mysql.entity.Following;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author: heiye
 * @date: 2024/12/20 上午10:54
 * @version: v1.0.0
 * @description:
 */
@Mapper
public interface FollowingMapper extends BaseMapper<Following> {
}
