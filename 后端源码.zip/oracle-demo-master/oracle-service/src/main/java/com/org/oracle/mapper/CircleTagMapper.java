package com.org.oracle.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.org.oracle.mysql.entity.CircleTag;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author: heiye
 * @date: 2024/11/14 下午3:05
 * @version: v1.0.0
 * @description: 知识圈标签Mapper
 */
@Mapper
public interface CircleTagMapper extends BaseMapper<CircleTag> {
}
