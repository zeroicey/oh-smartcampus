package com.org.oracle.controller;

import com.org.oracle.mongodb.dto.CircleQueryBatchDTO;
import com.org.oracle.result.Result;
import com.org.oracle.service.CircleService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;


/**
 * @author suze
 * @date 2024/8/18
 * @time 20:38
 **/
@RestController
@RequestMapping("/circle")
public class CircleController {
    @Resource
    private CircleService circleService;

    /**
     * 寻找所有知识圈
     *
     * 此方法用于获取系统中的所有知识圈信息
     * 它没有参数
     * 返回包含所有知识圈信息的Result对象
     */
    @GetMapping("/findAll")
    public Result find_all() {
        return Result.ok(circleService.find_all());
    }

    /**
     * 根据标签查知识圈
     *
     * 此方法用于根据特定标签获取知识圈信息
     * @param tag 标签ID，用于筛选知识圈
     * 返回包含根据标签筛选的知识圈信息的Result对象
     */
    @GetMapping("/findByTag")
    public Result find_by_tag(@RequestParam("tag") Long tag) {
        return Result.ok(circleService.find_by_tag(tag));
    }

    /**
     * 根据词汇搜索知识圈
     *
     * 此方法用于根据特定词汇搜索知识圈信息
     * @param word 关键词汇，用于搜索知识圈
     * 返回包含根据关键词搜索的知识圈信息的Result对象
     */
    @GetMapping("/findByWord")
    public Result find_by_word(@RequestParam("word") String word) {
        return Result.ok(circleService.find_by_word(word));
    }
}
