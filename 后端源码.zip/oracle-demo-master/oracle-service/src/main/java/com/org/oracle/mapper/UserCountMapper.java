package com.org.oracle.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.org.oracle.mysql.entity.UserCount;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @author: heiye
 * @date: 2024/12/15 下午10:56
 * @version: v1.0.0
 * @description: 用户计数
 */
@Mapper
public interface UserCountMapper extends BaseMapper<UserCount> {
    /**
     * 添加记录或更新笔记点赞数
     *
     * @param count
     * @param uid
     * @return
     */
    int insertOrUpdateLikeTotalByUserId(@Param("count") Integer count, @Param("uid") String uid);

    /**
     * 添加记录或更新笔记收藏数
     *
     * @param count
     * @param uid
     * @return
     */
    int insertOrUpdateCollectTotalByUserId(@Param("count") Integer count, @Param("uid") String uid);

    /**
     * 添加记录或更新发过笔记的数量
     *
     * @param count
     * @param uid
     * @return
     */
    int insertOrUpdateNoteTotalByUserId(@Param("count") Long count, @Param("uid") String uid);

    /**
     * 添加记录或更新点亮数
     *
     * @param count
     * @param uid
     * @return
     */
    int insertOrUpdateBrightTotalTotalByUserId(@Param("count") Integer count, @Param("uid") String uid);

    /**
     * 查询用户获得的点赞数
     *
     * @param uid 用户ID
     * @return 笔记点赞数
     */
    int selectLikeTotalByUserId(@Param("uid") String uid);

    /**
     * 查询用户获得的收藏数
     *
     * @param uid 用户ID
     * @return 笔记收藏数
     */
    int selectCollectTotalByUserId(@Param("uid") String uid);

    /**
     * 查询用户发过的笔记数量
     *
     * @param uid 用户ID
     * @return 发过的笔记数量
     */
    int selectNoteTotalByUserId(@Param("uid") String uid);

    /**
     * 查询用户获得点亮总数
     *
     * @param uid 用户ID
     * @return 获得点亮总数
     */
    int selectBrightTotalByUserId(@Param("uid") String uid);

}
