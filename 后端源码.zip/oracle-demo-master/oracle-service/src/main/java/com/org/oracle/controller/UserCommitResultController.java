package com.org.oracle.controller;

import com.org.oracle.mysql.dto.UserAnswerSubmitDTO;
import com.org.oracle.result.Result;
import com.org.oracle.service.UserCommitResultsService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/question")
public class UserCommitResultController {

    @Resource
    private UserCommitResultsService userCommitResultsService;

    /**
     * 用户正常完整上传答案
     * @param submitDTO
     * @return 正确率，刷题时间min单位 等相关字段
     */
    @PostMapping("/answerUpload")
    public Result userUpLoadAnswer(@RequestHeader String uid, @RequestBody UserAnswerSubmitDTO submitDTO){
        return userCommitResultsService.userUpLoadAnswer(uid,submitDTO);
    }

    @PostMapping("/tempSaveAnswer")
    public Result temporarySaveAnswer(@RequestHeader String uid, @RequestBody UserAnswerSubmitDTO submitDTO){
        return userCommitResultsService.userTemporarySaveAnswer(uid,submitDTO);
    }

    @GetMapping("/getSubjectProgressByUid")
    public Float test01(@RequestHeader String uid){
        return userCommitResultsService.getSubjectProgressByUid(uid);
    }
//    @GetMapping("/getLastSubmitOrTemporaryTime")
//    public Result getLastSubmitOrTemporaryTime(String uid,String chapterId){
//        return Result.ok(userCommitResultsService.getLastSubmitOrTemporaryTime(uid,chapterId));
//    }
//    @GetMapping("/getChapterTotalStudyTime")
//    public Result getChapterTotalStudyTime(String uid,String chapterId){
//        return Result.ok(userCommitResultsService.getChapterTotalStudyTime(uid,chapterId));
//    }
}
