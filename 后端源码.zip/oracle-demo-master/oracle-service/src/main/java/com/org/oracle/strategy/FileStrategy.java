package com.org.oracle.strategy;

import org.springframework.web.multipart.MultipartFile;

/**
 * @author: heiye
 * @date: 2024/11/21 下午1:31
 * @version: v1.0.0
 * @description: 文件策略接口
 *               策略的定义比较简单，包含一个策略接口和一组实现该接口的策略类。
 *               因为所有的策略类都实现了相同的接口，调用者基于接口使用，
 *               所以可以灵活的替换不同策略，调用者是无感知的。
 */
public interface FileStrategy {
    /**
     * 图片上传
     *
     * @param image
     * @param bucketName
     * @return
     */
    String uploadImg(MultipartFile image, String bucketName);
}
