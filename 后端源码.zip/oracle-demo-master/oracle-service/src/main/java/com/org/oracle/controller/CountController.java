package com.org.oracle.controller;

import org.springframework.web.bind.annotation.*;

/**
 * @author: heiye
 * @date: 2024/12/11 下午6:15
 * @version: v1.0.0
 * @description: 计数服务
 */
@RestController
public class CountController {
}
