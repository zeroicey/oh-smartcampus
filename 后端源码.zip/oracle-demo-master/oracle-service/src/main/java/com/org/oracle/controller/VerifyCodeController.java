package com.org.oracle.controller;

import com.org.oracle.result.Result;
import com.org.oracle.service.VerifyCodeService;
import com.org.oracle.sub.dto.EmailCheckDTO;
import com.org.oracle.sub.dto.EmailVerifyCodeDTO;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author: heiye
 * @date: 2024/12/03 下午7:23
 * @version: v1.0.0
 * @description: 验证码接口
 */
@RestController
public class VerifyCodeController {

    @Resource
    private VerifyCodeService verifyCodeService;

    /**
     * 发送邮箱验证码
     *
     * @param emailVerifyCodeDTO
     * @return
     */
    @PostMapping("/send/email")
    public Result sendEmail(@RequestBody EmailVerifyCodeDTO emailVerifyCodeDTO) {
        verifyCodeService.sendEmail(emailVerifyCodeDTO);
        return Result.ok();
    }

    /**
     * 校验邮箱的验证码是否正确
     *
     * @param emailCheckDTO
     * @return
     */
    @PostMapping("/check/email")
    public Result checkEmail(@RequestBody EmailCheckDTO emailCheckDTO) {
        verifyCodeService.checkEmail(emailCheckDTO);
        return Result.ok();
    }
}
