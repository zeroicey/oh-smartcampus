/*
 Navicat Premium Data Transfer

 Source Server         : MongoDB
 Source Server Type    : MongoDB
 Source Server Version : 40012 (4.0.12)
 Source Host           : localhost:27017
 Source Schema         : oracle

 Target Server Type    : MongoDB
 Target Server Version : 40012 (4.0.12)
 File Encoding         : 65001

 Date: 28/12/2024 20:51:02
*/


// ----------------------------
// Collection structure for AiHistory
// ----------------------------
db.getCollection("AiHistory").drop();
db.createCollection("AiHistory");

// ----------------------------
// Documents of AiHistory
// ----------------------------
db.getCollection("AiHistory").insert([ {
    _id: ObjectId("676e3b066aa64d4d64db5cf3"),
    uid: "1000003",
    topic_id: "1",
    messages: [
        {
            role: "assistant",
            content: "绪论是文章或书籍的开头部分，介绍主题背景、目的和研究范围，为读者提供整体框架和研究方向。"
        },
        {
            role: "user",
            content: "啊啊啊"
        },
        {
            role: "assistant",
            content: "看起来你输入的内容“啊啊啊”并没有与<Data></Data>标记中的内容直接相关。根据你的指示，如果问题与<Data></Data>标记中的内容无关，我将拒绝回答本次问题。如果你有其他具体问题或需要帮助，请随时提出。"
        }
    ],
    _class: "com.org.oracle.mongodb.entity.AiHistory"
} ]);
db.getCollection("AiHistory").insert([ {
    _id: ObjectId("676e3b6b6aa64d4d64db5cf4"),
    uid: "1000003",
    topic_id: "1",
    messages: [
        {
            role: "assistant",
            content: "绪论是文章或书籍的开头部分，介绍主题背景、目的和研究范围，为读者提供整体框架和研究方向。"
        }
    ],
    _class: "com.org.oracle.mongodb.entity.AiHistory"
} ]);
db.getCollection("AiHistory").insert([ {
    _id: ObjectId("676e45d9f626a1380027c780"),
    uid: "1000006",
    topic_id: "42",
    messages: [ ],
    _class: "com.org.oracle.mongodb.entity.AiHistory"
} ]);
db.getCollection("AiHistory").insert([ {
    _id: ObjectId("676e4651f626a1380027c781"),
    uid: "1000006",
    messages: [ ],
    _class: "com.org.oracle.mongodb.entity.AiHistory"
} ]);
db.getCollection("AiHistory").insert([ {
    _id: ObjectId("676e509af626a1380027c782"),
    uid: "1000006",
    topic_id: "2",
    messages: [ ],
    _class: "com.org.oracle.mongodb.entity.AiHistory"
} ]);
db.getCollection("AiHistory").insert([ {
    _id: ObjectId("676e70d1dfbbd0668b96f913"),
    uid: "1000006",
    topic_id: "1",
    messages: [
        {
            role: "assistant",
            content: "绪论是书籍或论文的开头部分，用于介绍主题背景、研究目的和意义，概述主要内容和结构，为读者提供阅读框架。"
        },
        {
            role: "user",
            content: "aaa"
        },
        {
            role: "assistant",
            content: "由于您的问题“\"aaa\"”并没有与`<Data></Data>`标记中的内容直接相关，根据指示，如果问题与`<Data></Data>`标记中的内容无关，我将拒绝回答本次问题。如果您有其他具体问题或需要帮助，请随时提出。"
        }
    ],
    _class: "com.org.oracle.mongodb.entity.AiHistory"
} ]);
db.getCollection("AiHistory").insert([ {
    _id: ObjectId("676e7363dfbbd0668b96f914"),
    uid: "1000006",
    topic_id: "1",
    messages: [
        {
            role: "assistant",
            content: "绪论是书籍或论文的开头部分，用于介绍主题背景、研究目的和意义，概述主要内容和结构，为读者提供阅读框架。"
        }
    ],
    _class: "com.org.oracle.mongodb.entity.AiHistory"
} ]);
db.getCollection("AiHistory").insert([ {
    _id: ObjectId("676e73dbdfbbd0668b96f915"),
    uid: "1000006",
    topic_id: "1",
    messages: [
        {
            role: "assistant",
            content: "绪论是书籍或论文的开头部分，用于介绍主题背景、研究目的和意义，概述主要内容和结构，为读者提供阅读框架。"
        }
    ],
    _class: "com.org.oracle.mongodb.entity.AiHistory"
} ]);
db.getCollection("AiHistory").insert([ {
    _id: ObjectId("676fa42d14183f712b7dd38f"),
    uid: "1000003",
    topic_id: "66",
    messages: [
        {
            role: "assistant",
            content: "总线是计算机系统中连接不同硬件组件的通信通道，负责传输数据、地址和控制信号，确保各部件间高效协同工作。"
        }
    ],
    _class: "com.org.oracle.mongodb.entity.AiHistory"
} ]);
db.getCollection("AiHistory").insert([ {
    _id: ObjectId("676fa6fc14183f712b7dd390"),
    uid: "1000003",
    topic_id: "66",
    messages: [
        {
            role: "assistant",
            content: "总线是计算机系统中连接不同硬件组件的通信通道，负责传输数据、地址和控制信号，确保各部件间高效协同工作。"
        },
        {
            role: "user",
            content: "总线应该怎么去学啊，好多好难"
        }
    ],
    _class: "com.org.oracle.mongodb.entity.AiHistory"
} ]);
db.getCollection("AiHistory").insert([ {
    _id: ObjectId("676fba9814183f712b7dd391"),
    uid: "1000003",
    topic_id: "66",
    messages: [
        {
            role: "assistant",
            content: "总线是计算机系统中连接不同硬件组件的通信通道，负责传输数据、地址和控制信号，确保各部件间高效协同工作。"
        }
    ],
    _class: "com.org.oracle.mongodb.entity.AiHistory"
} ]);
db.getCollection("AiHistory").insert([ {
    _id: ObjectId("676fbc9014183f712b7dd392"),
    uid: "1000003",
    topic_id: "66",
    messages: [
        {
            role: "assistant",
            content: "总线是计算机系统中连接不同硬件组件的通信通道，负责传输数据、地址和控制信号，确保各部件间高效协同工作。"
        }
    ],
    _class: "com.org.oracle.mongodb.entity.AiHistory"
} ]);
db.getCollection("AiHistory").insert([ {
    _id: ObjectId("676fbcf914183f712b7dd393"),
    uid: "1000003",
    topic_id: "1",
    messages: [
        {
            role: "assistant",
            content: "绪论是文章或书籍的开头部分，用于介绍主题、背景信息和研究目的，为读者提供必要的上下文，帮助理解后续内容。"
        }
    ],
    _class: "com.org.oracle.mongodb.entity.AiHistory"
} ]);
db.getCollection("AiHistory").insert([ {
    _id: ObjectId("676fc28814183f712b7dd395"),
    uid: "1000003",
    topic_id: "1",
    messages: [
        {
            role: "assistant",
            content: "绪论是文章或书籍的开头部分，用于介绍主题、背景信息和研究目的，为读者提供必要的上下文，帮助理解后续内容。"
        }
    ],
    _class: "com.org.oracle.mongodb.entity.AiHistory"
} ]);

// ----------------------------
// Collection structure for ai_note
// ----------------------------
db.getCollection("ai_note").drop();
db.createCollection("ai_note");

// ----------------------------
// Documents of ai_note
// ----------------------------
db.getCollection("ai_note").insert([ {
    _id: "4",
    name: "她只是我的妹妹",
    uid: "1000001",
    topic_id: NumberLong("0"),
    img: [
        "https://www.bilibili.com/video/BV1UT42167xb/?spm_id_from=333.337.search-card.all.click"
    ],
    word: "```markdown\n# 多重中断的特点\n\n## 优先级\n- **不同优先级**：中断请求有不同的优先级。\n- **响应顺序**：根据优先级高低决定CPU响应的顺序。\n\n## 中断嵌套\n- **触发更高优先级中断**：在处理一个中断的过程中，可能触发另一个更高优先级的中断。\n- **中断服务程序嵌套执行**：导致中断服务程序的嵌套执行。\n\n## 中断响应周期\n- **多个响应周期**：CPU在处理中断时，可能会进入多个中断响应周期。\n- **每个周期处理一个请求**：每个周期处理一个中断请求。\n```",
    data_set: {
        _id: "1",
        uid: "1000001",
        topic_id: "1",
        messages: [
            {
                role: "user",
                content: "多重中断的特点：\n优先级：\n中断请求有不同的优先级，根据优先级高低决定CPU响应的顺序。\n中断嵌套：在处理一个中断的过程中，可能触发另一个更高优先级的中断，导致中断服务程序的嵌套执行。\n中断响应周期：CPU在处理中断时，可能会进入多个中断响应周期，每个周期处理一个中断请求。"
            }
        ],
        _class: "com.org.oracle.sub.entity.DataSet"
    },
    create_time: ISODate("1970-01-01T05:24:30.667Z"),
    update_time: ISODate("1970-01-01T15:04:58.565Z"),
    _class: "com.org.oracle.mongodb.entity.AINote"
} ]);
db.getCollection("ai_note").insert([ {
    _id: "5",
    name: "霸王别姬",
    uid: "1000001",
    topic_id: NumberLong("0"),
    img: [
        "https://www.bilibili.com/video/BV1UT42167xb/?spm_id_from=333.337.search-card.all.click"
    ],
    word: "```markdown\n# 多重中断的特点\n\n## 优先级\n- **中断请求优先级**：中断请求有不同的优先级。\n- **CPU响应顺序**：根据优先级高低决定CPU响应的顺序。\n\n## 中断嵌套\n- **中断触发**：在处理一个中断的过程中，可能触发另一个更高优先级的中断。\n- **中断服务程序嵌套**：导致中断服务程序的嵌套执行。\n\n## 中断响应周期\n- **多个中断响应周期**：CPU在处理中断时，可能会进入多个中断响应周期。\n- **每个周期处理**：每个周期处理一个中断请求。\n```",
    data_set: {
        _id: "2",
        uid: "1000001",
        topic_id: "1",
        messages: [
            {
                role: "user",
                content: "多重中断的特点：\n优先级：\n中断请求有不同的优先级，根据优先级高低决定CPU响应的顺序。\n中断嵌套：在处理一个中断的过程中，可能触发另一个更高优先级的中断，导致中断服务程序的嵌套执行。\n中断响应周期：CPU在处理中断时，可能会进入多个中断响应周期，每个周期处理一个中断请求。"
            }
        ],
        _class: "com.org.oracle.sub.entity.DataSet"
    },
    create_time: ISODate("1970-01-01T03:23:49.441Z"),
    update_time: ISODate("1970-01-01T03:23:49.441Z"),
    _class: "com.org.oracle.mongodb.entity.AINote"
} ]);

// ----------------------------
// Collection structure for chapters
// ----------------------------
db.getCollection("chapters").drop();
db.createCollection("chapters");

// ----------------------------
// Documents of chapters
// ----------------------------
db.getCollection("chapters").insert([ {
    _id: ObjectId("67356bffed834eaf0e0d792d"),
    id: NumberInt("3"),
    testing_points: [
        {
            ordinal: "01",
            name: "绪论",
            summary: "基本概念、基本原理和基本方法"
        },
        {
            ordinal: "02",
            name: "算法的基本概念、特性及设计要求",
            summary: "算法的定义、特性、设计要求"
        },
        {
            ordinal: "03",
            name: "算法的时间复杂度和空间复杂度",
            summary: "时间复杂度和空间复杂度的概念和计算方法"
        },
        {
            ordinal: "04",
            name: "线性表",
            summary: "线性表的定义和基本操作"
        },
        {
            ordinal: "05",
            name: "顺序表",
            summary: "顺序表的定义和操作"
        },
        {
            ordinal: "06",
            name: "单链表、双链表、循环链表",
            summary: "单链表、双链表、循环链表的定义及其操作"
        },
        {
            ordinal: "07",
            name: "顺序表和链表的比较",
            summary: "顺序表和链表的优缺点比较"
        },
        {
            ordinal: "08",
            name: "栈和队列",
            summary: "栈和队列的基本概念"
        },
        {
            ordinal: "09",
            name: "栈和队列的存储结构",
            summary: "栈和队列的顺序存储结构和链式存储结构"
        },
        {
            ordinal: "10",
            name: "多维数组的存储",
            summary: "多维数组的存储方式"
        },
        {
            ordinal: "11",
            name: "特殊矩阵的压缩存储",
            summary: "特殊矩阵的存储方法"
        },
        {
            ordinal: "12",
            name: "栈、队列和数组的应用",
            summary: "栈、队列和数组在实际问题中的应用"
        },
        {
            ordinal: "13",
            name: "树与二叉树",
            summary: "树的基本概念"
        },
        {
            ordinal: "14",
            name: "二叉树的定义、性质、遍历",
            summary: "二叉树的定义、性质、遍历方法"
        },
        {
            ordinal: "15",
            name: "线索二叉树",
            summary: "线索二叉树的基本概念和构造"
        },
        {
            ordinal: "16",
            name: "树、森林与二叉树的转换",
            summary: "树、森林与二叉树之间的转换方法"
        },
        {
            ordinal: "17",
            name: "树与二叉树的应用",
            summary: "树与二叉树的应用，如哈夫曼树和哈夫曼编码、并查集"
        },
        {
            ordinal: "18",
            name: "图",
            summary: "图的基本概念"
        },
        {
            ordinal: "19",
            name: "图的存储及基本操作",
            summary: "图的存储结构及基本操作"
        },
        {
            ordinal: "20",
            name: "图的遍历",
            summary: "图的遍历方法，包括深度优先搜索和广度优先搜索"
        },
        {
            ordinal: "21",
            name: "图的基本应用",
            summary: "图的基本应用，如最小生成树、最短路径、拓扑排序、关键路径"
        },
        {
            ordinal: "22",
            name: "查找",
            summary: "查找的基本概念"
        },
        {
            ordinal: "23",
            name: "顺序查找法",
            summary: "顺序查找法的原理和应用"
        },
        {
            ordinal: "24",
            name: "分块查找法",
            summary: "分块查找法的原理和应用"
        },
        {
            ordinal: "25",
            name: "折半查找法",
            summary: "折半查找法的原理和应用"
        },
        {
            ordinal: "26",
            name: "B树及其基本操作",
            summary: "B树的定义、性质和基本操作"
        },
        {
            ordinal: "27",
            name: "散列表（Hash）",
            summary: "散列表的基本原理和应用"
        },
        {
            ordinal: "28",
            name: "排序",
            summary: "排序的基本概念"
        },
        {
            ordinal: "29",
            name: "插入排序",
            summary: "插入排序的原理和实现"
        },
        {
            ordinal: "30",
            name: "气泡排序",
            summary: "气泡排序的原理和实现"
        },
        {
            ordinal: "31",
            name: "简单选择排序",
            summary: "简单选择排序的原理和实现"
        },
        {
            ordinal: "32",
            name: "希尔排序",
            summary: "希尔排序的原理和实现"
        },
        {
            ordinal: "33",
            name: "快速排序",
            summary: "快速排序的原理和实现"
        },
        {
            ordinal: "34",
            name: "堆排序",
            summary: "堆排序的原理和实现"
        },
        {
            ordinal: "35",
            name: "二路归并排序",
            summary: "二路归并排序的原理和实现"
        },
        {
            ordinal: "36",
            name: "基数排序",
            summary: "基数排序的原理和实现"
        },
        {
            ordinal: "37",
            name: "外部排序",
            summary: "外部排序的原理和实现"
        },
        {
            ordinal: "38",
            name: "排序算法的分析与应用",
            summary: "排序算法的分析和在实际问题中的应用"
        }
    ],
    circle_id: "3"
} ]);
db.getCollection("chapters").insert([ {
    _id: ObjectId("67356bffed834eaf0e0d792e"),
    id: NumberInt("1"),
    testing_points: [
        {
            ordinal: "01",
            name: "计算机发展历程",
            summary: "概述计算机从诞生至今的演变过程，包括各代计算机的特点和代表性技术。"
        },
        {
            ordinal: "02",
            name: "计算机系统层次结构",
            summary: "介绍计算机系统的多级层次结构，包括硬件、操作系统、应用程序等不同层次的功能和交互。"
        },
        {
            ordinal: "03",
            name: "计算机性能指标",
            summary: "分析计算机性能的衡量标准，如时钟频率、吞吐量、响应时间等。"
        },
        {
            ordinal: "04",
            name: "数据的表示和运算",
            summary: "探讨数据在计算机中的表示方法，包括二进制、ASCII码等，以及基本的算术和逻辑运算。"
        },
        {
            ordinal: "05",
            name: "定点数的表示和运算",
            summary: "详细说明定点数的表示方式，包括整数和小数的二进制表示，以及相关的运算规则。"
        },
        {
            ordinal: "06",
            name: "浮点数的表示和运算",
            summary: "解释浮点数的表示方法，如IEEE标准，以及浮点数的运算原理和精度问题。"
        },
        {
            ordinal: "07",
            name: "运算方法和运算电路",
            summary: "分析不同的算术运算方法和实现这些运算的电路设计。"
        },
        {
            ordinal: "08",
            name: "存储器层次结构",
            summary: "描述存储器的层次化结构，包括寄存器、缓存、主存和辅助存储器的作用和特点。"
        },
        {
            ordinal: "09",
            name: "层次化存储器的基本结构",
            summary: "深入探讨存储器层次结构中各层的组织方式和数据流动。"
        },
        {
            ordinal: "10",
            name: "半导体随机存取存储器",
            summary: "介绍半导体RAM的工作原理和分类，包括SRAM和DRAM。"
        },
        {
            ordinal: "11",
            name: "主存储器",
            summary: "讲解主存储器的构成、工作原理以及与CPU的交互。"
        },
        {
            ordinal: "12",
            name: "外部存储器",
            summary: "分析外部存储器如硬盘、固态硬盘等的存储原理和性能特点。"
        },
        {
            ordinal: "13",
            name: "高速缓冲存储器(Cache)",
            summary: "讨论Cache的工作原理，包括Cache的组织、替换策略和对性能的影响。"
        },
        {
            ordinal: "14",
            name: "虚拟存储器",
            summary: "解释虚拟存储器的概念，以及它如何通过内存管理单元(MMU)实现地址转换。"
        },
        {
            ordinal: "15",
            name: "指令系统的基本概念",
            summary: "概述指令系统的基本组成，包括指令格式、操作码和操作数。"
        },
        {
            ordinal: "16",
            name: "指令格式",
            summary: "详细描述不同类型指令的格式，如RISC和CISC指令集的特点。"
        },
        {
            ordinal: "17",
            name: "寻址方式",
            summary: "介绍各种寻址方式，包括直接寻址、间接寻址、基址寻址等。"
        },
        {
            ordinal: "18",
            name: "数据的对齐和大/小端存放方式",
            summary: "讨论数据在内存中的对齐方式和字节序问题，包括大端和小端模式。"
        },
        {
            ordinal: "19",
            name: "CISC 和 RISC 的基本概念",
            summary: "对比复杂指令集计算机(CISC)和精简指令集计算机(RISC)的设计哲学和性能特点。"
        },
        {
            ordinal: "20",
            name: "高级语言程序与机器级代码之间的对应",
            summary: "分析高级语言编写的程序如何被编译成机器级代码，并执行。"
        },
        {
            ordinal: "21",
            name: "中央处理器(CPU)",
            summary: "讲解CPU的结构和功能，包括指令执行过程、数据通路和控制器。"
        },
        {
            ordinal: "22",
            name: "指令执行过程",
            summary: "描述CPU执行一条指令的整个过程，包括取指、译码、执行、访存和写回。"
        },
        {
            ordinal: "23",
            name: "数据通路的功能和基本结构",
            summary: "分析数据通路在指令执行中的作用，以及其基本组成和数据流动。"
        },
        {
            ordinal: "24",
            name: "控制器的功能和工作原理",
            summary: "讨论控制器如何控制CPU的操作，包括硬布线和微程序控制方式。"
        },
        {
            ordinal: "25",
            name: "异常和中断机制",
            summary: "解释异常和中断的概念，以及它们在操作系统和CPU中的处理方式。"
        },
        {
            ordinal: "26",
            name: "指令流水线",
            summary: "讨论指令流水线的工作原理和优化CPU性能的方法。"
        },
        {
            ordinal: "27",
            name: "多处理器基本概念",
            summary: "介绍多处理器系统的基本概念，包括对称多处理(SMP)和非对称多处理(AMP)。"
        },
        {
            ordinal: "28",
            name: "总线和输入输出系统",
            summary: "讲解总线的概念、分类和功能，以及输入输出系统的组成和工作原理。"
        },
        {
            ordinal: "29",
            name: "I/O 接口(I/O 控制器)",
            summary: "分析I/O接口的功能和设计，包括各种I/O控制器的作用。"
        },
        {
            ordinal: "30",
            name: "I/O 方式",
            summary: "讨论不同的I/O传输方式，如轮询、中断驱动和直接内存访问(DMA)。"
        }
    ],
    circle_id: "1"
} ]);
db.getCollection("chapters").insert([ {
    _id: ObjectId("67356bffed834eaf0e0d792f"),
    id: NumberInt("4"),
    testing_points: [
        {
            ordinal: "01",
            name: "标准化工作及相关组织",
            summary: "了解国际标准化组织(ISO)、国际电信联盟(ITU)、电气和电子工程师协会(IEEE)等在计算机网络领域的标准化工作。"
        },
        {
            ordinal: "02",
            name: "速率相关的性能指标",
            summary: "掌握速率、带宽、吞吐量、延迟、时延带宽积等性能指标的定义和计算方法。"
        },
        {
            ordinal: "03",
            name: "分层结构、协议、接口、服务",
            summary: "理解OSI参考模型和TCP/IP模型的分层结构，以及各层之间的协议、接口和服务。"
        },
        {
            ordinal: "04",
            name: "数据传输率计算",
            summary: "掌握数据传输率的计算方法，包括比特率和波特率的转换。"
        },
        {
            ordinal: "05",
            name: "信号的编码与调制",
            summary: "了解信号编码和调制的基本原理，包括模拟信号和数字信号的编码与调制技术。"
        },
        {
            ordinal: "06",
            name: "信道划分介质访问控制",
            summary: "掌握信道划分技术，如频分多路复用(FDM)、时分多路复用(TDM)、波分多路复用(WDM)等。"
        },
        {
            ordinal: "07",
            name: "随机访问介质访问控制",
            summary: "了解随机访问介质访问控制协议，如ALOHA、CSMA/CD等。"
        },
        {
            ordinal: "08",
            name: "介质访问控制协议",
            summary: "掌握以太网的介质访问控制协议，包括CSMA/CD和CSMA/CA。"
        },
        {
            ordinal: "09",
            name: "扩展以太网：网桥、交换机",
            summary: "了解网桥和交换机的工作原理及其在扩展以太网中的应用。"
        },
        {
            ordinal: "10",
            name: "子网划分和子网掩码",
            summary: "掌握子网划分的基本概念和子网掩码的计算方法。"
        },
        {
            ordinal: "11",
            name: "无分类编址 CIDR",
            summary: "理解无分类编址CIDR的概念和作用，以及如何进行路由聚合。"
        },
        {
            ordinal: "12",
            name: "路由选择协议",
            summary: "掌握内部网关协议(IGP)和外部网关协议(EGP)的工作原理，如RIP、OSPF、BGP等。"
        },
        {
            ordinal: "13",
            name: "端口号、TCP/UDP协议",
            summary: "了解端口号的作用和TCP、UDP协议的特点及其在网络中的应用。"
        },
        {
            ordinal: "14",
            name: "可靠传输、流量控制、拥塞控制",
            summary: "掌握TCP协议的可靠传输机制、流量控制和拥塞控制方法。"
        },
        {
            ordinal: "15",
            name: "连接管理",
            summary: "了解TCP连接的建立和释放过程，包括三次握手和四次挥手。"
        },
        {
            ordinal: "16",
            name: "域名系统 DNS",
            summary: "掌握DNS的工作原理和域名解析过程。"
        },
        {
            ordinal: "17",
            name: "文件传输协议 FTP",
            summary: "了解FTP协议的工作原理和文件传输过程。"
        },
        {
            ordinal: "18",
            name: "万维网 WWW 和 HTTP 协议",
            summary: "掌握HTTP协议的工作原理和Web页面的请求与响应过程。"
        },
        {
            ordinal: "19",
            name: "电子邮件系统",
            summary: "了解电子邮件系统的工作原理，包括SMTP、POP3、IMAP等协议。"
        },
        {
            ordinal: "20",
            name: "动态主机配置协议 DHCP",
            summary: "掌握DHCP协议的工作原理和IP地址的自动配置过程。"
        },
        {
            ordinal: "21",
            name: "网络安全",
            summary: "了解网络安全的基本概念和常见的安全威胁。"
        },
        {
            ordinal: "22",
            name: "网络攻击的常见方式",
            summary: "掌握网络攻击的常见类型和防御策略。"
        },
        {
            ordinal: "23",
            name: "对称密码体制和公钥密码体制",
            summary: "了解对称密码体制和公钥密码体制的基本原理及其在网络安全中的应用。"
        },
        {
            ordinal: "24",
            name: "数字签名与保密通信",
            summary: "掌握数字签名和保密通信的实现机制。"
        },
        {
            ordinal: "25",
            name: "秘钥分配",
            summary: "了解秘钥分配的基本原理和常用的秘钥分配协议。"
        },
        {
            ordinal: "26",
            name: "无线局域网",
            summary: "了解无线局域网的基本概念和组成。"
        },
        {
            ordinal: "27",
            name: "无线局域网的组成和分类",
            summary: "掌握无线局域网的组成、分类和特点。"
        },
        {
            ordinal: "28",
            name: "IEEE 802.11 标准",
            summary: "了解IEEE 802.11标准及其在无线局域网中的应用。"
        }
    ],
    circle_id: "4"
} ]);
db.getCollection("chapters").insert([ {
    _id: ObjectId("67356bffed834eaf0e0d7930"),
    id: NumberInt("2"),
    testing_points: [
        {
            ordinal: "01",
            name: "基本概念、特征、分类",
            summary: "介绍操作系统的基本概念、特征和分类。"
        },
        {
            ordinal: "02",
            name: "主要功能",
            summary: "概述操作系统的主要功能。"
        },
        {
            ordinal: "03",
            name: "发展演化过程，典型操作系统",
            summary: "探讨操作系统的发展演化过程和典型的操作系统案例。"
        },
        {
            ordinal: "04",
            name: "结构设计，典型的操作系统结构",
            summary: "分析操作系统的结构设计和典型的操作系统结构。"
        },
        {
            ordinal: "05",
            name: "操作系统运行机制",
            summary: "解释操作系统的运行机制。"
        },
        {
            ordinal: "06",
            name: "内核态与用户态",
            summary: "讨论内核态与用户态的概念及其区别。"
        },
        {
            ordinal: "07",
            name: "中断与异常",
            summary: "解释中断与异常的概念及其在操作系统中的作用。"
        },
        {
            ordinal: "08",
            name: "系统调用接口",
            summary: "描述系统调用接口的功能和重要性。"
        },
        {
            ordinal: "09",
            name: "存储系统",
            summary: "介绍存储系统的组成和工作原理。"
        },
        {
            ordinal: "10",
            name: "I/O系统",
            summary: "探讨输入/输出系统的结构和功能。"
        },
        {
            ordinal: "11",
            name: "时钟（Clock）",
            summary: "解释时钟在操作系统中的作用和重要性。"
        },
        {
            ordinal: "12",
            name: "进程线程模型",
            summary: "分析进程和线程的模型及其在操作系统中的应用。"
        },
        {
            ordinal: "13",
            name: "并发环境与多道程序设计",
            summary: "讨论并发环境下的多道程序设计问题。"
        },
        {
            ordinal: "14",
            name: "进程的基本概念，进程控制块（PCB）",
            summary: "介绍进程的基本概念和进程控制块（PCB）的作用。"
        },
        {
            ordinal: "15",
            name: "进程状态及状态转换",
            summary: "解释进程的不同状态及其状态转换。"
        },
        {
            ordinal: "16",
            name: "进程控制：创建、撤销、阻塞、唤醒",
            summary: "描述进程控制的基本操作，包括创建、撤销、阻塞和唤醒。"
        },
        {
            ordinal: "17",
            name: "线程的基本概念，线程的实现机制",
            summary: "介绍线程的基本概念和线程实现机制。"
        },
        {
            ordinal: "18",
            name: "进程的同步与互斥：信号量及PV操作，管程",
            summary: "探讨进程同步与互斥的机制，包括信号量、PV操作和管程。"
        },
        {
            ordinal: "19",
            name: "进程间通信",
            summary: "解释进程间通信的机制和方法。"
        },
        {
            ordinal: "20",
            name: "处理机调度",
            summary: "讨论处理机调度的算法和策略。"
        },
        {
            ordinal: "21",
            name: "存储管理方案",
            summary: "介绍不同的存储管理方案及其特点。"
        },
        {
            ordinal: "22",
            name: "存储管理的基本概念，存储管理的基本任务",
            summary: "解释存储管理的基本概念和基本任务。"
        },
        {
            ordinal: "23",
            name: "分区存储管理方案",
            summary: "探讨分区存储管理方案的工作原理和应用。"
        },
        {
            ordinal: "24",
            name: "覆盖技术与交换技术",
            summary: "介绍覆盖技术和交换技术在存储管理中的应用。"
        },
        {
            ordinal: "25",
            name: "虚拟页式存储管理方案",
            summary: "分析虚拟页式存储管理方案的工作原理和优势。"
        },
        {
            ordinal: "26",
            name: "文件系统设计与实现技术",
            summary: "讨论文件系统的设计与实现技术。"
        },
        {
            ordinal: "27",
            name: "文件的基本概念、文件逻辑结构、文件的物理结构和存取方式",
            summary: "介绍文件的基本概念、逻辑结构、物理结构和存取方式。"
        },
        {
            ordinal: "28",
            name: "文件目录的基本概念，文件目录的实现",
            summary: "解释文件目录的基本概念和实现方法。"
        },
        {
            ordinal: "29",
            name: "文件的操作，目录的操作",
            summary: "描述文件和目录的操作过程。"
        },
        {
            ordinal: "30",
            name: "磁盘空间的管理",
            summary: "探讨磁盘空间的管理策略和方法。"
        },
        {
            ordinal: "31",
            name: "文件系统的可靠性和安全性",
            summary: "讨论文件系统的可靠性和安全性问题。"
        },
        {
            ordinal: "32",
            name: "文件系统的性能问题",
            summary: "分析文件系统的性能问题及其解决方案。"
        },
        {
            ordinal: "33",
            name: "I/O设备管理",
            summary: "介绍I/O设备管理的基本概念和方法。"
        },
        {
            ordinal: "34",
            name: "设备与设备分类",
            summary: "讨论设备的种类和分类。"
        },
        {
            ordinal: "35",
            name: "I/O硬件组成",
            summary: "介绍I/O系统的硬件组成。"
        },
        {
            ordinal: "36",
            name: "I/O软件的特点及结构",
            summary: "探讨I/O软件的特点和结构。"
        },
        {
            ordinal: "37",
            name: "典型技术：通道技术，缓冲技术，SPOOLing技术",
            summary: "分析通道技术、缓冲技术和SPOOLing技术在I/O系统中的应用。"
        },
        {
            ordinal: "38",
            name: "I/O性能问题及解决方案",
            summary: "讨论I/O性能问题及其解决方案。"
        },
        {
            ordinal: "39",
            name: "死锁",
            summary: "探讨死锁的概念、成因和解决方法。"
        },
        {
            ordinal: "40",
            name: "基本概念：死锁，活锁，饥饿",
            summary: "介绍死锁、活锁和饥饿的基本概念。"
        },
        {
            ordinal: "41",
            name: "死锁预防策略",
            summary: "讨论预防死锁的策略。"
        },
        {
            ordinal: "42",
            name: "死锁避免策略",
            summary: "探讨避免死锁的策略。"
        },
        {
            ordinal: "43",
            name: "死锁检测与解除",
            summary: "介绍死锁检测和解除的方法。"
        },
        {
            ordinal: "44",
            name: "资源分配图",
            summary: "解释资源分配图的概念和在死锁分析中的应用。"
        }
    ],
    circle_id: "2"
} ]);

// ----------------------------
// Collection structure for circle
// ----------------------------
db.getCollection("circle").drop();
db.createCollection("circle");

// ----------------------------
// Documents of circle
// ----------------------------
db.getCollection("circle").insert([ {
    _id: "66caefeeb018527ac0fc54e3",
    avatar: "https://gd-hbimg.huaban.com/404953d7b5259f2c3a2704c081aea8719c43f4c7104c3-ZXO6fd_fw658webp",
    introduce: "🌐 操作系统 🖥️\n\n欢迎探索操作系统的奥秘，加入我们的知识圈，开启你的计算机考研之旅！🚀\n\n📚 数据宝库：我们为你准备了丰富的学习资料库，包括上岸学长的详细知识笔记、知名教学up主的直观思维导图，以及官方考纲考点的精准提炼。总数据集超过60G+，是你考研路上的得力助手。📊\n\n🎯 精准练习：根据考纲设计的对点练习题，让你的复习更加有的放矢。参与学习任务打榜赛，与圈内高手一较高下，让你的每一步都走得更加坚实。🏋️‍♂️\n\n🏆 共同进步：在这里，你将遇到许多志同道合的学习者。我们互相帮助，分享彼此的经验和心得，互相鼓励，共同在操作系统的知识海洋中乘风破浪。🌊\n\n🤖 AI辅助：话题AI专注于操作系统领域，使用知识圈共享的知识库为你提供精准的关联回答，让学习更加高效。🔍\n\n🛠️ 工具集成：我们还为你准备了流程图一键生成、思维导图生成、笔记生成等实用小工具，让你的学习更加得心应手。🔧\n\n加入我们，一起深入操作系统的核心，掌握计算机的灵魂，让操作系统成为你实现梦想的有力翅膀！🦅",
    ai_key: "fastgpt-SxSwEegL9wJuWGzNfgstizw25PL6jK4WV3SrYfF6egGM9FKPuV7iB7HZFOT3",
    tag: NumberLong("3"),
    circle_id: "3",
    name: "操作系统"
} ]);
db.getCollection("circle").insert([ {
    _id: "66caf07bb018527ac0fc54e6",
    avatar: "https://gd-hbimg.huaban.com/11f2c25f0322f01e7818578967d9d87c83b42928f01f-L1YlMg",
    introduce: "🌟 数据结构知识圈介绍 🌐\n\n📚 数据集支撑：我们的知识圈拥有海量的数据集，为你的考研之路提供坚实的数据支撑。📊\n\n考纲考点：详尽的考纲考点，让你对考试内容了如指掌。\n学长笔记：上岸学长的宝贵知识笔记，带你领略成功者的足迹。\n思维导图：知名教学up主的思维导图，帮你构建清晰的知识框架。\n考纲考点提炼：官方的考纲考点精细提炼，让你的学习更加高效。\n数据集大小：总数据集高达60G+，内容丰富，资料齐全。\n🏆 学习活动：加入我们，你将参与到各种学习活动中，包括：\n\n对点练习题：针对性的练习题，让你在实践中提升。\n学习任务打榜赛：通过竞赛激发你的学习热情，一步步走向巅峰。\n🤝 互助与分享：在这里，你不是一个人在战斗。\n\n互相帮助：圈子成员之间互相帮助，共同进步。\n分享经验：分享你的学习经验，同时也从他人那里获取宝贵的建议。\n互相鼓励：在困难时刻，我们互相鼓励，共同克服。\n🤖 话题AI：我们的话题AI专注于数据结构领域，为你提供专业的服务。\n\n知识库关联回答：使用知识圈共享的知识库，为你的问题提供精准的答案。\n小工具集成：流程图一键生成、思维导图生成、笔记生成等工具，让你的学习更加便捷。\n🚀 加入我们的数据结构知识圈，让我们一起在数据的海洋中遨游，攀登知识的高峰！🌉📈📖",
    ai_key: "fastgpt-QrfAXEWKYQCdoIkAhgU94FdK4gB2t0lKtg8Bak9zzrDneywF5XU8FZpirRB",
    circle_id: "4",
    name: "数据结构与算法",
    tag: NumberLong("4")
} ]);
db.getCollection("circle").insert([ {
    _id: "66caf07bb018527ac0fc54e7",
    avatar: "https://gd-hbimg.huaban.com/27218f0917846d22f5fe65162e97174c1f983b7215362-KviOb1_fw658webp",
    introduce: "🎓 计算机组成原理 💾\n\n欢迎来到计算机组成原理的知识圈，这里是一个充满数据和智慧的宝库，专为计算机考研的你量身打造！🌟\n\n📚 数据集支撑：我们拥有丰富的学习资源，包括上岸学长的珍贵笔记、知名教学up主的思维导图，以及官方考纲考点的精细提炼。总数据集高达60G+，为你的考研之路提供坚实的数据支撑。📈\n\n🏋️ 实战演练：加入我们，你将获得根据考纲设计的对点练习题，参与学习任务打榜赛，与众多学习者一起切磋技艺。跟着圈子的步骤，你将逐步攀登学习的高峰，直至巅峰。🏆\n\n🤝 互助共进：在这里，你会遇到许多志同道合的伙伴。我们互相帮助，分享经验，互相鼓励，共同在计算机组成原理的海洋中乘风破浪。🚀\n\n🤖 AI助力：话题AI将使用知识圈共享的知识库进行关联回答，专注于该领域，为你提供精准的信息和解答。\n\n🛠️ 工具集成：我们还为你准备了流程图一键生成、思维导图生成、笔记生成等实用小工具，让你的学习更加高效。\n\n加入我们，一起探索计算机的奥秘，让计算机组成原理成为你实现梦想的坚实基石！🌈",
    ai_key: "fastgpt-UCL2wYYZJY7QGebMPUmtxHmHIDFiW2HGTRXNqxi9kovh4etFjy2p6HYpbmtz",
    circle_id: "1",
    name: "计算机组成原理",
    tag: NumberLong("1")
} ]);
db.getCollection("circle").insert([ {
    _id: "66caf07bb018527ac0fc54e8",
    avatar: "https://gd-hbimg.huaban.com/81bf523ee5ec3e0e45bd6a6734dce69e377280c118fbb-wXTw1c",
    introduce: "🌐 计算机网络考研知识圈 🚀\n\n🎯 数据集支撑：\n\n📚 上岸学长笔记：深入理解，实战经验，带你飞速提升！\n🗺️ 教学UP主导图：清晰思维，逻辑清晰，让你一目了然！\n📊 官方考纲考点：精细提炼，精准把握，让你考试无忧！\n📈 学习活动：\n\n📝 对点练习题：针对性强，巩固基础，让你步步为营！\n🏆 学习任务打榜赛：激发斗志，挑战自我，助你攀登高峰！\n🤝 互助社区：\n\n👥 互相帮助：分享经验，共同进步，我们是一个团队！\n💪 互相鼓励：正能量满满，让你的学习之路不再孤单！\n📖 数据集详情：\n\n📁 总数据集：高达60G+，内容丰富，资料全面！\n🔍 AI关联回答：智能AI，使用知识库，为你提供精准答案！\n🛠️ 实用工具集成：\n\n📊 流程图生成：一键操作，快速生成，让你的逻辑更清晰！\n🗺️ 思维导图：结构化思维，帮助你构建知识网络！\n📝 笔记生成：整理要点，记录精华，让你的复习更高效！\n🌟 加入我们，一起在计算机网络的海洋中遨游，共同迎接考研的挑战！🚀🌟",
    ai_key: "fastgpt-iudzs4oeEeCtFNCx6hjlPUi4b7fdlTATTp8Xo1macLzRJJDo2ZgjR15FC",
    circle_id: "2",
    name: "计算机网络",
    tag: NumberLong("2")
} ]);

// ----------------------------
// Collection structure for draft
// ----------------------------
db.getCollection("draft").drop();
db.createCollection("draft");

// ----------------------------
// Documents of draft
// ----------------------------
db.getCollection("draft").insert([ {
    _id: ObjectId("6761660e77098d75262feed5"),
    circle_id: "1",
    pictures: [
        "https://gitee.com/shiheiyea/heiye-figure-bed/raw/master/8e6dc43c4369438dbbbdea87505be0e7.jpg"
    ],
    title: "GDRD-039",
    word: "车牌号",
    uid: "1000003",
    topicId: "54",
    _class: "com.org.oracle.mongodb.entity.CircleContext"
} ]);
db.getCollection("draft").insert([ {
    _id: "1s11aa",
    pictures: [
        "http://example.com/image1.jpg",
        "http://example.com/image2.jpg"
    ],
    title: "这是一个笔记标题",
    word: "<p>这是笔记的内容，可以包含富文本格式。</p>",
    uid: "1000001",
    topicId: "topic012",
    create_time: ISODate("2024-08-15T06:12:00.000Z"),
    update_time: ISODate("2024-08-15T06:12:00.000Z"),
    _class: "com.org.oracle.mongodb.entity.CircleContext"
} ]);
db.getCollection("draft").insert([ {
    _id: "1s11af3",
    pictures: [
        "http://example.com/image1.jpg",
        "http://example.com/image2.jpg"
    ],
    title: "这是一个笔记标题",
    word: "<p>这是笔记的内容，可以包含富文本格式。</p>",
    uid: "1000001",
    topicId: "topic012",
    create_time: ISODate("2024-08-15T06:12:00.000Z"),
    update_time: ISODate("2024-08-15T06:12:00.000Z"),
    _class: "com.org.oracle.mongodb.entity.CircleContext"
} ]);
db.getCollection("draft").insert([ {
    _id: "1735206669816dvtJDE",
    title: "aaa",
    word: "aaaaaaa",
    uid: "1000003",
    topicId: "54",
    create_time: ISODate("2024-12-26T09:51:09.000Z"),
    _class: "com.org.oracle.mongodb.entity.CircleContext"
} ]);
db.getCollection("draft").insert([ {
    _id: "1735298745633dAce0N",
    title: "a'a'a",
    word: "反反复复",
    uid: "1000003",
    topicId: "1",
    create_time: ISODate("2024-12-27T11:25:45.000Z"),
    _class: "com.org.oracle.mongodb.entity.CircleContext"
} ]);
db.getCollection("draft").insert([ {
    _id: "1735299173064Rk3J5W",
    title: "对对对",
    word: "孤寡孤寡",
    uid: "1000003",
    topicId: "1",
    create_time: ISODate("2024-12-27T11:32:53.000Z"),
    _class: "com.org.oracle.mongodb.entity.CircleContext"
} ]);
db.getCollection("draft").insert([ {
    _id: "1735299498601tsXb3A",
    title: "aaaa",
    word: "飞飞飞飞飞",
    uid: "1000003",
    topicId: "1",
    create_time: ISODate("2024-12-27T11:38:18.000Z"),
    _class: "com.org.oracle.mongodb.entity.CircleContext"
} ]);
db.getCollection("draft").insert([ {
    _id: "1735299907805g0sidD",
    title: "啊啊啊",
    word: "孤寡孤寡",
    uid: "1000003",
    topicId: "1",
    create_time: ISODate("2024-12-27T11:45:07.000Z"),
    _class: "com.org.oracle.mongodb.entity.CircleContext"
} ]);
db.getCollection("draft").insert([ {
    _id: "1735377466567w1BDx1",
    title: "啊啊啊啊",
    word: "发发发发发发发发发发$哈哈哈哈哈宝宝",
    uid: "1000003",
    topicId: "66",
    create_time: ISODate("2024-12-28T09:17:46.000Z"),
    _class: "com.org.oracle.mongodb.entity.CircleContext"
} ]);

// ----------------------------
// Collection structure for knowledge_base
// ----------------------------
db.getCollection("knowledge_base").drop();
db.createCollection("knowledge_base");

// ----------------------------
// Documents of knowledge_base
// ----------------------------

// ----------------------------
// Collection structure for members
// ----------------------------
db.getCollection("members").drop();
db.createCollection("members");

// ----------------------------
// Documents of members
// ----------------------------
db.getCollection("members").insert([ {
    _id: "042875571275796",
    circleId: "1",
    uid: "1000001",
    _class: "com.org.oracle.mongodb.entity.Member"
} ]);

// ----------------------------
// Collection structure for note
// ----------------------------
db.getCollection("note").drop();
db.createCollection("note");

// ----------------------------
// Documents of note
// ----------------------------
db.getCollection("note").insert([ {
    _id: "RandomString_1abc",
    circle_id: "1",
    pictures: [
        "https://sns-webpic-qc.xhscdn.com/202412272252/986777c982d72ad445b8f25374f092cc/1040g00831anlrqet7e005oohdjp4g595obg054o!nc_n_webp_mw_1",
        "https://sns-webpic-qc.xhscdn.com/202412272217/b2b9914e3316f5106e19d3cc82e10475/1040g00830tse1htd50505old87qmo4atarlu2ng!nc_n_webp_mw_1"
    ],
    title: "408计算机组成原理知识点汇总",
    word: "408计算机组成原理知识点汇总\n欢迎小伙伴们加入我的备考之旅！首先计算机组成原理分为指令系统、内存系统、文件系统、IO系统几个部分等等，",
    uid: "1000003",
    topicId: "66"
} ]);
db.getCollection("note").insert([ {
    _id: "Ranfaegsf",
    circle_id: "1",
    pictures: [
        "https://sns-webpic-qc.xhscdn.com/202412272251/14d99411170e403df34ee28a3538a170/1040g2sg3196jhlf356b05nnknf9gbi33nbhstog!nc_n_webp_mw_1",
        "https://sns-webpic-qc.xhscdn.com/202412272217/b2b9914e3316f5106e19d3cc82e10475/1040g00830tse1htd50505old87qmo4atarlu2ng!nc_n_webp_mw_1"
    ],
    title: "408计算机组成原理知识点汇总",
    word: "总线和输入输出系统是计算机的血脉，它们负责数据的流动和交互，是理解计算机运作的关键。",
    uid: "1000003",
    topicId: "66"
} ]);
db.getCollection("note").insert([ {
    _id: "1dxq2wwt6thrgnDWS",
    circle_id: "1",
    pictures: [
        "https://sns-webpic-qc.xhscdn.com/202412280944/2b02279e47adc37abe1439a8cead6413/1040g2sg30q6njovanm6g5npfj1tg9arrpcogcf8!nc_n_webp_mw_1",
        "https://sns-webpic-qc.xhscdn.com/202412280955/8a0fd9f5d850ce3a24b5568f11bee18c/1040g2sg30q6njovanm5g5npfj1tg9arr4rhahug!nd_dft_wlteh_webp_3"
    ],
    title: "计组强化|总线相关知识汇总",
    word: "通过计组强化感觉对这门课的恐惧性大大降低了，他其实考的也没有那么难，弄懂架构之后很快就能理出来。唯一不足就是知识点有点多，很容易遗忘，所以需要常常复习",
    uid: "1000001",
    topicId: "66"
} ]);
db.getCollection("note").insert([ {
    _id: "Ra3f4eSt23rfecdabc",
    circle_id: "1",
    pictures: [
        "https://sns-webpic-qc.xhscdn.com/202412272245/46f5f5eadc3f3172de7ff36c2867c2d6/1040g008319l2mpem7a3g5pmpnvj7ef6442du7no!nc_n_webp_mw_1",
        "https://sns-webpic-qc.xhscdn.com/202412272245/23d364f4af4b85050182b8588afdcd9d/1000g0082ch62pl2h20005o1532lg84fs6fie9h8!nc_n_webp_mw_1"
    ],
    title: "计算机组成原理系统总线",
    word: "计算机组成原理系统总线的笔记我总结了这些 大家一起来看看吧",
    uid: "1000003",
    topicId: "66"
} ]);
db.getCollection("note").insert([ {
    _id: "g2345rfea",
    circle_id: "1",
    pictures: [
        "https://sns-webpic-qc.xhscdn.com/202412272252/7f3a70898fec9677cbbb7786a7220bd1/1040g2sg312ujs80r5u705nol7seg8lvi1q52g10!nc_n_webp_mw_1",
        "https://sns-webpic-qc.xhscdn.com/202412272252/1c8a8f85e7de65fcab54afed6a404589/1040g00831atikf117e6g5otqt459gqoomatmr18!nc_n_webp_mw_1"
    ],
    title: "总线和I/O系统就像是计算机的四肢，它们让计算机能够与世界互动。",
    word: "总线和I/O系统就像是计算机的四肢，它们让计算机能够与世界互动。",
    uid: "1000003",
    topicId: "66"
} ]);
db.getCollection("note").insert([ {
    _id: "1c2x33454cxvtreds",
    circle_id: "1",
    pictures: [
        "https://sns-webpic-qc.xhscdn.com/202412272252/ea64947476415ec040be76a5b9d5a2f2/01025v01klz9l9riqmo011b5vyydhrtdba!nc_n_webp_mw_1",
        "https://sns-webpic-qc.xhscdn.com/202412272252/1c8a8f85e7de65fcab54afed6a404589/1040g00831atikf117e6g5otqt459gqoomatmr18!nc_n_webp_mw_1"
    ],
    title: "主存储器和CPU连接🚀",
    word: "计算机组成原理名词解析",
    uid: "1000003",
    topicId: "66"
} ]);
db.getCollection("note").insert([ {
    _id: "123456",
    circle_id: "1",
    pictures: [
        "https://sns-webpic-qc.xhscdn.com/202412272252/97a1cfaeaaf3aefbde03eccde78460af/1040g2sg31b1h55junec05ol5aep8cok95rb97fg!nc_n_webp_mw_1",
        "https://sns-webpic-qc.xhscdn.com/202412272252/393420d5b96a8a517f03b984568282e4/01024h01khboo8riawi0116um5ica9if0z!nc_n_webp_mw_1"
    ],
    title: "计组 6.1 总线概述",
    word: "计组 6.1 总线概述",
    uid: "1000003",
    topicId: "66"
} ]);
db.getCollection("note").insert([ {
    _id: "g324egt3",
    circle_id: "1",
    pictures: [
        "https://sns-webpic-qc.xhscdn.com/202412280944/43b3180d5deb9c950b24f5316bbdb87f/1040g2sg31aoh4drfngb05o8bgca08nege9brht0!nc_n_webp_mw_1"
    ],
    title: "计算机组成原理总线定时通信控制",
    word: "计算机组成原理总线定时通信控制下，中断又应该如何去进行呢？",
    uid: "1000003",
    topicId: "66"
} ]);
db.getCollection("note").insert([ {
    _id: "b456we6gt7ujjj",
    circle_id: "1",
    pictures: [
        "https://sns-webpic-qc.xhscdn.com/202412280944/5b88fb871ddf9bb4d135394ae5aada9a/1000g0081lj100ikcm0605o58r10g866nivign4o!nc_n_webp_mw_1"
    ],
    title: "从不一样的角度去理解总线",
    word: "其实总线就是计算机系统的高速公路，各个部件想要传输信息或控制信号都需要经过他去传播",
    uid: "1000001",
    topicId: "66"
} ]);
db.getCollection("note").insert([ {
    _id: "123",
    circle_id: "1",
    pictures: [
        "https://sns-webpic-qc.xhscdn.com/202412280944/c34041b7d73c8a0a54daf237632e8c01/1040g008317v5c1higm105ofondhk1dvi3f8laa0!nc_n_webp_mw_1"
    ],
    title: "计算机组成原理总线强化总结笔记",
    word: "计算机组成原理总线强化总结笔记",
    uid: "1000002",
    topicId: "66"
} ]);
db.getCollection("note").insert([ {
    _id: "Ranf341dd1abc",
    circle_id: "0",
    pictures: [
        "https://sns-webpic-qc.xhscdn.com/202412281358/0bb547d56ec194f0f3d7ff6dd778f887/1040g2sg3187vnrrd3u705n6gj3c5irqho9jlgso!nc_n_webp_mw_1",
        "https://sns-webpic-qc.xhscdn.com/202412281358/271b4a87d58f93086b9a28d3100efbb0/1040g2sg3187vnrrd3u7g5n6gj3c5irqhdncsbmg!nd_dft_wlteh_webp_3"
    ],
    title: "疯了💥这些专业统统改考计算机408",
    word: "人人都奔着计算机专业毕业后的高工资高就业率去勇敢跨考，但招生人数是固定的❗️越多的人跨考，就意味越多的人跨考失败落榜，这个数字每年高达几十万人！",
    uid: "1000002",
    topicId: "0"
} ]);
db.getCollection("note").insert([ {
    _id: "R453dfd3",
    circle_id: "0",
    pictures: [
        "https://sns-webpic-qc.xhscdn.com/202412281359/608177d94dcf64f9f26876772bb86dd1/1040g2sg3140rnke3hcdg5pf35ul19rj83ts9u40!nd_dft_wlteh_webp_3",
        "https://sns-webpic-qc.xhscdn.com/202412281359/06eabd66b852049cb48bc4dec460504c/1040g2sg3140rnke3hcd05pf35ul19rj8s1l6j38!nd_dft_wgth_webp_3"
    ],
    title: "第一年改考408，会不会爆冷啊？",
    word: "首先，985和前排的211（例如刚刚改考的北京交通大学），不仅仅不会爆冷，反而可能更加炸裂，因为这些院校，很容易受到大佬们的关注，大佬们本来复习的就是408，所以这些学校改考408，对他们来说也是多了一种选择。而且这种学校本身也不在大多数同学的考虑范围内，因此，好学校改考与否，对竞争性并无影响。",
    uid: "1000002",
    topicId: "0"
} ]);
db.getCollection("note").insert([ {
    _id: "R4f34DFGGd3",
    circle_id: "0",
    pictures: [
        "https://sns-webpic-qc.xhscdn.com/202412281401/c0d0a4476cd86ca913333669269605b6/1040g2sg3189lupmegm605p3487m51rjuh81ehk8!nc_n_webp_mw_1"
    ],
    title: "官宣！改考408的院校汇总！",
    word: "官宣！改考408的院校汇总！",
    uid: "1000002",
    topicId: "0"
} ]);
db.getCollection("note").insert([ {
    _id: "R4Dh56Gjjd3",
    circle_id: "0",
    pictures: [
        "https://sns-webpic-qc.xhscdn.com/202412281401/cda5bb38e68c3ae2dc87559468888339/1040g2sg318jlhlc2kc0g5of3gd640r26anem030!nc_n_webp_mw_1"
    ],
    title: "超过120所院校新增改考408！",
    word: "在预报名前会整理成全国所有省份的专业目录供各位考生择校",
    uid: "1000002",
    topicId: "0"
} ]);
db.getCollection("note").insert([ {
    _id: "BG6653dfd3",
    circle_id: "0",
    pictures: [
        "https://sns-webpic-qc.xhscdn.com/202412281401/8edc2c495c291b3aef37e9eddd786f69/1040g008319b0fvd85m005p5lti72k135lm18a4g!nc_n_webp_mw_1"
    ],
    title: "242所！25考研计算机408院校汇总最终版！",
    word: "242所！25考研计算机408院校汇总最终版！",
    uid: "1000002",
    topicId: "0"
} ]);
db.getCollection("note").insert([ {
    _id: "H6632d3dfd3",
    circle_id: "0",
    pictures: [
        "https://sns-webpic-qc.xhscdn.com/202412281402/f175b984d42b68f2533a225f820da92c/1040g2sg31bgk8k0f166g5p5lti72k1354f9jl98!nc_n_webp_mw_1"
    ],
    title: "25考研改考408的院校盘点！",
    word: "25考研改考408的院校盘点！",
    uid: "1000002",
    topicId: "0"
} ]);
db.getCollection("note").insert([ {
    _id: "7v6ytjhfc34evMKd3",
    circle_id: "0",
    pictures: [
        "https://sns-webpic-qc.xhscdn.com/202412281405/7a248d9bfb11b10b059df6337ac39236/1040g00831bf3bjea7a0g5on67tgmo4j1u7k0798!nc_n_webp_mw_1"
    ],
    title: "寒假回去408 要怎样复习才可以上 120？",
    word: "寒假回去408 要怎样复习才可以上 120？",
    uid: "1000002",
    topicId: "0"
} ]);
db.getCollection("note").insert([ {
    _id: "V3erdfd3",
    circle_id: "0",
    pictures: [
        "https://sns-webpic-qc.xhscdn.com/202412281405/91e9f9130b97c90f295dc531d2bf6abd/1040g2sg31bcv18mpmu5g5pk99bdiu49bk83npr8!nc_n_webp_mw_1"
    ],
    title: "上海交大计算机考研408上岸经验贴",
    word: "复试经验也有，机考经验在文末，希望大家都能考上理想院校。",
    uid: "1000002",
    topicId: "0"
} ]);
db.getCollection("note").insert([ {
    _id: "kj678ffd3",
    circle_id: "0",
    pictures: [
        "https://sns-webpic-qc.xhscdn.com/202412281405/e90b893b5c0c60cc60c2890d19f9ff40/1040g00831bn9cr00gm005pr157b63r3ddugaj2g!nc_n_webp_mw_1"
    ],
    title: "因为淋过雨，给26考研408的同学一点建议",
    word: "因为淋过雨，给26考研408的同学一点建议",
    uid: "1000002",
    topicId: "0"
} ]);
db.getCollection("note").insert([ {
    _id: ObjectId("676fc23414183f712b7dd394"),
    circle_id: "1",
    title: "啊啊啊啊",
    word: "发发发发发发发发发发$哈哈哈哈哈宝宝",
    uid: "1000003",
    topicId: "66",
    create_time: ISODate("2024-12-28T09:17:40.271Z"),
    update_time: ISODate("2024-12-28T09:17:40.271Z"),
    _class: "com.org.oracle.mongodb.entity.CircleContext"
} ]);

// ----------------------------
// Collection structure for question_comments
// ----------------------------
db.getCollection("question_comments").drop();
db.createCollection("question_comments");

// ----------------------------
// Documents of question_comments
// ----------------------------
db.getCollection("question_comments").insert([ {
    _id: ObjectId("67516e3eaa3944b9ffadbbf8"),
    questionId: "1",
    commentId: "comment001",
    rootCommentId: "-1",
    content: "数据结构开端！",
    replyToUid: "user002",
    replyToCommentId: "",
    createBy: "user001",
    likes: NumberInt("5")
} ]);
db.getCollection("question_comments").insert([ {
    _id: ObjectId("67516e3eaa3944b9ffadbbf9"),
    questionId: "1",
    commentId: "comment002",
    rootCommentId: "67516e3eaa3944b9ffadbbf8",
    content: "一起加油！26考研加油！",
    replyToUid: "user003",
    replyToCommentId: "",
    createBy: "user004",
    likes: NumberInt("2")
} ]);
db.getCollection("question_comments").insert([ {
    _id: ObjectId("67516e3eaa3944b9ffadbbfa"),
    questionId: "1",
    commentId: "comment003",
    rootCommentId: "67516e3eaa3944b9ffadbbf8",
    content: "26考研，共勉！",
    replyToUid: "user001",
    replyToCommentId: "",
    createBy: "user002",
    likes: NumberInt("3")
} ]);
db.getCollection("question_comments").insert([ {
    _id: ObjectId("67516e3eaa3944b9ffadbbfb"),
    questionId: "1",
    commentId: "comment004",
    rootCommentId: "-1",
    content: "408，冲冲冲！",
    replyToUid: "user005",
    replyToCommentId: "",
    createBy: "user003",
    likes: NumberInt("7")
} ]);
db.getCollection("question_comments").insert([ {
    _id: ObjectId("67516e3eaa3944b9ffadbbfc"),
    questionId: "2",
    commentId: "comment005",
    rootCommentId: "-1",
    content: "平芜尽处是春山，追风赶月莫停留！",
    replyToUid: "user004",
    replyToCommentId: "",
    createBy: "user005",
    likes: NumberInt("4")
} ]);

// ----------------------------
// Collection structure for study_points_list
// ----------------------------
db.getCollection("study_points_list").drop();
db.createCollection("study_points_list");

// ----------------------------
// Documents of study_points_list
// ----------------------------
db.getCollection("study_points_list").insert([ {
    _id: ObjectId("66d172fcd2fe207de968445b"),
    circle_id: "1",
    _class: "org.heiye.test.entity.StudyPointsList",
    list: [
        {
            uid: "1000001",
            week_points: NumberInt("342"),
            month_points: NumberInt("862"),
            sum_points: NumberInt("862"),
            address: "广州市"
        }
    ]
} ]);

// ----------------------------
// Collection structure for user
// ----------------------------
db.getCollection("user").drop();
db.createCollection("user");

// ----------------------------
// Documents of user
// ----------------------------
db.getCollection("user").insert([ {
    _id: ObjectId("6708e4a9f81d1917b57bfa6c"),
    uid: "1000001",
    openid: "123456",
    _class: "com.org.oracle.mongodb.entity.User",
    address: "广东省",
    avatar: "https://gitee.com/shiheiyea/heiye-figure-bed/raw/master/13aee0ba5a2b4307ba16e8d4f2120cab.jpg",
    name: "黑夜",
    status: 0,
    createTime: ISODate("2024-12-03T08:19:03.98Z"),
    updateTime: ISODate("2024-12-06T17:34:45.579Z"),
    password: "$2a$10$gyoT/Wu0p2r.EtIoRSh0VeX.dgE63Te5ageYyHQsF8mv0W9AYm736",
    update_time: ISODate("2024-12-09T08:43:57.703Z"),
    email: "2759688992@qq.com",
    introduction: "反派角色",
    sex: NumberInt("1"),
    birthday: ISODate("2024-12-01T16:00:00.000Z")
} ]);
db.getCollection("user").insert([ {
    _id: ObjectId("674ebef80cd0d17f2e314b86"),
    uid: "1000002",
    name: "白鸽",
    email: "shiheiyea@qq.com",
    password: "$2a$10$e2iiDy5Gel6qSiEgertQ6eCM8WIldg6C0f/FhJsm7wdvMAJ4wkVjS",
    status: NumberInt("0"),
    createTime: ISODate("2024-12-03T08:19:03.98Z"),
    updateTime: ISODate("2024-12-03T08:19:03.98Z"),
    _class: "com.org.oracle.mongodb.entity.User",
    update_time: ISODate("2024-12-06T12:31:29.973Z"),
    birthday: null
} ]);
db.getCollection("user").insert([ {
    _id: ObjectId("6756971b1fb7680c8ae1ab15"),
    uid: "1000003",
    name: "Chao",
    email: "2372558841@qq.com",
    password: "$2a$10$t.n0Se3yLtE8M6y8tWk/M..iatiFiBbPpmcgzSEqMRynI8L9zDbDW",
    status: NumberInt("0"),
    create_time: ISODate("2024-12-09T07:07:07.599Z"),
    update_time: ISODate("2024-12-28T09:13:21.129Z"),
    _class: "com.org.oracle.mongodb.entity.User",
    avatar: "https://gitee.com/shiheiyea/heiye-figure-bed/raw/master/fa79f0c8f6c34a459beded57e2b0dbe2.jpg",
    birthday: ISODate("2004-11-11T16:00:00.000Z"),
    introduction: "nihao,我是chaos"
} ]);
