package com.org.oracle.mongodb.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: heiye
 * @date: 2024/11/29 上午10:49
 * @version: v1.0.0
 * @description: 知识圈详细信息
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserDetailCircleVO {
    /**
     * 用户唯一标识
     */
    private String uid;

    /**
     * 用户昵称
     */
    private String name;

    /**
     * 用户头像
     */
    private String avatar;

    /**
     * 个人简介
     */
    private String introduction;
    /**
     * 学习进度
     */
    private String studyProgress;
    /**
     * 签到数
     */
    private Long attendance;
    /**
     * 获得点赞总数
     */
    private Long likeTotal;
    /**
     * 获得点亮总数
     */
    private Long brightTotal;
}
