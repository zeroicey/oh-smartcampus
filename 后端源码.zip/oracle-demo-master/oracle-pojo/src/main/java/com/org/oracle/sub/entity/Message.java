package com.org.oracle.sub.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author: heiye
 * @CreateTime: 2024/09/09 下午5:42
 * @Description: 对话内容对象
 * @Version: 1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Message {
    /**
     * 角色
     */
    private String role;

    /**
     * 说话内容
     */
    private String content;
}
