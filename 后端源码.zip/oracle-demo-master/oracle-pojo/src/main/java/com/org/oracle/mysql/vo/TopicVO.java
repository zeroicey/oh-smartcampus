package com.org.oracle.mysql.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: heiye
 * @date: 2024/11/17 下午9:20
 * @version: v1.0.0
 * @description: 话题AI VO
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TopicVO {
    /**
     * ID
     */
    private Long id;
    /**
     * 话题 AI 名称
     */
    private String name;
}
