package com.org.oracle.mysql.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author: heiye
 * @date: 2024/12/20 下午1:54
 * @version: v1.0.0
 * @description: 关注用户
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FollowUserMqDTO {
    /**
     * 用户ID
     */
    private String userId;
    /**
     * 关注的用户ID
     */
    private String followingUserId;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
}
