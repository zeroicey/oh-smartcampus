package com.org.oracle.mysql.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: heiye
 * @date: 2024/12/11 下午3:05
 * @version: v1.0.0
 * @description: 用户计数
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserCount {
    /**
     * ID
     */
    @TableId(type = IdType.AUTO)
    private Long id;
    /**
     * 用户ID
     */
    private String uid;
    /**
     * 发布笔记总数
     */
    private Long noteTotal;
    /**
     * 获得点赞总数
     */
    private Long likeTotal;
    /**
     * 获得收藏总数
     */
    private Long collectTotal;
    /**
     * 获得点亮总数
     */
    private Long brightTotal;
}
