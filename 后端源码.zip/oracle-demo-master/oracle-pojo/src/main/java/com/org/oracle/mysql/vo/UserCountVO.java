package com.org.oracle.mysql.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: heiye
 * @date: 2024/12/17 下午8:46
 * @version: v1.0.0
 * @description: 用户计数
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserCountVO {
    /**
     * UID
     */
    private String uid;
    /**
     * 发布笔记总数
     */
    private Long noteTotal;
    /**
     * 获得点赞总数
     */
    private Long likeTotal;
    /**
     * 获得点亮总数
     */
    private Long brightTotal;
}
