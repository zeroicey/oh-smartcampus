package com.org.oracle.mysql.entity;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * (UserCommitResults)表实体类
 *
 * @author luo
 * @since 2024-12-16 20:37:19
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("user_commit_results")
public class UserCommitResult {
    //答题记录ID
    @TableId
    private Long id;
    //用户ID
    private String uid;
    //科目ID
    private String subjectId;
    //章节ID
    private String chapterId;
    //总分
    private Float totalScore;
    //答对的题目数
    private Integer correctCount;
    //总题目数
    private Integer totalCount;
    //答题正确率，精度到百分比
    private Float accuracy;
    //提交状态（如：已完成、未完成）
    private String status;
    //提交时间
    private Date submittedAt;
    //本次答题总刷题时长（单位与时间戳一致,毫秒）
    private Long totalStudyTime;
    //创建时间
    private Date createdAt;
    //更新时间
    private Date updatedAt;
}

