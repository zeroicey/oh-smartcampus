package com.org.oracle.mysql.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ChapterProgressVo {
    /**
     * 章节ID
     */
    private String id;
    /**
     * 章节名称
     */
    private String name;
    /**
     * 章节题目数
     */
    private Integer questionNum;
    /**
     * 是否完成
     */
    private boolean isCompleted;
    /**
     * 最新提交时间
     */
    private Date lastTime;
    /**
     * 章节累计学习时间
     */
    private Long totalStudyTime;

}