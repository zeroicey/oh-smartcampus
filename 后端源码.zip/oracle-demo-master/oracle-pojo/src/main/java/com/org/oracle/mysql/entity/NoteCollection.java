package com.org.oracle.mysql.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author: heiye
 * @date: 2024/12/11 下午3:07
 * @version: v1.0.0
 * @description: 笔记收藏
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class NoteCollection {
    /**
     * ID
     */
    @TableId(type = IdType.AUTO)
    private Long id;
    /**
     * 用户ID
     */
    private String uid;
    /**
     * 笔记ID
     */
    private String noteId;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    /**
     * 收藏状态(0：取消收藏 1：收藏)
     */
    private Integer status;
}
