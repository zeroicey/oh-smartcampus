package com.org.oracle.mysql.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: heiye
 * @date: 2024/12/16 上午11:00
 * @version: v1.0.0
 * @description: 聚合后计数：收藏、取消收藏笔记
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AggregationCountCollectUnCollectNoteMqDTO {
    /**
     * 笔记发布者 ID
     */
    private String creatorId;
    /**
     * 笔记 ID
     */
    private String noteId;
    /**
     * 聚合后的计数
     */
    private Integer count;
}
