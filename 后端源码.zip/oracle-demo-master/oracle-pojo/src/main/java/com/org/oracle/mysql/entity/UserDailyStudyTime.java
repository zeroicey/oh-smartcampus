package com.org.oracle.mysql.entity;

import java.util.Date;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * (UserDailyStudyTime)表实体类
 *
 * @author luo
 * @since 2024-12-16 21:22:13
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("user_daily_study_time")
public class UserDailyStudyTime  {
    //每日刷题时间记录ID
    @TableId
    private Long id;
    //用户ID
    private String uid;
    //日期，记录是哪天的刷题时间
    private Date date;
    //当天刷题总时长（单位与时间戳一致，毫秒，通过计算每道题时间累加得出）
    private Long totalStudyTime;
    //创建时间
    private Date createdAt;
    //更新时间
    private Date updatedAt;
}

