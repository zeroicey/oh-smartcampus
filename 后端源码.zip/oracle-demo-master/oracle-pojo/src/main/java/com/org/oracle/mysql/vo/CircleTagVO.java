package com.org.oracle.mysql.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author: heiye
 * @date: 2024/11/18 上午11:11
 * @version: v1.0.0
 * @description: 知识圈标签VO
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CircleTagVO {
    /**
     * 主键
     */
    private Long id;
    /**
     * 标签名称
     */
    private String name;
    /**
     * 方便前端选择
     */
    @TableField(exist = false)
    private Boolean isSelected = false;
}
