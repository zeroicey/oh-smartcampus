package com.org.oracle.mysql.dto;

import com.org.oracle.sub.dto.PageRequestDTO;
import lombok.Data;

/***
 * @title FindSchoolSearchDTO
 * @author SUZE
 * @Date 15:10
 **/
@Data
public class FindSchoolSearchDTO extends PageRequestDTO {
    private String school;

}
