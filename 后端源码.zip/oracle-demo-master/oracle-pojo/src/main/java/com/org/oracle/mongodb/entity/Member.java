package com.org.oracle.mongodb.entity;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

import java.io.IOException;

/**
 * @author suze
 * @date 2024/8/18
 * @time 20:44
 **/
@Document(collection = "members")
@Data
public class Member {//知识圈成员

    private String id;
    private String circleId;
    private String uid;
}
