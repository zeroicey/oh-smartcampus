package com.org.oracle.mysql.dto;

import com.org.oracle.sub.dto.PageRequestDTO;
import lombok.Data;

/***
 * @title FindRangeSearchDTO
 * @author SUZE
 * @Date 13:10
 **/
@Data
public class FindRangeSearchDTO extends PageRequestDTO {

    private String region; // 地区
    /**
     * 二级专业。前端视角的大专业
     */
    private String secondaryMajor;

    /**
     * 三级专业。前端视角的小专业
     */
    private String tertiaryMajor;


}
