package com.org.oracle.mysql.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Field;

import java.time.LocalDateTime;

/**
 * @author: heiye
 * @date: 2024/12/20 上午10:43
 * @version: v1.0.0
 * @description: 用户关注表
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Following {
    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long id;
    /**
     * 用户ID
     */
    private String userId;
    /**
     * 关注的用户ID
     */
    private String followingUserId;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
}
