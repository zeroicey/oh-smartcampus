package com.org.oracle.mysql.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: heiye
 * @date: 2024/12/20 下午6:29
 * @version: v1.0.0
 * @description: 计数：关注、取关
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CountFollowUnfollowMqDTO {
    /**
     * 原用户
     */
    private String userId;
    /**
     * 目标用户ID
     */
    private String targetUserId;
    /**
     * 1:关注 0:取关
     */
    private Integer type;
}
