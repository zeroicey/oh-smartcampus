package com.org.oracle.mysql.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/***
 * @title NoteLikeResponseVO
 * @author SUZE
 * @Date 8:51
 **/

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class NoteLikeResponseVO {
    private String noteId;
    private Long likeCount;
    //用户是否对该笔记点过赞
    private boolean isLike;
}
