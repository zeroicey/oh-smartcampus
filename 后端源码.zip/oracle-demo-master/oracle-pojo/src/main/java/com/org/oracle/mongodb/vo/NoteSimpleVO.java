package com.org.oracle.mongodb.vo;

import com.org.oracle.mysql.vo.TopicVO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author: heiye
 * @date: 2024/12/16 下午1:27
 * @version: v1.0.0
 * @description: 笔记简要信息
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class NoteSimpleVO {
    /**
     * 笔记ID
     */
    private String id;
    /**
     * 发布笔记作者ID
     */
    private String creatorId;
    /**
     * 发布笔记作者昵称
     */
    private String creatorName;
    /**
     * 发布笔记作者头像
     */
    private String creatorAvatar;
    /**
     * 笔记标题
     */
    private String title;
    /**
     * 笔记封面
     */
    private String picture;
    /**
     * 笔记获得喜欢数量
     */
    private Long likeTotal;
}
