package com.org.oracle.mongodb.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author: heiye
 * @date: 2024/11/18 上午10:35
 * @version: v1.0.0
 * @description: 知识圈内容VO
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class NoteVO {
    /**
     * 笔记ID
     */
    private String id;

    /**
     * 话题AI的ID
     */
    private String topicId;
    /**
     * 话题 AI 名称
     */
    private String topicName;
    /**
     * 发布笔记作者ID
     */
    private String creatorId;
    /**
     * 发布笔记作者昵称
     */
    private String creatorName;
    /**
     * 发布笔记作者头像
     */
    private String creatorAvatar;
    /**
     * 标题
     */
    private String title;
    /**
     * 图片集合，这里使用字符串列表来存储图片URL
     */
    private List<String> pictures;
    /**
     * 文字  可能要用到富文本
     */
    private String word;
    /**
     * 点赞总数
     */
    private Long likeTotal;
    /**
     * 收藏总数
     */
    private Long collectTotal;
    /**
     * 评论总数
     */
    private Long commentTotal;
    /**
     * 用户是否点赞了
     */
    private Boolean isLike;
    /**
     * 用户是否收藏了
     */
    private Boolean isCollect;
    /**
     * 用户是否关注笔记作者
     */
    private Boolean isFollowingCreator;
}
