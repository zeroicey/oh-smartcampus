package com.org.oracle.sub.dto;

import jakarta.validation.constraints.NotEmpty;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * @author: heiye
 * @date: 2024/12/06 上午9:15
 * @version: v1.0.0
 * @description: 邮箱校验
 */
@Data
public class EmailCheckDTO {
    /**
     * 邮箱
     */
    @NotEmpty
    private String email;
    /**
     * 验证码
     */
    @NotEmpty
    private String code;
}
