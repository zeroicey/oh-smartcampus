package com.org.oracle.sub.dto;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;


/**
 * @Author: heiye
 * @CreateTime: 2024/08/31 下午3:21
 * @Description: 分页DTO
 * @Version: 1.0
 */
@Data
public class PageRequestDTO {

    /**
     * 页码
     */
    protected Integer page;

    /**
     * 条数
     */
    protected Integer size;

    /**
     * 校验参数
     */
    public void checkParam() {
        if (this.page == null || this.page < 0) {
            setPage(0);
        }
        if (this.size == null || this.size < 0 || this.size > 100) {
            setSize(10);
        }
    }
}
