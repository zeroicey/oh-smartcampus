package com.org.oracle.mysql.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/***
 * @title HistoryTopicVO
 * @author SUZE
 * @Date 16:50
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class HistoryTopicVO {

    /**
     * ID
     */
    private Long id;
    /**
     * 话题 AI 名称
     */
    private String name;
    /**
     * 头像
     */
    private String avatar;
}
