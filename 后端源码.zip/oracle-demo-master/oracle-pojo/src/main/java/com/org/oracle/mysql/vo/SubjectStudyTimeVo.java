package com.org.oracle.mysql.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SubjectStudyTimeVo {
    /**
     * 科目ID
     */
    private String subjectId;
    /**
     * 科目名称
     */
    private String subjectName;
    /**
     * 当天该科目学习时间（分钟）
     */
    private long studyTimeInMinutes;
}