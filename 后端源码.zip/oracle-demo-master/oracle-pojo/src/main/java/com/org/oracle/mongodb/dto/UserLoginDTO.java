package com.org.oracle.mongodb.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @author: heiye
 * @date: 2024/10/11 下午1:56
 * @version: v1.0.0
 * @description: 用户登录
 */
@Data
public class UserLoginDTO implements Serializable {
    /**
     * 手机号
     */
    private String phoneNumber;
    /**
     * 邮箱
     */
    private String email;
    /**
     * 密码
     */
    private String password;
    /**
     * 登录类型：
     *      1：密码
     *      2：验证码
     */
    private Integer type;
    /**
     * 校验码
     */
    private String code;
}