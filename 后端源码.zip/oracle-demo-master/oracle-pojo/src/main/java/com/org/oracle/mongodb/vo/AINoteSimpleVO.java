package com.org.oracle.mongodb.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author: heiye
 * @date: 2024/11/12 下午12:39
 * @version: v1.0.0
 * @description: AI 笔记简单信息VO
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AINoteSimpleVO {
    /**
     * 笔记ID
     */
    private String id;

    /**
     * 笔记名称
     */
    private String name;

    /**
     * 最后修改时间
     */
    private LocalDateTime updateTime;
}
