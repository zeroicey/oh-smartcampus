package com.org.oracle.mysql.entity;

import cn.hutool.core.date.DateTime;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/19 下午4:13
 * 总任务库表
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Task implements Serializable {
    /**
     * 主键id
     */
    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 任务名
     */
    private String name;

    /**
     * 创建该任务的用户id
     */
    private String uid;

    /**
     * 归属知识圈
     */
    private String circleId;

    /**
     * 归属章节
     */
    private String chapter;

    /**
     * 内容
     */
    private String content;

    /**
     * 任务获得的积分
     */
    private Integer points;

    /**
     * 状态 0未接受；1正在挑战；2已完成
     */
    private Integer state;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更改时间
     */
    private LocalDateTime updateTime;
}
