package com.org.oracle.mongodb.dto;

import com.org.oracle.sub.dto.PageRequestDTO;
import lombok.Data;

/**
 * @author: heiye
 * @date: 2024/11/12 下午7:45
 * @version: v1.0.0
 * @description: 批量查询知识圈内容DTO
 */
@Data
public class CircleQueryBatchDTO extends PageRequestDTO {
    /**
     * 知识圈ID
     */
    private String circleId;

    /**
     * 话题ID
     */
    private Long topicId;
}
