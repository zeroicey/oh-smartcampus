package com.org.oracle.mongodb.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author: heiye
 * @date: 2024/12/06 下午8:44
 * @version: v1.0.0
 * @description: 用户编辑信息
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserEditInfoVO {
    /**
     * 昵称
     */
    private String name;
    /**
     * 头像
     */
    private String avatar;
    /**
     * 性别
     */
    private Integer sex;
    /**
     * 个人简介
     */
    private String introduction;
    /**
     * 邮箱地址
     */
    private String email;
    /**
     * 生日
     */
    private LocalDateTime birthday;
}
