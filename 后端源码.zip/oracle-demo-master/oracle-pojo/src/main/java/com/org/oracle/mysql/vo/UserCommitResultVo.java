package com.org.oracle.mysql.vo;

import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserCommitResultVo {
//    //答题记录ID
//    private Long id;
    //用户ID
    private String uid;
    //科目ID
    private String subjectId;
    //章节ID
    private String chapterId;
    //总分
    private Float totalScore;
    //答对的题目数
    private Integer correctCount;
    //总题目数
    private Integer totalCount;
    //答题正确率，精度到百分比
    private Float accuracy;
//    //考试状态（如：已完成、未完成）
//    private String status;
    // 答题用时，单位为分钟
    private Float studyTimeInMinutes;
}