package com.org.oracle.mysql.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * @author: heiye
 * @date: 2024/12/13 下午8:16
 * @version: v1.0.0
 * @description:
 */
@Data
public class CollectNoteDTO {
    /**
     * 笔记 ID
     */
    @NotNull(message = "笔记 ID 不能为空")
    private String noteId;
}
