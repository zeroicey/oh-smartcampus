package com.org.oracle.mongodb.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author: heiye
 * @date: 2024/11/12 上午9:15
 * @version: v1.0.0
 * @description: ai笔记返回数据
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AINoteVO {
    /**
     * 图片链接数组
     */
    private List<String> img;
    /**
     * 富文本笔记
     */
    private String word;
}
