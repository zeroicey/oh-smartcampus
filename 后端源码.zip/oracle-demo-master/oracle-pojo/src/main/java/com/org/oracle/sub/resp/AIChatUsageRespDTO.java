package com.org.oracle.sub.resp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: heiye
 * @date: 2024/11/15 上午12:19
 * @version: v1.0.0
 * @description: AI 对话中 usage 参数对象
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AIChatUsageRespDTO {

    private String prompt_tokens;

    private String completion_tokens;

    private String total_tokens;
}
