package com.org.oracle.mongodb.entity;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.org.oracle.sub.entity.DataSet;
import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @author suze
 * @date 2024/8/15
 * @time 14:12
 **/
@Data
@Document(collection = "note")
public class CircleContext {
    @Field("circle_id")
    private String circleId;

    private String id;

    /**
     * 图片集合，这里使用字符串列表来存储图片URL
     */
    private List<String> pictures;
    /**
     * 标题
     */
    private String title;
    /**
     * 文字  可能要用到富文本
     */
    private String word;
    /**
     * 用户id
     */
    private String uid;

    /**
    *话题id
     */
    private String topicId;

    /**
     * 创建时间
     */
    @Field("create_time")
    private LocalDateTime createTime;
    /**
     * 修改时间
     */
    @Field("update_time")
    private LocalDateTime updateTime;


    /**
     * 评论数组，该版本先不用
     */
    private List<Comment> comments;
}
