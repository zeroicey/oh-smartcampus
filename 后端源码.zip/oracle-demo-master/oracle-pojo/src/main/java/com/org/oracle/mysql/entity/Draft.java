package com.org.oracle.mysql.entity;/**
 * @author suze
 * @date 2024/12/11
 * @time 21:11
 **/

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author SuZe
 * @Description 草稿箱
 * @Date $ $
 * @Param $
 * @return $
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Draft {

        private int  cid;
        private String context;
        private long id;
        private long uid;

}
