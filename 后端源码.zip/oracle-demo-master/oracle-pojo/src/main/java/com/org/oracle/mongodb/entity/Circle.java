package com.org.oracle.mongodb.entity;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

/**
 * @author suze
 * @date 2024/8/18
 * @time 20:41
 **/

@Document(collection = "circle")
@Data
public class Circle {
    /**
     * 知识圈id  主键
     */
    @Field("circle_id")
    private String circleId;
    /**
     * 知识圈头像
     */
    private String avatar;
    /**
     * 知识圈标签
     */
    private Long tag;
    /**
     * 知识圈名称
     */
    private String name;
    private String introduce;
    private String aiKey;
}
