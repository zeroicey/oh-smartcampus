package com.org.oracle.mongodb.entity;

import cn.hutool.core.collection.CollUtil;
import com.org.oracle.sub.entity.DataSet;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.Collections;
import java.util.List;

/**
 * @Author: heiye
 * @CreateTime: 2024/09/09 下午5:37
 * @Description: 知识库类
 * @Version: 1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Document("knowledge_base")
public class KnowledgeBase {
    /**
     * 知识库id
     */
    private String id;

    /**
     * 知识库昵称
     */
    private String name;

    /**
     * 知识库简介
     */
    private String description;

    /**
     * 用户id
     */
    private String uid;

    /**
     * 对话数据集
     */
    @Field("data_set_list")
    private List<DataSet> dataSetList;

    /**
     * 校验必须传入的参数
     * @return
     */
    public Boolean check() {
        return CollUtil.isNotEmpty(dataSetList) &&
                StringUtils.isNotBlank(uid) &&
                StringUtils.isNotBlank(name);
    }
}
