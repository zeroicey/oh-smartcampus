package com.org.oracle.mysql.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/***
 * @title NoteCollectionResponseVO
 * @author SUZE
 * @Date 11:14
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class NoteCollectionResponseVO {
    private String noteId;
    private Long collectCount;
    //用户是否对该笔记点过赞
    private boolean isCollected;
}
