package com.org.oracle.mongodb.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @author: heiye
 * @date: 2024/12/06 下午11:10
 * @version: v1.0.0
 * @description: 用户信息
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserVO {
    /**
     * 用户唯一标识
     */
    private String uid;
    /**
     * 昵称
     */
    private String name;
    /**
     * 头像
     */
    private String avatar;
    /**
     * 性别
     */
    private Integer sex;
    /**
     * 个人简介
     */
    private String introduction;
    /**
     * 手机号
     */
    private String phone;
    /**
     * 邮箱地址
     */
    private String email;
    /**
     * 目标院校的昵称
     */
    private String collegeName;
    /**
     * 生日
     */
    private LocalDate birthday;
    /**
     * 地区
     */
    private String address;
    /**
     * 学习时长
     */
    private Long studyTime;
    /**
     * 签到天数
     */
    private Long attendance;
    /**
     * token
     */
    private String token;
}
