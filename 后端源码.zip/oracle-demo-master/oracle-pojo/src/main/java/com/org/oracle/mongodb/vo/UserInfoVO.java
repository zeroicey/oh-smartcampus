package com.org.oracle.mongodb.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author: heiye
 * @date: 2024/11/18 上午10:57
 * @version: v1.0.0
 * @description: 用户VO
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserInfoVO {
    /**
     * 头像
     */
    private String avatar;
    /**
     * 用户昵称
     */
    private String name;
    /**
     * 个人简介
     */
    private String introduction;
    /**
     * 发布笔记总数
     */
    private Long noteTotal;
    /**
     * 获得点赞总数
     */
    private Long likeTotal;
    /**
     * 获得点亮总数
     */
    private Long brightTotal;
    /**
     * 学习时长
     */
    private Long studyTime;
    /**
     * 签到数
     */
    private Long attendance;
}
