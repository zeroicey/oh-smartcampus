package com.org.oracle.mongodb.entity;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

/**
 * @author suze
 * @date 2024/8/19
 * @time 11:16
 **/

@Document(collection = "comments")
@Data
public class Comment {
    private String id;

    //内容元素真正的id  也是用这个与内容元素相绑定
    private String cmid;
    private String context;
    private String uid;
    //回复的id  回复A 那这就是A的id 若是回复文章这里写一个0
    private String replyId;
    private String uName;
    private String avatar;

    private String time;

    private List<Comment> subComment;

    public String getContext() { return context; }
    public void setContext(String value) { this.context = value; }

    public String getuid() { return uid; }
    public void setuid(String value) { this.uid = value; }

    public String getUName() { return uName; }
    public void setUName(String value) { this.uName = value; }


}