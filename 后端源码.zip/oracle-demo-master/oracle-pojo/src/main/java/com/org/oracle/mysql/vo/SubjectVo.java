package com.org.oracle.mysql.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SubjectVo {
    private Long id;

    //科目名称（如：数据结构）
    private String name;

}
