package com.org.oracle.mysql.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author: heiye
 * @date: 2024/12/14 下午8:30
 * @version: v1.0.0
 * @description: 收藏、取消收藏笔记
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CollectUnCollectNoteMqDTO {
    /**
     * 用户ID
     */
    private String uid;
    /**
     * 笔记ID
     */
    private String noteId;
    /**
     * 0: 取消收藏， 1：收藏
     */
    private Integer type;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    /**
     * 笔记发布者 ID
     */
    private String noteCreatorId;
}
