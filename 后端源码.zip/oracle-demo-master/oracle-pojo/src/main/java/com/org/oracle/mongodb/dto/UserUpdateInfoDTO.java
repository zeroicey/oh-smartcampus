package com.org.oracle.mongodb.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * @author: heiye
 * @date: 2024/10/09 下午9:22
 * @version: v1.0.0
 * @description: 用户修改信息dto
 */
@Data
public class UserUpdateInfoDTO implements Serializable {
    /**
     * 头像
     */
    private String avatar;
    /**
     * 名称
     */
    private String name;
    /**
     * 生日
     */
    private LocalDate birthday;
    /**
     * 性别
     */
    private Integer sex;
    /**
     * 个人简介
     */
    private String introduction;
}