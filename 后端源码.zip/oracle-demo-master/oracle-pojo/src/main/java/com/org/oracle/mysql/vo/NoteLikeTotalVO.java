package com.org.oracle.mysql.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: heiye
 * @date: 2024/12/18 下午5:06
 * @version: v1.0.0
 * @description: 笔记被喜欢的总数
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class NoteLikeTotalVO {
    /**
     * 笔记ID
     */
    private String noteId;
    /**
     * 笔记获得喜欢总数
     */
    private Long likeTotal;
}
