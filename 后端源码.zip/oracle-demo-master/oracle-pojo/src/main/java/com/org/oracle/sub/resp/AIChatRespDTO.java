package com.org.oracle.sub.resp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author: heiye
 * @date: 2024/11/15 上午12:02
 * @version: v1.0.0
 * @description: AI 对话数据接收DTO
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AIChatRespDTO {
    private String id;

    private String model;

    private AIChatUsageRespDTO usage;

    private List<AIChatChoicesRespDTO> choices;
}
