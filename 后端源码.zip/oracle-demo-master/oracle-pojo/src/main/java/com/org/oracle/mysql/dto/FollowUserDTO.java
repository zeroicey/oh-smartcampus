package com.org.oracle.mysql.dto;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: heiye
 * @date: 2024/12/20 上午9:41
 * @version: v1.0.0
 * @description: 关注用户DTO
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FollowUserDTO {
    /**
     * 关注 UID
     */
    @NotEmpty(message = "关注用户ID不能为空")
    private String followUserId;
}
