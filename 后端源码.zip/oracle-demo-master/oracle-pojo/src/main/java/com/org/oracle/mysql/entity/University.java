package com.org.oracle.mysql.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.springframework.data.mongodb.core.mapping.Field;

/**
 * @author suze
 * @date 2024/11/30
 * @time 15:44
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@TableName("university")
public class University {

    /**
     * id
     * 用于唯一标识每个记录
     */
    private Long id;


    /**
     * 学校名称
     * 用于存储学校的名称信息
     */
    @TableField("school_name")
    private String school_name;

    /**
     * 学校所在的地区，对应数据库中的region字段。
     */
    private String region;

    /**
     * 图片的URL地址，对应数据库中的img字段。
     * 设图片以URL的形式存储
     */
    private String img;


}
