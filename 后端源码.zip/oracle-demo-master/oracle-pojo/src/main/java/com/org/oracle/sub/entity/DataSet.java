package com.org.oracle.sub.entity;

import cn.hutool.core.collection.CollUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;
import java.util.Objects;

/**
 * @Author: heiye
 * @CreateTime: 2024/09/09 下午5:40
 * @Description: 对话数据集
 * @Version: 1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DataSet {
    /**
     * 对话数据id
     */
    private String id;

    /**
     * 用户id
     */
    private String uid;

    /**
     * 话题id
     */
    @Field("topic_id")
    private Long topicId;

    /**
     * 对话内容
     */
    private List<Message> messages;

    /**
     * 检验参数
     *
     * @return
     */
    public Boolean check() {
        return StringUtils.isNotEmpty(uid) &&
                Objects.nonNull(topicId) &&
                CollUtil.isNotEmpty(messages);
    }
}
