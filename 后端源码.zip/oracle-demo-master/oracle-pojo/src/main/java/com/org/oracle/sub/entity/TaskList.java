package com.org.oracle.sub.entity;

import com.org.oracle.mysql.entity.Task;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/19 下午10:24
 * 任务列表
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TaskList implements Serializable {
    /**
     * id
     */
    private String id;

    /**
     * 用户id
     */
    private String uid;

    /**
     * 知识圈id
     */
    private String circleId;

    /**
     * 该用户当天的任务表单
     */
    private List<Task> list;

    /**
     * 是否完成当天任务
     */
    private Boolean isFinish;
}


