package com.org.oracle.mongodb.dto;

import com.org.oracle.sub.dto.PageRequestDTO;
import lombok.Data;

/**
 * @Author: heiye
 * @CreateTime: 2024/08/31 下午2:42
 * @Description: 查找积分榜
 * @Version: 1.0
 */
@Data
public class PointsListDTO extends PageRequestDTO {
    /**
     * 知识圈id
     */
    private String circleId;

    /**
     * 想查找的榜单类型
     * 参数：
     *      周榜
     *      月榜
     *      总榜
     */
    private String type;

    /**
     * 地区榜(广州市)
     */
    private String address;
}
