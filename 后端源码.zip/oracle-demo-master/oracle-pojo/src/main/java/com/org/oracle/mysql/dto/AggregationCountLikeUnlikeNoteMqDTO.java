package com.org.oracle.mysql.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: heiye
 * @date: 2024/12/15 下午9:27
 * @version: v1.0.0
 * @description: 聚合后计数：点赞、取消点赞笔记
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AggregationCountLikeUnlikeNoteMqDTO {
    /**
     * 笔记发布者 ID
     */
    private String creatorId;
    /**
     * 笔记 ID
     */
    private String noteId;
    /**
     * 聚合后的计数
     */
    private Integer count;
}
