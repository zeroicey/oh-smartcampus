package com.org.oracle.mongodb.entity;

import com.org.oracle.sub.entity.Message;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;

/**
 * @author: heiye
 * @date: 2024/11/12 上午11:34
 * @version: v1.0.0
 * @description: AI聊天记录
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "AiHistory")
public class AiHistory {
    /**
     * 对话数据mid  MongoDB自动生成一个全局唯一id
     */
    private String _id;

    /**
     * 用户id
     */
    private String uid;

    /**
     * 话题id
     */
    @Field("topic_id")
    private String topicId;

    /**
     * 对话内容
     */
    private List<Message> messages;
}
