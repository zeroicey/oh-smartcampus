package com.org.oracle.mysql.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * @author: heiye
 * @date: 2024/12/12 下午4:35
 * @version: v1.0.0
 * @description: 取消点赞
 */
@Data
public class UnLikeNoteDTO {
    /**
     * 笔记 ID
     */
    @NotNull(message = "笔记 ID 不能为空")
    private String noteId;
}
