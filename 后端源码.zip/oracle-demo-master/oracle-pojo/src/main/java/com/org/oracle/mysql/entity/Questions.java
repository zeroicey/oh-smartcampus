package com.org.oracle.mysql.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.Date;
import java.util.List;

/**
 * (Questions)表实体类
 *
 * @author luo
 * @since 2024-11-13 17:21:55
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@TableName("questions")
public class Questions {
    //题目ID
    @TableId
    private Long id;
    //科目ID
    private String subjectId;
    //章节ID
    private String chapterId;
    //题目类型（如：选择题、填空题、简答题等）
    private String type;
    //题目内容
    private String content;
    //题目的答案
    private String answer;
    //题目的题解
    private String explanation;
    //选择题选项（使用JSON存储）
    private String options;
    //难度等级（1-5级）
    private Integer difficulty;
    //创建时间
    private Date createdAt;
    //更新时间
    private Date updatedAt;
    @TableField(exist = false)
    private List<String> optionsList;

}

