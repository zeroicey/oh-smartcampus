package com.org.oracle.mongodb.entity;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;

/**
 * @author suze
 * @date 2024/8/29
 * @time 19:57
 **/
@Document(collection = "chapters")
@Data
public class Chapter {
    @Field("circle_id")
    private String circleId;

    private String id;

    @Field("testing_points")
    private List<testingPoints> testingPoints;


    public class testingPoints {
        private String name;
        /**
         * 章节号
         */
        private String ordinal;
        /**
         * 摘要
         */
        private String summary;

        public String getName() { return name; }
        public void setName(String value) { this.name = value; }

        public String getOrdinal() { return ordinal; }
        public void setOrdinal(String value) { this.ordinal = value; }

        public String getSummary() { return summary; }
        public void setSummary(String value) { this.summary = value; }
    }
}
