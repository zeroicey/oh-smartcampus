package com.org.oracle.mysql.entity;

import cn.hutool.core.date.DateTime;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Date;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/21 下午5:08
 * 每日打卡表
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DayLog {
    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 用户id
     */
    private String uid;

    /**
     * 当日得分
     */
    private int gotPoints;

    /**
     * 日期
     */
    private LocalDateTime date;

    /**
     * 今日是否完成任务
     * 0：未完成 1：完成
     */

    private int isFinish;
}
