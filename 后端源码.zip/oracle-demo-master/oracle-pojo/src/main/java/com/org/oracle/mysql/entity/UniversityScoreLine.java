package com.org.oracle.mysql.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/***
 * @title UniversityScoreLine
 * @author SUZE
 * @Date 13:06
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@TableName("university_score_line")
public class UniversityScoreLine {
    /**
     * 地区。
     */
    private String region;

    /**
     * 二级专业。
     */
    private String secondaryMajor;

    /**
     * 三级专业。
     */
    private String tertiaryMajor;
    /**
     * 年份。
     */
    private String  year;
    /**
     * 录取人数
     */
    private String enrollment;

    /**
     * 学校。
     */
    private String school;

    /**
     * 学院。
     */
    private String faculty;

    /**
     * 最低分数线。
     */
    private String minScore;

    /**
     * 平均分数线。
     */
    private String averageScore;

    /**
     * 最高分数线。
     */
    private String maxScore;
}
