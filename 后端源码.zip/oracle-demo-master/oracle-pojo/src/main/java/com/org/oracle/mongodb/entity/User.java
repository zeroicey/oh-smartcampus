package com.org.oracle.mongodb.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @author suze
 * @date 2024/8/15
 * @time 14:22
 **/
@Data
@Builder
@Document("user")
@AllArgsConstructor
@NoArgsConstructor
public class User {
    /**
     * 用户唯一标识
     */
    private String uid;
    /**
     * 昵称
     */
    private String name;
    /**
     * 头像
     */
    private String avatar;
    /**
     * 性别
     */
    private Integer sex;
    /**
     * 个人简介
     */
    private String introduction;
    /**
     * 手机号
     */
    private String phone;
    /**
     * 邮箱地址
     */
    private String email;
    /**
     * 密码
     */
    private String password;
    /**
     * 目标院校的昵称
     */
    private String collegeName;
    /**
     * 生日
     */
    private LocalDate birthday;
    /**
     * 回调方传来的标识
     * 如：微信openid
     */
    private String openid;
    /**
     * 地区
     */
    private String address;
    /**
     * 账号状态
     */
    private Integer status;
    /**
     * 创建时间
     */
    @Field("create_time")
    private LocalDateTime createTime;
    /**
     * 修改时间
     */
    @Field("update_time")
    private LocalDateTime updateTime;
}

