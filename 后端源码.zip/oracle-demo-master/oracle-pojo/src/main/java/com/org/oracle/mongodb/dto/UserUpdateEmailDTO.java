package com.org.oracle.mongodb.dto;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

/**
 * @author: heiye
 * @date: 2024/12/07 上午11:07
 * @version: v1.0.0
 * @description:
 */
@Data
public class UserUpdateEmailDTO {
    /**
     * 邮箱
     */
    @NotEmpty
    private String email;
    /**
     * 验证码
     */
    @NotEmpty
    private String code;
}
