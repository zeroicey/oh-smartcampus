package com.org.oracle.mysql.entity;

import java.util.Date;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * (UserQuestionProgress)表实体类
 *
 * @author luo
 * @since 2024-12-18 20:37:44
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("user_question_progress")
public class UserQuestionProgress  {
    //用户题目进度ID
    @TableId
    private Long id;

    //用户ID
    private String uid;
    //题目ID
    private String questionId;
    //所属科目ID
    private String subjectId;
    //所属章节ID
    private String chapterId;
    //是否完成（0表示未完成，1表示已完成）
    private Integer isCompleted;
    //创建时间
    private Date createdAt;
    //更新时间
    private Date updatedAt;



}

