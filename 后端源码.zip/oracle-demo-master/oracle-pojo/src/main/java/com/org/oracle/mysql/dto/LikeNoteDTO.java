package com.org.oracle.mysql.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * @author: heiye
 * @date: 2024/12/11 下午6:20
 * @version: v1.0.0
 * @description: 点赞笔记
 */
@Data
public class LikeNoteDTO {
    /**
     * 笔记 ID
     */
    @NotNull(message = "笔记 ID 不能为空")
    private String noteId;
}
