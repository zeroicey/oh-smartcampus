package com.org.oracle.mongodb.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

/**
 * @author: heiye
 * @date: 2024/12/06 下午4:33
 * @version: v1.0.0
 * @description: 更改密码
 */
@Data
public class UpdatePasswordDTO {
    /**
     * 新密码
     */
    @NotBlank(message = "新密码不能为空")
    private String newPassword;
}
