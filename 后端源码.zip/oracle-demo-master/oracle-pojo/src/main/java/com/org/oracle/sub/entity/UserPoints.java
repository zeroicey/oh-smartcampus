package com.org.oracle.sub.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Field;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/27 下午9:51
 * 用户积分
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserPoints {
    /**
     * 用户id
     */
    private String uid;

    /**
     * 当前周积分
     */
    @Field("week_points")
    private int weekPoints;

    /**
     * 当前月积分
     */
    @Field("month_points")
    private int monthPoints;

    /**
     * 总积分
     */
    @Field("sum_points")
    private int sumPoints;

    /**
     * 地区
     */
    private String address;
}
