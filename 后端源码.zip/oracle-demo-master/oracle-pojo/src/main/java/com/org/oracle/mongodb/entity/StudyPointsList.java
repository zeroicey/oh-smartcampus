package com.org.oracle.mongodb.entity;

import com.org.oracle.sub.entity.UserPoints;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/27 下午9:41
 * 学习积分表
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Document("study_points_list")
public class StudyPointsList {
    /**
     * 主键
     */
    private String id;

    /**
     * 知识圈id
     */
    @Field("circle_id")
    private String circleId;

    /**
     * 用户积分列表
     */
    private List<UserPoints> list;
}
