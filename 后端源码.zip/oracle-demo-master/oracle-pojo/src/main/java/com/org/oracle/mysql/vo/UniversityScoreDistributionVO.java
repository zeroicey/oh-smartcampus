package com.org.oracle.mysql.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/***
 * @title UniversityScoreDistributionVO
 * @author SUZE
 * @Date 16:50
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UniversityScoreDistributionVO {
    /**
     * 分数段。
     */
    private String scoreRange;

    /**
     * 学生人数。
     */
    private String numberOfStudents;
}
