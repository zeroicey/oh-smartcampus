package com.org.oracle.mysql.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * @author: heiye
 * @date: 2024/12/15 上午11:54
 * @version: v1.0.0
 * @description: 取消收藏
 */
@Data
public class UnCollectNoteDTO {
    /**
     * 笔记 ID
     */
    @NotNull(message = "笔记 ID 不能为空")
    private String noteId;
}
