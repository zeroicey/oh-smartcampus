package com.org.oracle.mysql.vo;

import com.org.oracle.mongodb.entity.QuestionComment;
import jakarta.validation.constraints.AssertFalse;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class QuestionAddCommentVo {

    private Long id;
    //章节ID
    private String chapterId;
    //题目类型（如：选择题、填空题、简答题等）
    private String type;
    //题目内容
    private String content;
    //题目的答案
    private String answer;
    //题目的题解
    private String explanation;
    //难度等级（1-5级）
    private Integer difficulty;
    //创建时间
    private List<String> optionsList;
    //评论
    private List<QuestionComment> questionCommentList;
}
