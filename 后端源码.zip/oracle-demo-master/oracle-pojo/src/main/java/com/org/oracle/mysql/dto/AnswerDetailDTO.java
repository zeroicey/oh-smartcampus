package com.org.oracle.mysql.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AnswerDetailDTO {
    /**
     * 题目id
     */
    private Long questionId;
    /**
     * 用户答案
     */
    private String userAnswer;
    /**
     * 开始时间戳
     */
    private Long startTimestamp;
    /**
     * 结束时间戳
     */
    private Long endTimestamp;
}