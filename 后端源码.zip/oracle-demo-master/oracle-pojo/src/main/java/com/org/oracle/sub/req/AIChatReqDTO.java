package com.org.oracle.sub.req;

import com.org.oracle.sub.entity.Message;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author: heiye
 * @date: 2024/11/14 下午11:55
 * @version: v1.0.0
 * @description: AI对话 数据发送DTO
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AIChatReqDTO {

    private String chatId;

    private Boolean stream;

    private Boolean detail;

    private List<Message> messages;
}
