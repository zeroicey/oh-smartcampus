package com.org.oracle.mongodb.entity;

import lombok.Data;

/***
 * @title CircleContextDraft
 * @author SUZE
 * @Date 16:36
 **/
@Data
public class CircleContextDraft {


}
