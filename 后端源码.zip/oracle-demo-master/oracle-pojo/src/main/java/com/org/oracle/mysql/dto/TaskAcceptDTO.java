package com.org.oracle.mysql.dto;

import lombok.Data;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/19 下午9:47
 * 接受任务DTO
 */
@Data
public class TaskAcceptDTO {
    /**
     * 任务名
     */
    private String name;

    /**
     * 获得的积分
     */
    private int points;
}
