package com.org.oracle.sub.resp;

import com.org.oracle.sub.entity.Message;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: heiye
 * @date: 2024/11/15 上午12:20
 * @version: v1.0.0
 * @description: AI 对话中 choices 参数对象
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AIChatChoicesRespDTO {
    private Message message;

    private String finish_reason;

    private Integer index;
}
