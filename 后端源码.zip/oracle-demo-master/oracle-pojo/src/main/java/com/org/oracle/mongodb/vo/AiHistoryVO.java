package com.org.oracle.mongodb.vo;

import com.org.oracle.mysql.vo.HistoryTopicVO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/***
 * @title AiHistoryVO
 * @author SUZE
 * @Date 15:59
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AiHistoryVO {
    private String mid;

    private HistoryTopicVO topic;

    //这里可以是聊天记录的最后一句话 也可以是概要描述
    private String induction;

}
