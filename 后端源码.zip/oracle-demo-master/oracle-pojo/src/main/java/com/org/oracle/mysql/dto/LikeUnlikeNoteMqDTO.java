package com.org.oracle.mysql.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author: heiye
 * @date: 2024/12/12 下午9:37
 * @version: v1.0.0
 * @description: 点赞、取消点赞笔记
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LikeUnlikeNoteMqDTO {
    /**
     * 用户ID
     */
    private String uid;
    /**
     * 笔记ID
     */
    private String noteId;
    /**
     * 0: 取消点赞， 1：点赞
     */
    private Integer type;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    /**
     * 笔记发布者 ID
     */
    private String noteCreatorId;
}
