package com.org.oracle.mysql.entity;

import cn.hutool.core.date.DateTime;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/18 下午4:38
 * 话题Ai表
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Topic {
    /**
     * 主键id
      */
    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 话题AI名称
     */
    private String name;

    /**
     * 简介
     */
    private String introduce;

    /**
     * 头像
     */
    private String avatar;

    /**
     * 知识圈id
     */
    private String circleId;

    /**
     * AI标识
     */
    private String aiKey;

    /**
     * 章节
     */
    private String chapter;
    /**
     * 权重
     */
    private int weight;

    private String attractTitle;
    /**
     * 创建时间
     */
    private LocalDateTime createAt;

    /**
     * 更改时间
     */
    private LocalDateTime updatedAt;
}
