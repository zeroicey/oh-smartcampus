package com.org.oracle.mysql.entity;

import java.util.Date;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * (Subjects)表实体类
 *
 * @author luo
 * @since 2024-12-02 09:35:56
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("subjects")
public class Subjects  {
    //科目ID
    @TableId
    private Long id;

    //科目名称（如：数据结构）
    private String name;
    //科目的描述（可选）
    private String description;
    //创建时间
    private Date createdAt;
    //更新时间
    private Date updatedAt;



}

