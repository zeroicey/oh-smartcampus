package com.org.oracle.mongodb.entity;

import com.org.oracle.sub.entity.Message;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "deepseek_chat_records")
public class DeepSeekChatRecord {
    @Id
    private String id;
    
    @Indexed
    private String userId;  // 用户唯一标识
    
    @Field("messages")
    private List<Message> messages;  // 完整对话记录
    
    @Field("created_at")
    private LocalDateTime createdAt; // 创建时间戳
}