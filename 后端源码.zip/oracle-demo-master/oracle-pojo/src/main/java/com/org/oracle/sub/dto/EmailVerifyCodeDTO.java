package com.org.oracle.sub.dto;

import lombok.Data;

/**
 * @author: heiye
 * @date: 2024/12/03 下午7:36
 * @version: v1.0.0
 * @description: 发送邮件验证码
 */
@Data
public class EmailVerifyCodeDTO {
    /**
     * 邮箱
     */
    private String email;
}
