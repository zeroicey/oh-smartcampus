package com.org.oracle.mysql.entity;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * (UserAnswerDetails)表实体类
 *
 * @author luo
 * @since 2024-12-16 20:35:13
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("user_answer_details")
public class UserAnswerDetail {
    //用户答题详情ID
    @TableId
    private Long id;

    //对应的答题记录ID
    private Long userCommitResultId;
    //用户ID
    private String uid;
    //题目ID
    private Long questionId;
    //用户的答案（选择题：选择项，简答题：文字答案）
    private String userAnswer;
    //是否答对（true/false）
    private Integer isCorrect;
    //该题得分（可以根据难度评分）
    private Float score;
    //开始做该题的时间戳（毫秒）
    private Long startTimestamp;
    //做完该题的时间戳（毫秒）
    private Long endTimestamp;
    //创建时间
    private Date createdAt;
    //更新时间
    private Date updatedAt;
    /**
     * 是否缓存，1 代表缓存，0 代表正式提交
     */
    private Integer isTemporary;
    /**
     * 暂存类型（0已提交，1当天暂存，2累计暂存）
     */
    private Integer temporaryType;
    //暂存开始时间戳（毫秒）
    private Long temporaryStartTimestamp;
}

