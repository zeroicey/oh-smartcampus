package com.org.oracle.mongodb.entity;

import lombok.Data;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document(collection = "question_comments")
@Data
public class QuestionComment {
    @Id
    private ObjectId id;
    //题目Id
    private String questionId;
    /**
     *默认为-1（根评论）
     */
    private String rootCommentId;
    //评论内容
    private String content;
    //所回复的对象id
    private String replyToUid;
    //所回复的评论id
    private String replyToCommentId;
    //该评论的发起者（uid）
    private String createBy;
    //点赞数（暂定，以后可以拓展）
    private int likes;
    // 子评论
    @Transient
    private List<QuestionComment> replies;
    //将id转化为字符串
    public String getCommentId() {
        return id != null ? id.toString() : null;
    }
}
