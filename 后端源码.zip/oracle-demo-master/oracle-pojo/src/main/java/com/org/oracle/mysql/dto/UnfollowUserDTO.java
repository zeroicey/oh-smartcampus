package com.org.oracle.mysql.dto;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: heiye
 * @date: 2024/12/20 下午3:18
 * @version: v1.0.0
 * @description: 取消关注
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UnfollowUserDTO {
    /**
     * 关注 UID
     */
    @NotEmpty(message = "取关用户 ID 不能为空")
    private String unfollowUserId;
}
