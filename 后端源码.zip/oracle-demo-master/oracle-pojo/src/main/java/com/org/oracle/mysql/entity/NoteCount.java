package com.org.oracle.mysql.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: heiye
 * @date: 2024/12/11 下午3:02
 * @version: v1.0.0
 * @description: 笔记计数
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class NoteCount {
    /**
     * ID
     */
    @TableId(type = IdType.AUTO)
    private Long id;
    /**
     * 笔记ID
     */
    private String noteId;
    /**
     * 点赞总数
     */
    private Long likeTotal;
    /**
     * 收藏总数
     */
    private Long collectTotal;
    /**
     * 评论总数
     */
    private Long commentTotal;
}
