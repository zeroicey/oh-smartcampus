package com.org.oracle.mysql.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserAnswerSubmitDTO {
//    /**
//     * 用户id
//     */
//    private String uid;
//    /**
//     * 科目id
//     */
//    private String subjectId;
    /**
     * 章节id
     */
    private String chapterId;
    /**
     * 存储每道题目的作答情况，题目ID对应用户答案，以及开始、结束时间戳
     */
    private List<AnswerDetailDTO> answerDetails;
}