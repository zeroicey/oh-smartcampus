package com.org.oracle.mysql.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/***
 * @title UniversityScoreDistribution
 * @author SUZE
 * @Date 13:08
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@TableName("university_score_distribution")
public class UniversityScoreDistribution {
    /**
     * 地区。
     */
    private String region;

    /**
     * 二级专业。
     */
    private String secondaryMajor;

    /**
     * 三级专业。
     */
    private String tertiaryMajor;

    /**
     * 大学等级。
     */
    private String universityLevel;

    /**
     * 年份。
     */
    private String year;

    /**
     * 学校。
     */
    private String school;

    /**
     * 学院。
     */
    private String faculty;

    /**
     * 专业。
     */
    private String major;

    /**
     * 分数段。
     */
    private String scoreRange;

    /**
     * 学生人数。
     */
    private String numberOfStudents;

}
