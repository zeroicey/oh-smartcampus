package com.org.oracle.mysql.dto;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/19 下午5:14
 * 任务初始化
 */
@Data
public class TaskInitDTO {
    /**
     * 任务名
     */
    private String name;

    /**
     * 归属知识圈
     */
    private String circleId;

    /**
     * 归属章节
     */
    private String chapter;

    /**
     * 任务内容
     */
    private String content;

    public boolean checkParam() {
        return StringUtils.isNotBlank(this.chapter)
                && StringUtils.isNotBlank(this.circleId)
                && StringUtils.isNotBlank(this.name)
                && StringUtils.isNotBlank(this.content);
    }
}
