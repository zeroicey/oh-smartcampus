package com.org.oracle.mongodb.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * @author: heiye
 * @date: 2024/12/06 下午5:25
 * @version: v1.0.0
 * @description: 忘记密码
 */
@Data
public class ForgetPasswordDTO {
    /**
     * 邮箱
     */
    @NotBlank
    private String email;
    /**
     * 新密码
     */
    @NotBlank(message = "新密码不能为空")
    private String newPassword;
}
