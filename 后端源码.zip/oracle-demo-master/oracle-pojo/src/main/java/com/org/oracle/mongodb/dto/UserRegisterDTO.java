package com.org.oracle.mongodb.dto;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

/**
 * @author: heiye
 * @date: 2024/12/03 上午9:09
 * @version: v1.0.0
 * @description: 用户注册
 */
@Data
public class UserRegisterDTO {
    /**
     * 名称
     */
    @NotEmpty
    private String name;
    /**
     * 密码
     */
    @NotEmpty
    private String password;
    /**
     * 邮箱
     */
    @NotEmpty
    private String email;
    /**
     * 验证码
     */
    @NotEmpty
    private String code;
}
