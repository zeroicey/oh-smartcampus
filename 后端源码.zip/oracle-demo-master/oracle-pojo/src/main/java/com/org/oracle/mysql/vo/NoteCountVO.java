package com.org.oracle.mysql.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: heiye
 * @date: 2024/12/18 下午7:17
 * @version: v1.0.0
 * @description: 笔记计数
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class NoteCountVO {
    /**
     * 笔记ID
     */
    private String noteId;
    /**
     * 点赞总数
     */
    private Long likeTotal;
    /**
     * 收藏总数
     */
    private Long collectTotal;
    /**
     * 评论总数
     */
    private Long commentTotal;
}
