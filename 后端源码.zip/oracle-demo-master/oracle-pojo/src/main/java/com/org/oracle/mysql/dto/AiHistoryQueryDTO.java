package com.org.oracle.mysql.dto;

import com.org.oracle.sub.dto.PageRequestDTO;
import lombok.Data;

/***
 * @title AiHistoryQueryDTO
 * @author SUZE
 * @Date 16:13
 **/
@Data
public class AiHistoryQueryDTO extends PageRequestDTO {
    private String uid;
    private String TopicId;
}
