package com.org.oracle.mongodb.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: heiye
 * @date: 2024/11/29 上午10:30
 * @version: v1.0.0
 * @description: 用户简要信息
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserSimpleVO {
    /**
     * 用户唯一标识
     */
    private String uid;
    /**
     * 用户昵称
     */
    private String name;
    /**
     * 用户头像
     */
    private String avatar;
    /**
     * 个人简介
     */
    private String introduction;
}
