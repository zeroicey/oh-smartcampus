package com.org.oracle.mysql.entity;

import java.util.Date;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.experimental.Accessors;
import org.springframework.data.mongodb.core.mapping.Field;

/**
 * (QuestionChapters)表实体类
 *
 * @author luo
 * @since 2024-11-13 20:15:36
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@TableName("question_chapters")
public class QuestionChapters  {
    //章节ID
    @TableId
    private Long id;
    //科目ID
    private String subjectId;
    //章节名称（如：线性表等）
    private String name;
    //排序顺序，值越小越靠前
    private Integer sortOrder;
    //章节描述
    private String description;
    //章节的题目数
    @TableField(exist = false)
    private Integer questionNum;
    //创建时间
    private Date createdAt;
    //更新时间
    private Date updatedAt;


}

