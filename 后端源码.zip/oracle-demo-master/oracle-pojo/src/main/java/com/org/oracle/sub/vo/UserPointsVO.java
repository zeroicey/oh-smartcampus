package com.org.oracle.sub.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author: heiye
 * @CreateTime: 2024/08/31 下午4:10
 * @Description: 用户积分VO
 * @Version: 1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserPointsVO {
    /**
     * 用户id
     */
    private String uid;

    /**
     * 用户名称
     */
    private String name;

    /**
     * 用户头像
     */
    private String avatar;

    /**
     * 用户积分
     */
    private int points;
}
