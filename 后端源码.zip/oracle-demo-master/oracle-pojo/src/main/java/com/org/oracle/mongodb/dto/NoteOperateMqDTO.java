package com.org.oracle.mongodb.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: heiye
 * @date: 2024/12/16 上午11:41
 * @version: v1.0.0
 * @description: 笔记操作
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class NoteOperateMqDTO {
    /**
     * 笔记发布者 ID
     */
    private String creatorId;

    /**
     * 笔记 ID
     */
    private String noteId;

    /**
     * 操作类型： 0 - 笔记删除； 1：笔记发布；
     */
    private Integer type;
}
