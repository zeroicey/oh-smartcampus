package com.org.oracle.mongodb.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: heiye
 * @date: 2024/11/18 上午11:21
 * @version: v1.0.0
 * @description: 知识圈VO
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CircleVO {
    /**
     * 知识圈id  主键
     */
    private String circleId;
    /**
     * 知识圈头像
     */
    private String avatar;
    /**
     * 知识圈名称
     */
    private String name;
    /**
     * 知识圈简介,前端暂时用不上
     */
//    private String introduce;
}
