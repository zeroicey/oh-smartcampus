package com.org.oracle.mysql.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/***
 * @title FindRangeSearchVO
 * @author SUZE
 * @Date 13:05
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FindRangeSearchVO {


    /**
     * 三级专业。前端视角的专业
     */
    private String tertiaryMajor;
    /**
     * 年份。
     */
    private int year;

    /**
     * 学校。
     */
    private String school;

    private String img;

    /**
     * 学院。
     */
    private String faculty;

    /**
     * 最低分数线。
     */
    private String minScore;

    /**
     * 平均分数线。
     */
    private String averageScore;

    /**
     * 最高分数线。
     */
    private String maxScore;

    /**
     * 对应专业的分数分布数组
     */
    private List<UniversityScoreDistributionVO> universityScoreDistributionVOS;

}
