package com.org.oracle.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * @author: heiye
 * @date: 2024/12/03 下午4:26
 * @version: v1.0.0
 * @description: 登录类型枚举
 */
@Getter
@AllArgsConstructor
public enum LoginTypeEnum {
    // 密码
    PASSWORD(1),
    // 验证码
    VERIFICATION_CODE(2);

    private final Integer value;

    public static LoginTypeEnum valueOf(Integer code) {
        for (LoginTypeEnum loginTypeEnum : LoginTypeEnum.values()) {
            if (Objects.equals(code, loginTypeEnum.getValue())) {
                return loginTypeEnum;
            }
        }
        return null;
    }
}
