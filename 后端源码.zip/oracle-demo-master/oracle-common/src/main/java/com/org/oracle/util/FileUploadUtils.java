package com.org.oracle.util;

import org.springframework.web.multipart.MultipartFile;

public class FileUploadUtils {

    // 校验文件扩展名是否为支持的类型
    public static boolean isValidCSVFileType(MultipartFile file) {
        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null) {
            return false;
        }
        String fileExtension = originalFilename.substring(originalFilename.lastIndexOf(".") + 1).toLowerCase();
        return "csv".equals(fileExtension);
    }

    public static boolean isValidExcelFileType(MultipartFile file) {
        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null) {
            return false;
        }
        String fileExtension = originalFilename.substring(originalFilename.lastIndexOf(".") + 1).toLowerCase();
        return "xlsx".equals(fileExtension);
    }
}
