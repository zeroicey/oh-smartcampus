package com.org.oracle.result;

import com.org.oracle.exception.CustomException;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author suze
 * @date 2023-10-25
 * @time 15:19
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Result {
    private Boolean success;
    private Integer errorCode;
    /**
     * 错误码
     */
    private String errorMsg;
    private Object data;

    public static Result ok() {
        return new Result(true, null, null, null);
    }

    public static Result ok(Object data) {
        return new Result(true, null, null, data);
    }

    public static Result ok(List<?> data, Integer code) {
        return new Result(true, code, null, data);
    }

    public static Result fail(String errorMsg) {
        return new Result(false, null, errorMsg, null);
    }

    public static Result fail(String errorMsg, Integer errorCode) {
        return new Result(false, errorCode, errorMsg, null);
    }
//    public static Result fail(int  errorCode, String errorMsg){
//        return new Result(false, errorMsg, null, null);
//    }
}
