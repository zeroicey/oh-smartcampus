package com.org.oracle.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/20 下午14:05
 * 异常抛出枚举
 */
@Getter
@AllArgsConstructor
public enum ResponseCodeEnum {
    // 成功段0
    SUCCESS(200, "操作成功"),
    // 登录段1~50
    NEED_LOGIN(1, "需要登录后操作"),
    LOGIN_PASSWORD_ERROR(2, "密码错误"),
    LOGIN_FAIL(3, "登录失败"),
    LOGIN_TYPE_ERROR(4, "登录类型错误"),
    // TOKEN50~100
    TOKEN_INVALID(50, "无效的token"),
    TOKEN_EXPIRE(51, "token已过期"),
    TOKEN_REQUIRE(52, "token是必须的"),
    // 参数错误 500~1000
    SERVER_ERROR(500, "服务器繁忙"),
    PARAM_REQUIRE(501, "缺少参数"),
    PARAM_INVALID(502, "无效参数"),
    PARAM_IMAGE_FORMAT_ERROR(503, "图片格式有误"),
    // 数据错误 1000~2000
    DATA_EXIST(1000, "数据已经存在"),
    DATA_NOT_EXIST(1001, "数据不存在"),
    DATA_SAVE_ERROR(1002, "数据保存失败"),
    EMAIL_VERIFICATION_CODE_SEND_FREQUENTLY(1003, "请求太频繁，请5分钟后再试"),
    FILE_SIZE_EMPTY(1004, "文件大小不能为空"),
    IMAGE_UPLOAD_FAIL(1005, "图片上传失败"),
    IMAGE_TYPE_ERROR(1006, "突破类型错误"),
    // 权限错误 3000~3500
    NO_OPERATOR_AUTH(3000, "权限不足"),
    NEED_ADMIND(3001, "需要管理员权限"),
    // 用户服务错误 4000~5000
    USER_NOT_FOUND(4000, "用户不存在"),
    USER_ADDRESS_NOT_AUTHORIZATION(4001, "用户没有授权地址信息"),
    DISPLAY_NAME_VALID_FAIL(4002, "昵称请设置2-24个字符，不能使用@《/等特殊字符"),
    SEX_VALID_FAIL(4003, "性别错误"),
    SYNOPSIS_VALID_FAIL(4005, "个人简介请设置1-100个字符"),
    UPLOAD_AVATAR_FAIL(4006, "头像上传失败"),
    PASSWORD_VALID_FAIL(4007, "密码请设置8-15个字符，且应包含大小写字母和数字"),
    NAME_OR_PASSWORD_ERROR(4008, "用户名或者密码不正确"),
    EMAIL_VERIFICATION_CODE_FAIL(4009, "验证码无效"),
    USER_ALREADY_EXISTS(4010, "用户已存在"),
    EMAIL_HAS_ALREADY_SET(4012, "该邮箱已被其他用户绑定"),
    //刷题服务错误 5000~6000
    QUESTION_UPLOAD_ERROR_CSV(5001,"文件类型错误，必须为CSV格式"),
    QUESTION_UPLOAD_ERROR_EXCEL(5002,"文件类型错误，必须为EXCEL格式"),
    QUESTION_UPLOAD_FILENAME_NOTNULL(5003,"文件名不能为空"),
    // 笔记服务错误 6000~7000
    NOTE_NOT_FIND(6000, "笔记不存在"),
    NOTE_ALREADY_LIKED(6001, "您已经点赞过该笔记"),
    NOTE_NOT_LIKED(6002, "您未点赞该篇笔记，无法取消点赞"),
    NOTE_ALREADY_COLLECTED(6003, "您已经收藏过该笔记"),
    NOTE_NOT_COLLECTED(6004, "您未收藏该篇笔记，无法取消收藏"),
    // 用户关系服务 7000~8000
    CANT_FOLLOW_YOUR_SELF(7000, "无法关注自己"),
    FOLLOW_USER_NOT_EXISTED(7001, "关注的用户不存在"),
    FOLLOWING_COUNT_LIMIT(7002, "您关注的用户已达上限，请先取关部分用户"),
    ALREADY_FOLLOWED(7003, "您已经关注了该用户"),
    CANT_UNFOLLOW_YOUR_SELF(7004, "无法取关自己"),
    NOT_FOLLOWED(7005, "你未关注对方，无法取关"),
    ;

    final Integer code;
    final String errorMessage;
}
