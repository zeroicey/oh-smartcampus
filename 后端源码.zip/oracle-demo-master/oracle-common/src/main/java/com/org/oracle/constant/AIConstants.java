package com.org.oracle.constant;

/**
 * @author: heiye
 * @date: 2024/11/12 上午11:37
 * @version: v1.0.0
 * @description: AI 笔记常量类
 */
public class AIConstants {
    /**
     * AI 笔记
     */
    public static final Integer AI_NOTE = 1;

    /**
     * AI 聊天记录
     */
    public static final Integer CHAR_HISTORY = 2;
}
