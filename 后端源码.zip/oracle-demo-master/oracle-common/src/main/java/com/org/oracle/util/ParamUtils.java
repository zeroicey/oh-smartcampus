package com.org.oracle.util;

import java.util.regex.Pattern;

/**
 * @author: heiye
 * @date: 2024/11/27 上午10:59
 * @version: v1.0.0
 * @description: 参数条件工具
 */
public class ParamUtils {
    private ParamUtils() {

    }

    // ============================== 校验昵称 ==============================
    // 定义昵称长度范围
    private static final int DISPLAY_NAME_MIN_LENGTH = 2;
    private static final int DISPLAY_NAME_MAX_LENGTH = 24;

    // 定义特殊字符的正则表达式
    private static final String DISPLAY_NAME_REGEX = "[!@#$%^&*(),.?\\\":{}|<>]";

    // ============================== 校验密码 ==============================
    // 定义密码格式的正则表达式
    private static final String PASSWORD_REGEX = "^\\S*(?=\\S{6,})(?=\\S*\\d)(?=\\S*[A-Z])(?=\\S*[a-z])(?=\\S*[!@#$%^&*? ])\\S*$";

    /**
     * 昵称校验
     *
     * @param displayName
     * @return
     */
    public static boolean checkDisplayName(String displayName) {
        // 检查长度
        if (displayName.length() < DISPLAY_NAME_MIN_LENGTH || displayName.length() > DISPLAY_NAME_MAX_LENGTH) {
            return false;
        }

        // 检查是否含有特殊字符
        Pattern pattern = Pattern.compile(DISPLAY_NAME_REGEX);
        return !pattern.matcher(displayName).find();
    }

    /**
     * 字符串长度校验
     *
     * @param str
     * @param length
     * @return
     */
    public static boolean checkLength(String str, int length) {
        // 检查长度
        return !str.isEmpty() && str.length() <= length;
    }

    /**
     * 昵称密码
     *
     * @param password
     * @return
     */
    public static boolean checkPassword(String password) {
        // 检查是否符合规范
        Pattern pattern = Pattern.compile(PASSWORD_REGEX);
        return pattern.matcher(password).matches();
    }
}
