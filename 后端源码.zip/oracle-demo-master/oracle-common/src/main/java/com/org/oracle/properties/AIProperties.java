package com.org.oracle.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author: heiye
 * @date: 2024/11/15 上午12:43
 * @version: v1.0.0
 * @description: AI 变量配置
 */
@Data
@Component
@ConfigurationProperties(prefix = "ai")
public class AIProperties {
    /**
     * 主路径
     */
    private String url;
    /**
     * 笔记接口路径
     */
    private String note;
}
