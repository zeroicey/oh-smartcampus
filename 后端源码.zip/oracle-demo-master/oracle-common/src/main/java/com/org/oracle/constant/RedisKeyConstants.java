package com.org.oracle.constant;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/20 下午8:00
 * key前缀常量
 */
public class RedisKeyConstants {
    /**
     * 任务列表
     */
    public static final String TASK_LIST = "task_list:";

    /**
     * 用户uid自增字段 key 前缀
     */
    public static final String USER_ID_GENERATOR = "user.id.generator";

    /**
     * 用户打卡按钮 key 前缀
     */
    public static final String LOG_BUTTON = "log.button:";

    /**
     * AI笔记自增字段 key 前缀
     */
    public static final String AI_NOTE_ID_GENERATOR = "ai.note.id.generator";

    /**
     * 用户信息数据 KEY 前缀
     */
    private static final String USER_INFO_KEY_PREFIX = "user:info:";

    /**
     * 邮箱验证码 KEY 前缀
     */
    private static final String EMAIL_VERIFICATION_CODE_KEY_PREFIX = "email:verification_code:";

    /**
     * 布隆过滤器：用户笔记点赞
     */
    public static final String BLOOM_USER_NOTE_LIKE_LIST_KEY = "bloom:note:likes:";

    /**
     * 用户笔记点赞列表 ZSet 前缀
     */
    public static final String USER_NOTE_LIKE_ZSET_KEY = "user:note:likes:";

    /**
     * 笔记维度计数 Key 前缀
     */
    private static final String COUNT_NOTE_KEY_PREFIX = "count:note:";

    /**
     * 关注列表 KEY 前缀
     */
    private static final String USER_FOLLOWING_KEY_PREFIX = "following:";

    /**
     * Hash Field: 笔记点赞总数
     */
    public static final String FIELD_LIKE_TOTAL = "likeTotal";

    /**
     * Hash Field: 笔记收藏总数
     */
    public static final String FIELD_COLLECT_TOTAL = "collectTotal";

    /**
     * Hash Field: 笔记发布总数
     */
    public static final String FIELD_NOTE_TOTAL = "noteTotal";

    /**
     * Hash Field: 获得点亮总数
     */
    public static final String FIELD_BRIGHT_TOTAL = "brightTotal";

    /**
     * Hash Field: 笔记评论总数
     */
    public static final String FIELD_COMMENT_TOTAL = "commentTotal";

    /**
     * 用户笔记收藏列表 ZSet 前缀
     */
    public static final String USER_NOTE_COLLECT_ZSET_KEY = "user:note:collects:";

    /**
     * 用户维度计数 Key 前缀
     */
    private static final String COUNT_USER_KEY_PREFIX = "count:user:";

    /**
     * 构建邮箱验证码 KEY
     *
     * @param email
     * @return
     */
    public static String buildEmailVerificationCodeKey(String email) {
        return EMAIL_VERIFICATION_CODE_KEY_PREFIX + email;
    }

    /**
     * 布隆过滤器：用户笔记收藏 前缀
     */
    public static final String BLOOM_USER_NOTE_COLLECT_LIST_KEY = "bloom:note:collects:";

    /**
     * 构建角色对应的权限集合 KEY
     *
     * @param uid
     * @return
     */
    public static String buildUserInfoKey(String uid) {
        return USER_INFO_KEY_PREFIX + uid;
    }

    /**
     * 构建完整的布隆过滤器：用户笔记点赞 KEY
     *
     * @param uid
     * @return
     */
    public static String buildBloomUserNoteLikeListKey(String uid) {
        return BLOOM_USER_NOTE_LIKE_LIST_KEY + uid;
    }

    /**
     * 构建完整的用户笔记点赞列表 ZSet KEY
     *
     * @param uid
     * @return
     */
    public static String buildUserNoteLikeZSetKey(String uid) {
        return USER_NOTE_LIKE_ZSET_KEY + uid;
    }

    /**
     * 构建笔记维度计数 Key
     *
     * @param noteId
     * @return
     */
    public static String buildCountNoteKey(String noteId) {
        return COUNT_NOTE_KEY_PREFIX + noteId;
    }

    /**
     * 构建完整的布隆过滤器：用户笔记收藏 KEY
     *
     * @param uid
     * @return
     */
    public static String buildBloomUserNoteCollectListKey(String uid) {
        return BLOOM_USER_NOTE_COLLECT_LIST_KEY + uid;
    }

    /**
     * 构建完整的用户笔记收藏列表 ZSet KEY
     *
     * @param uid
     * @return
     */
    public static String buildUserNoteCollectZSetKey(String uid) {
        return USER_NOTE_COLLECT_ZSET_KEY + uid;
    }

    /**
     * 构建用户维度计数 Key
     *
     * @param uid
     * @return
     */
    public static String buildCountUserKey(String uid) {
        return COUNT_USER_KEY_PREFIX + uid;
    }

    /**
     * 构建关注列表完整的 KEY
     * @param uid
     * @return
     */
    public static String buildUserFollowingKey(String uid) {
        return USER_FOLLOWING_KEY_PREFIX + uid;
    }
}
