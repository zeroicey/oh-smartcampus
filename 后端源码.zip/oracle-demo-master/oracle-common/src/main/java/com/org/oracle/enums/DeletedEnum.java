package com.org.oracle.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/11/14 下午15:20
 * 逻辑删除枚举
 */
@Getter
@AllArgsConstructor
public enum DeletedEnum {

    YES(true),
    NO(false);

    private final Boolean value;
}
