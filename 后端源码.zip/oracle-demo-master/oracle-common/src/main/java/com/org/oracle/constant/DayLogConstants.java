package com.org.oracle.constant;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/21 下午8:06
 * 打卡记录常量
 */
public class DayLogConstants {
    /**
     * 完成当日全部任务
     */
    public static final Integer OVER = 1;

    /**
     * 未完成当日全部任务
     */
    public static final Integer NOT_OVER = 0;
}
