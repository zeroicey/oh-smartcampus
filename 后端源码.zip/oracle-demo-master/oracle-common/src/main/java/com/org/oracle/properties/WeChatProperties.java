package com.org.oracle.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author: heiye
 * @date: 2024/10/09 下午9:22
 * @version: v1.0.0
 * @description: 微信变量配置
 */
@Data
@Component
@ConfigurationProperties(prefix = "wechat")
public class WeChatProperties {

    /**
     * 小程序的appid
     */
    private String appid;

    /**
     * 小程序的秘钥
     */
    private String secret;
}