package com.org.oracle.util;

import java.time.Instant;
import java.util.UUID;

/**
 * @author suze
 * @date 2024/8/19
 * @time 12:21
 **/
public class UniqueIdGenerator {
    /**
     * 生成一个基于当前时间戳和随机字符串的全局唯一ID。
     *
     * @return 全局唯一ID字符串
     */
    public static String generateUniqueId() {
        // 获取当前时间的时间戳
        long timestamp = Instant.now().toEpochMilli();
        // 生成一个随机的UUID
        String randomUUID = UUID.randomUUID().toString().replace("-", "");
        // 将时间戳和随机UUID拼接，形成唯一ID
        return timestamp + randomUUID;
    }
}
