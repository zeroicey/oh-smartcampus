package com.org.oracle.constant;

/**
 * @Author: heiye
 * @CreateTime: 2024/08/31 下午3:26
 * @Description: 任务列表状态常量类
 * @Version: 1.0
 */
public class TaskListConstants {

    /**
     * 完成当日全部任务
     */
    public static final Boolean TASK_ALL_FINISH = true;

    /**
     * 未完成当日全部任务
     */
    public static final Boolean TASK_FAIL = false;


    // 首页打卡按钮常量
    /**
     * 不可以按
     */
    public static final Integer NOT_PRESS_LOG_BUTTON = 1;
    /**
     * 可以按按钮
     */
    public static final Integer CAN_PRESS_LOG_BUTTON = 2;
    /**
     * 已经按了
     */
    public static final Integer ALREADY_PRESSED_LOG_BUTTON = 3;
}
