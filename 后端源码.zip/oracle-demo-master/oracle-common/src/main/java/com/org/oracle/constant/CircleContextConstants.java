package com.org.oracle.constant;

/**
 * @author: heiye
 * @date: 2024/11/14 上午11:49
 * @version: v1.0.0
 * @description: 知识圈内容常量类
 */
public class CircleContextConstants {
    /**
     * 知识圈内容 MongoDB 集合前缀
     */


}
