package com.org.oracle.exception;

import com.org.oracle.enums.ResponseCodeEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/20 下午13:50
 * 业务异常
 */
@Getter
@AllArgsConstructor
public class CustomException extends RuntimeException {
    private ResponseCodeEnum responseCodeEnum;
}
