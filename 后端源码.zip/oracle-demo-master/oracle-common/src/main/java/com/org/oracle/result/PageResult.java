package com.org.oracle.result;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author: heiye
 * @date: 2024/12/15 下午10:22
 * @version: v1.0.0
 * @description: 鸿蒙APP PageResult
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PageResult<T> {
    /**
     * 页面总条数
     */
    private long total;
    /**
     * 页面
     */
    private long page;
    /**
     * 条数
     */
    private long pageSize;
    /**
     * 内容
     */
    private List<T> rows;

    /**
     * 获取总页数
     *
     * @param total
     * @param pageSize
     * @return
     */
    public static long getTotalPage(long total, long pageSize) {
        return pageSize == 0 ? 0 : (total + pageSize - 1) / pageSize;
    }

    /**
     * 计算分页查询的 offset
     * @param page
     * @param pageSize
     * @return
     */
    public static long getOffset(long page, long pageSize) {
        // 如果页码小于 1，默认返回第一页的 offset
        if (page < 1) {
            page = 1;
        }
        return (page - 1) * pageSize;
    }
}
