package com.org.oracle.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author: heiye
 * @date: 2024/12/03 下午7:38
 * @version: v1.0.0
 * @description: 邮件配置类
 */
@Data
@Component
@ConfigurationProperties(prefix = "spring.mail")
public class EmailProperties {
    /**
     * 发送邮件的邮箱账号
     */
    private String username;
}
