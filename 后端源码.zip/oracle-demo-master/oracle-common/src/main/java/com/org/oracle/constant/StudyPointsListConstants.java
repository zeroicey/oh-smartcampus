package com.org.oracle.constant;

import com.org.oracle.enums.ResponseCodeEnum;
import com.org.oracle.exception.CustomException;
import com.org.oracle.sub.entity.UserPoints;

/**
 * @Author: heiye
 * @CreateTime: 2024/08/31 下午3:38
 * @Description: 学习积分榜常量类
 * @Version: 1.0
 */
public class StudyPointsListConstants {
    /**
     * 周榜
     */
    public static final String WEEK_LIST = "周榜";

    /**
     * 月榜
     */
    public static final String MONTH_LIST = "月榜";

    /**
     * 总榜
     */
    public static final String SUM_LIST = "总榜";

    /**
     * 要获取哪个榜单数据字段
     *
     * @param type
     * @return
     *         list.week_points ||
     *         list.month_points ||
     *         list.sum_points
     */
    public static String getField(String type) {
        String field;
        // 判断该返回那个榜单
        switch (type) {
            // 周榜
            case StudyPointsListConstants.WEEK_LIST -> field = "list.week_points";
            // 月榜
            case StudyPointsListConstants.MONTH_LIST -> field = "list.month_points";
            // 总榜
            case StudyPointsListConstants.SUM_LIST -> field = "list.sum_points";
            // 都不是 抛出无效参数异常
            default -> throw new CustomException(ResponseCodeEnum.PARAM_INVALID);
        }
        return field;
    }

    /**
     * 要获取哪个榜单数据字段里的数据
     *
     * @param type
     * @return
     *         list.week_points ||
     *         list.month_points ||
     *         list.sum_points 的积分
     */
    public static int getFieldPoints(String type, UserPoints userPoints) {
        // 判断该返回那个榜单
        switch (type) {
            // 周榜
            case StudyPointsListConstants.WEEK_LIST -> {
                return userPoints.getWeekPoints();
            }
            // 月榜
            case StudyPointsListConstants.MONTH_LIST -> {
                return userPoints.getMonthPoints();
            }
            // 总榜
            case StudyPointsListConstants.SUM_LIST -> {
                return userPoints.getSumPoints();
            }
            // 都不是 抛出无效参数异常
            default -> throw new CustomException(ResponseCodeEnum.PARAM_INVALID);
        }
    }
}
