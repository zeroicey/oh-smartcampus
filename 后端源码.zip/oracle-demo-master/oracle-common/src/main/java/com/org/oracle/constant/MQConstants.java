package com.org.oracle.constant;

/**
 * @author: heiye
 * @date: 2024/12/12 下午9:38
 * @version: v1.0.0
 * @description: TODO
 */
public class MQConstants {
    /**
     * Topic: 点赞、取消点赞共用一个
     */
    public static final String TOPIC_LIKE_OR_UNLIKE = "LikeUnlikeTopic";

    /**
     * Topic: 计数 - 笔记点赞数
     */
    public static final String TOPIC_COUNT_NOTE_LIKE = "CountNoteLikeTopic";

    /**
     * Topic: 计数 - 笔记点赞数落库
     */
    public static final String TOPIC_COUNT_NOTE_LIKE_2_DB = "CountNoteLike2DBTTopic";

    /**
     * Topic: 收藏、取消收藏共用一个
     */
    public static final String TOPIC_COLLECT_OR_UN_COLLECT = "CollectUnCollectTopic";

    /**
     * Topic: 计数 - 笔记收藏数
     */
    public static final String TOPIC_COUNT_NOTE_COLLECT = "CountNoteCollectTopic";

    /**
     * Topic: 计数 - 笔记收藏数落库
     */
    public static final String TOPIC_COUNT_NOTE_COLLECT_2_DB = "CountNoteCollect2DBTTopic";

    /**
     * Topic: 笔记操作（发布、删除）
     */
    public static final String TOPIC_NOTE_OPERATE = "NoteOperateTopic";

    /**
     * Topic: 粉丝数计数
     */
    public static final String TOPIC_COUNT_FANS = "CountFansTopic";

    /**
     * Topic: 关注计数
     */
    public static final String TOPIC_COUNT_FOLLOWING = "CountFollowTopic";

    /**
     * Topic: 粉丝数计数入库
     */
    public static final String TOPIC_COUNT_FANS_2_DB = "CountFans2DBTopic";
    /**
     * Topic: 关注、取关共用一个
     */
    public static final String TOPIC_FOLLOW_OR_UNFOLLOW = "FollowUnfollowTopic";

    /**
     * Tag 标签：点赞
     */
    public static final String TAG_LIKE = "Like";

    /**
     * Tag 标签：取消点赞
     */
    public static final String TAG_UNLIKE = "Unlike";

    /**
     * Tag 标签：收藏
     */
    public static final String TAG_COLLECT = "Collect";

    /**
     * Tag 标签：取消收藏
     */
    public static final String TAG_UN_COLLECT = "UnCollect";

    /**
     * Tag 标签：笔记发布
     */
    public static final String TAG_NOTE_PUBLISH = "publishNote";

    /**
     * Tag 标签：笔记删除
     */
    public static final String TAG_NOTE_DELETE = "deleteNote";

    /**
     * Tag 标签：关注
     */
    public static final String TAG_FOLLOW = "Follow";

    /**
     * Tag 标签：取关标签
     */
    public static final String TAG_UNFOLLOW = "Unfollow";
}
