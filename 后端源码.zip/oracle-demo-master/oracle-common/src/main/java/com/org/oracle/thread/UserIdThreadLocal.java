package com.org.oracle.thread;

import com.alibaba.ttl.TransmittableThreadLocal;
import org.apache.commons.lang3.StringUtils;

/**
 * @author: heiye
 * @date: 2024/09/20 下午2:23
 * @version: v1.0.0
 * @description: 登录用户线程工具类
 */
public class UserIdThreadLocal {

    // 初始化一个 ThreadLocal 变量
    private final static ThreadLocal<String> USER_THREAD_LOCAL = TransmittableThreadLocal.withInitial(String::new);

    //存入线程
    public static void setUserId(String value) {
        USER_THREAD_LOCAL.set(value);
    }

    //从线程中获取
    public static String getUserId() {
        String value = USER_THREAD_LOCAL.get();
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        return value;
    }

    //清理
    public static void clear() {
        USER_THREAD_LOCAL.remove();
    }
}
