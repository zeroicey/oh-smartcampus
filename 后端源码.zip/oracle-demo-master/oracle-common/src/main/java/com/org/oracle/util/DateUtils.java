package com.org.oracle.util;

import java.time.LocalDateTime;
import java.time.ZoneOffset;

/**
 * @author: heiye
 * @date: 2024/12/11 下午9:39
 * @version: v1.0.0
 * @description: 日期工具类
 */
public class DateUtils {
    /**
     * LocalDateTime 转时间戳
     *
     * @param localDateTime
     * @return
     */
    public static long localDateTime2Timestamp(LocalDateTime localDateTime) {
        return localDateTime.toInstant(ZoneOffset.UTC).toEpochMilli();
    }
}
