package com.org.oracle.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author: heiye
 * @date: 2024/12/10 下午1:21
 * @version: v1.0.0
 * @description: Gitee 图床配置
 */
@Data
@Component
@ConfigurationProperties(prefix = "gitee")
public class GiteeProperties {
    private String accessToken;
    private String owner;
    private String repo;
}
