package com.org.oracle.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * @author: heiye
 * @date: 2024/12/20 下午4:48
 * @version: v1.0.0
 * @description: 取关用户Lua脚本返回结果
 */
@Getter
@AllArgsConstructor
public enum UnfollowLuaResultEnum {
    // ZSET 不存在
    ZSET_NOT_EXIST(-1L),
    // 未关注该用户
    NOT_FOLLOWED(-2L),
    // 关注成功
    UNFOLLOW_SUCCESS(0L),
    ;


    private final Long code;

    /**
     * 根据类型 code 获取对应的枚举
     *
     * @param code
     * @return
     */
    public static UnfollowLuaResultEnum valueOf(Long code) {
        for (UnfollowLuaResultEnum unfollowLuaResultEnum : UnfollowLuaResultEnum.values()) {
            if (Objects.equals(code, unfollowLuaResultEnum.getCode())) {
                return unfollowLuaResultEnum;
            }
        }
        return null;
    }
}
