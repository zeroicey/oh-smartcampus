package com.org.oracle.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * @author: heiye
 * @date: 2024/12/20 上午9:58
 * @version: v1.0.0
 * @description: 关注用户Lua脚本返回结果
 */
@Getter
@AllArgsConstructor
public enum FollowLuaResultEnum {
    // ZSET 不存在
    ZSET_NOT_EXIST(-1L),
    // 关注已达到上限
    FOLLOW_LIMIT(-2L),
    // 已经关注了该用户
    ALREADY_FOLLOWED(-3L),
    // 关注成功
    FOLLOW_SUCCESS(0L),
    ;

    private final Long code;

    /**
     * 根据类型 code 获取对应的枚举
     *
     * @param code
     * @return
     */
    public static FollowLuaResultEnum valueOf(Long code) {
        for (FollowLuaResultEnum followLuaResultEnum : FollowLuaResultEnum.values()) {
            if (Objects.equals(code, followLuaResultEnum.getCode())) {
                return followLuaResultEnum;
            }
        }
        return null;
    }
}
