package com.org.oracle.constant;

/**
 * @author heiye
 * @version 1.0
 * @data 2024/8/19 下午5:33
 * 任务状态常量
 */
public class TaskConstants {

    /**
     * 未挑战
     */
    public static final Integer NOT_CHALLENGED = 0;

    /**
     * 挑战中
     */
    public static final Integer CHALLENGED = 1;

    /**
     * 已完成
     */
    public static final Integer CHALLENGE_ACCOMPLISHED = 2;
}
